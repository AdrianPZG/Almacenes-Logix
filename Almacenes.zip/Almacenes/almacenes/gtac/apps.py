from django.apps import AppConfig


class GtacConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gtac'
