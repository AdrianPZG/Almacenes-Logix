from django.contrib import admin
from gtac.models import *
# Register your models here.
admin.site.register(Profile)
admin.site.register(OrdenEntrada)
