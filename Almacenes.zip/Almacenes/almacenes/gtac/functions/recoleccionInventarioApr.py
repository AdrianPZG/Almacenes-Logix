import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum




def realizarSalidaDeInventario(df,orden):

    orden.IdStatus = Estatus.objects.get(Id=16)
    orden.save()

    materialesDeLaOrden = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden)

    for matSistema in materialesDeLaOrden:
        materialCSV = df[df['Id']==matSistema.Id]
        
        if matSistema.SitioOcurre != None:
            matSistema.Caja=materialCSV.iloc[0]['Caja']
            matSistema.GuiaEnvio=materialCSV.iloc[0]['Guía de envio']

            matSistema.IdStatus = EstatusMateriales.objects.get(Id=4)
            matSistema.save()
            
        else:
            matSistema.IdStatus = EstatusMateriales.objects.get(Id=3)
            matSistema.save()

    return True