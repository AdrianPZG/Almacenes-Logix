import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum



ordenes_servicio = list(MatOrdenSalidaApr.objects.all().values('IDPMO').distinct())

ordenes_compra = list(OrdenesEntradaApr.objects.all().values('FolioOC').distinct())

for os in ordenes_servicio :

  
    os_sistema = CatalogoOS.objects.get(OS=os['IDPMO'])

    
    if not os_sistema.EsInterna:

        

        elementos_en_salida = MatOrdenSalidaApr.objects.filter(IDPMO = os['IDPMO']).aggregate(Sum('CtdSalida'))

        elementos_en_entrada = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr__FolioOC=os_sistema.IdPES.PES).aggregate(Sum('CantidadEntrada'))


        print(f"Orden servicio:{os['IDPMO']}  PES: {os_sistema.IdPES.PES} Salidas: {elementos_en_salida['CtdSalida__sum']} Entradas: {elementos_en_entrada['CantidadEntrada__sum']}")




for pes in ordenes_compra:

    
    if 'PES' in pes['FolioOC']:

        ordenes_asociadas = list(CatalogoOS.objects.filter(IdPES__PES = pes['FolioOC']).values('OS'))
        print(f"{pes['FolioOC']} OrdenesAsociadas: {ordenes_asociadas}")

        array_ordenes_asociadas=[]

        for i in ordenes_asociadas:

            array_ordenes_asociadas.append(i['OS'])



        materialesEntrada = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr__FolioOC=pes['FolioOC'])  


        for i in materialesEntrada:

            if i.IdMat.Tipo.Nombre =="Item":
                
                if  BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES=pes['FolioOC'],IdMat__SKU=i.IdMat.SKU,QtyAbastecida=0).exists():

                    materialBolsa = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES=pes['FolioOC'],IdMat__SKU=i.IdMat.SKU,QtyAbastecida=0).first()

                    materialBolsa.QtyAbastecida =1

                    materialBolsa.save()

            if i.IdMat.Tipo.Nombre == "Agrupado":

                materialBolsa = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES=pes['FolioOC'],IdMat__GrupoAPR__Etiqueta=i.IdMat.GrupoAPR.Etiqueta)



                cantidad_entrada = i.CantidadEntrada

                for a in materialBolsa:

                    if cantidad_entrada > 0:
                        if a.QtyAbastecida <  a.QtySolicitada:

                            por_abastecer = a.QtySolicitada - a.QtyAbastecida

                            if por_abastecer > cantidad_entrada:

                                a.QtyAbastecida = a.QtyAbastecida + por_abastecer
                                a.save()
                              

                                cantidad_entrada = 0

                            if por_abastecer <= cantidad_entrada:

                                a.QtyAbastecida = a.QtySolicitada
                                a.save()
                                

                                cantidad_entrada = cantidad_entrada - por_abastecer


                        







                
            
            

        

    
    


    
            

