
from gtac.models import *
from .funcionesGlobales import *
from django.db.models import Q,Count
import pandas as pd



def validacionMatEntradaEscaneo(sku,orden,caja):
    response_data = {}
    
    try:
               
        if not Materiales.objects.filter(SKU=sku).exists(): raise ValueError("El sku '{}' no existe en la plataforma, contacte al administrador".format(sku))

        material = Materiales.objects.get(SKU=sku)
        response_data['esActivo'] = material.Activo

        if material.Tipo.Nombre == "Item":
            if material.Activo:
                response_data['result']="Ok"
                response_data['modal']="modalItem"
            else:
                contador = MatOrdenEntradaApr.objects.filter(Q(IdMat__SKU=sku) & Q(IdStatus__Id=6) & Q(Caja__Id=caja)).count()
                print(contador)

                if contador>0: 
                    response_data['result']="Ok"
                    response_data['modal']="modalEtiquetaLogix"
                else:
                    registroUntracked = UntrackedItemsApr(
                        IdMat = Materiales.objects.get(SKU=sku),
                        Caja = CajasEntradaApr.objects.get(Id=caja),
                        Cantidad = 1,
                        IdStatus= EstatusMateriales.objects.get(Id=7),
                    )
                    registroUntracked.save()
                    
                    response_data['result']="Item no activo fuera de orden"
                    response_data['message']="El elemento no esta en la orden, apartelo y espere indicaciones"

                

        elif material.Tipo.Nombre == "Agrupado":
           
            response_data['result']="Ok"
            response_data['modal']="modalAPR"
        
        elif material.Tipo.Nombre == "Consumible":
            raise ValueError("El SKU '{}' es de tipo consumiblle, contacte al administrador")

        
        return response_data


    except Exception as e:
        response_data['result']="Error"
        response_data['message']=str(e)

        return response_data




