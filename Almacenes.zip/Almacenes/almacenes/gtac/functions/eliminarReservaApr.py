import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
import math
import json


def eliminarReservaAprBySitioOS(Sitio,PMO):
    
    materiales_a_cancelar = MatOrdenReservaApr.objects.filter(SitioDestino__Nombre = Sitio,IDPMO__OS=PMO)

    incrementarEnInventario(materiales_a_cancelar)

    return True

def incrementarEnInventario(materiales):

    for i in materiales:
        elemento_en_inventario = InventarioAprovicionamiento.objects.get(Id=i.IdInventario.Id)
        
        elemento_en_inventario.CtdDisponible = elemento_en_inventario.CtdDisponible + i.CtdReservada
        elemento_en_inventario.CtdReservada = elemento_en_inventario.CtdReservada - i.CtdReservada
        
        elemento_en_inventario.save()

        i.IdStatus = EstatusMateriales.objects.get(Id=15)
        i.save()


