import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from .funcionesGlobales import *
from .crearOrdenSalidaApr import *
from .pandasValidationSalidaApr import *
import math


array_materiales_a_ingresar=[]
keysOS = ['TEMM-','MEGA-','BEST-']
keysInternas = ['GTAC','OPS','NOC']


def validacionesArchivoReserva(request,df,almacen):
    columnasNecesarias = ['SKU','Descripción','Cantidad a retirar','ID PMO','Sitio destino','Orden de compra']
    arrayCamposVacios = ['SKU','Cantidad a retirar','Sitio destino','ID PMO']
    arrayCamposNumericos = ['Cantidad a retirar']
    arrayColumnasToStr = ['ID PMO','Orden de compra']
    df = stringifyColumn(arrayColumnasToStr,df)
    validarColumnasNecesarias(columnasNecesarias,df)
    validarCamposVaciosEnColumna(arrayCamposVacios,df)
    validarColumnaNumerica(arrayCamposNumericos,df)
    creacionPES(df)
    validacionSitioDestino(df)
    validacionOSPES(df)
    df['Pertenece a cliente'] =df.apply(lambda row: validarSiPerteneceACliente(row['ID PMO'],row['Orden de compra']),axis=1)
    df['nuevo PMO']=df.apply(lambda row: build_pmo(row['ID PMO'],row['Orden de compra']),axis=1)
    df['nuevo SKU']=df.apply(lambda row: apr_to_sku(row['SKU']),axis=1)
    df['SKU'] = df['nuevo SKU'] 
    folios_internos = df.loc[df['Pertenece a cliente']==False]
    validar_pmos_folios_internos(folios_internos['nuevo PMO'].unique())
    df['nuevo OC']=df.apply(lambda row: build_oc(row['ID PMO'],row['Orden de compra'],row['nuevo PMO']),axis=1)
    validarExistenciaSKU(df,almacen)
    nueva_reserva = nuevoProcesoDeReserva(df,request,almacen) 
    return nueva_reserva


def nuevoProcesoDeReserva(df,request,almacen):

    usuario = User.objects.get(username = request.user)
    
    aprobador = Profile.objects.get(user=usuario)
    nuevaReserva = ReservasApr(
        CreadoPor = usuario,
        Almacen = almacen,
        IdStatus = Estatus.objects.get(Id=18),
        Aprobador = aprobador.Area.Aprovador
    )

    nuevaReserva.save()

    folio="RESV-"+str(nuevaReserva.Id).zfill(5)

    nuevaReserva.Folio = folio
    nuevaReserva.save()
    crearRegistrosReservaApr(df,almacen,nuevaReserva)
    return folio

def crearRegistrosReservaApr(df,almacen,orden):
    
    skusItems=[]
    skusConsumibles = []


    catalogSKUs = df['SKU'].unique()

    for sku in catalogSKUs:
        
        sku=str(sku)
        material = Materiales.objects.get(SKU=sku)

        if material.Tipo.Nombre == "Item":
            skusItems.append(sku)
        elif material.Tipo.Nombre == "Agrupado":
            skusConsumibles.append(sku)

    
    for item in skusItems:
        df2 = df[df['SKU'] == item]
        
        for index,row in df2.iterrows():

            for i in range(0,row['Cantidad a retirar']):
                materialEnAlmacen = InventarioAprovicionamiento.objects.filter(Almacen=almacen).filter(IdMat__SKU=item).exclude(CtdDisponible=0).first()
                registroCons(row,almacen,materialEnAlmacen,orden,1)
                materialEnAlmacen.CtdDisponible = materialEnAlmacen.CtdDisponible - 1
                materialEnAlmacen.CtdReservada = materialEnAlmacen.CtdReservada + 1
                materialEnAlmacen.save()

    
    for cons in skusConsumibles:
    
        df2= df[df['SKU'].astype(str)==cons]


        for index,row in df2.iterrows():
            etiqueta = Materiales.objects.get(SKU=row['SKU'])

            registroConsumibleMatOrden(row,almacen,orden,etiqueta.GrupoAPR.Etiqueta)




def registroConsumibleMatOrden(row,almacen,orden,etiqueta):

    

    materialesInventario = InventarioAprovicionamiento.objects.filter(Etiqueta=etiqueta).filter(Almacen=almacen).exclude(CtdDisponible=0)
    
    cantidadOriginal = row['Cantidad a retirar']

    for i in materialesInventario:
        
        
        if cantidadOriginal > i.CtdDisponible:
            cantidadOriginal = cantidadOriginal-i.CtdDisponible
            registroCons(row,almacen,i,orden,i.CtdDisponible)
            i.CtdReservada=i.CtdReservada + i.CtdDisponible
            i.CtdDisponible=0
            i.save()
        else:
            registroCons(row,almacen,i,orden,cantidadOriginal)
            i.CtdDisponible=i.CtdDisponible - cantidadOriginal
            i.CtdReservada=i.CtdReservada + cantidadOriginal
            i.save()
            
            break


def registroCons(row,almacen,materialEnAlmacen,orden,cantidad):
    nuevo = MatOrdenReservaApr(
        IdMat=Materiales.objects.get(SKU=row['SKU']),
        IdReservaApr=orden,
        IdInventario=materialEnAlmacen,
        IdStatus=EstatusMateriales.objects.get(Id=13),
        CtdReservada=cantidad,
        CtdDisponible=cantidad,
        IDPMO=CatalogoOS.objects.get(OS=row['nuevo PMO']),
        SitioDestino=Sitios.objects.get(Nombre=row['Sitio destino'])
    )

   
    nuevo.save()

   
 
