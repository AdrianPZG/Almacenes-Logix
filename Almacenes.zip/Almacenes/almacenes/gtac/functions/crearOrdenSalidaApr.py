import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from django.utils import timezone
from datetime import datetime




def nuevaOrdenSalidaApr(df,request,almacen):

    
    usuario = User.objects.get(username = request.user)
    
    aprobador = Profile.objects.get(user=usuario)
    
    fecha_salida_valor = request.POST.get('fechaSalida')

    fecha_salida_dt = None
    try:
        if not fecha_salida_valor:
            fecha_salida_dt = timezone.now()
        elif isinstance(fecha_salida_valor, datetime):
            fecha_salida_dt = fecha_salida_valor
        elif isinstance(fecha_salida_valor, str):
            try:
                # ISO 8601: "YYYY-MM-DD" o "YYYY-MM-DDTHH:MM:SS"
                fecha_salida_dt = datetime.fromisoformat(fecha_salida_valor)
            except Exception:
                try:
                    # Formato común de input de fecha
                    fecha_salida_dt = datetime.strptime(fecha_salida_valor, "%Y-%m-%d")
                except Exception:
                    fecha_salida_dt = timezone.now()
        else:
            fecha_salida_dt = timezone.now()
    except Exception:
        fecha_salida_dt = timezone.now()

    if isinstance(fecha_salida_dt, datetime) and fecha_salida_dt.tzinfo is None:
        fecha_salida_dt = timezone.make_aware(fecha_salida_dt)

    nuevaOrdenSalida = OrdenesSalidaApr(
        CreadoPor = usuario,
        FechaSalida = fecha_salida_dt,
        Almacen = almacen,
        IdStatus = Estatus.objects.get(Id=15),
        Aprobador = aprobador.Area.Aprovador
    )

    nuevaOrdenSalida.save()

    folio=str(nuevaOrdenSalida.Id).zfill(5)

    nuevaOrdenSalida.Folio = "SAPR-"+folio
    nuevaOrdenSalida.save()
    crearRegistrosSalidaMatOrdenApr(df,almacen,nuevaOrdenSalida)

    return nuevaOrdenSalida

            
def crearRegistrosSalidaMatOrdenApr(df,almacen,orden):
    
    skusItems=[]
    skusConsumibles = []


    catalogSKUs = df['SKU'].unique()

    for sku in catalogSKUs:
        
        sku=str(sku)
        material = Materiales.objects.get(SKU=sku)

        if material.Tipo.Nombre == "Item":
            skusItems.append(sku)
        elif material.Tipo.Nombre == "Agrupado":
            skusConsumibles.append(sku)

    
    for item in skusItems:
        df2 = df[df['SKU'] == item]
        
        for index,row in df2.iterrows():

            for i in range(0,row['Cantidad a retirar']):
                materialEnAlmacen = InventarioAprovicionamiento.objects.filter(Almacen=almacen).filter(IdMat__SKU=item).exclude(CtdDisponible=0).first()
                registroCons(row,almacen,materialEnAlmacen,orden,1)
                materialEnAlmacen.CtdDisponible = materialEnAlmacen.CtdDisponible - 1
                materialEnAlmacen.CtdReservada = materialEnAlmacen.CtdReservada + 1
                materialEnAlmacen.IDPMO=row['nuevo PMO']
                materialEnAlmacen.save()

    
    for cons in skusConsumibles:
    
        df2= df[df['SKU'].astype(str)==cons]


        for index,row in df2.iterrows():
            etiqueta = Materiales.objects.get(SKU=row['SKU'])

            registroConsumibleMatOrden(row,almacen,orden,etiqueta.GrupoAPR.Etiqueta)




def registroConsumibleMatOrden(row,almacen,orden,etiqueta):

    

    materialesInventario = InventarioAprovicionamiento.objects.filter(Etiqueta=etiqueta).filter(Almacen=almacen).exclude(CtdDisponible=0)
    
    

    cantidadOriginal = row['Cantidad a retirar']

    for i in materialesInventario:
        
        
        if cantidadOriginal > i.CtdDisponible:
            cantidadOriginal = cantidadOriginal-i.CtdDisponible
            registroCons(row,almacen,i,orden,i.CtdDisponible)
            i.CtdReservada=i.CtdReservada + i.CtdDisponible
            i.CtdDisponible=0
            i.save()
            
            

        else:
            registroCons(row,almacen,i,orden,cantidadOriginal)
            i.CtdDisponible=i.CtdDisponible - cantidadOriginal
            i.CtdReservada=i.CtdReservada + cantidadOriginal
            i.save()
            
            break


def registroCons(row,almacen,materialEnAlmacen,orden,cantidad):

    

    nuevo = MatOrdenSalidaApr(
        IdMat=materialEnAlmacen.IdMat,
        IdOrdenSalidaApr=orden,
        IdInventario=materialEnAlmacen,
        IdStatus=EstatusMateriales.objects.get(Id=1),
        CtdSalida=cantidad,
        IDPMO=row['nuevo PMO'],
        SitioDestino=Sitios.objects.get(Nombre=row['Sitio destino'])
    )

    value = row['Recolecta en almacén']

    if pd.isnull(value) or value=="empty":
        nuevo.SitioOcurre = SitiosOcurre.objects.get(CodigoPostal=row['Envio a ocurre'])
        nuevo.Destinatario = row['Destinatario']    
    
    else:
        nuevo.RecolectaEnAlmacén = row['Recolecta en almacén']
    
    nuevo.save()

   
           
            
        


    
    
    
