from gtac.models import *
from django.db.models import Q
import pandas as pd
from .funcionesGlobales import *


def validacionDeEstatus(Id):
    registro = MatOrdenEntradaApr.objects.get(Id=Id)
    if registro.IdStatus.Id == 8 or registro.IdStatus.Id == 9 :
        return True
    else:
        return False


def buscarSiIdExisteEnCaja(Id,caja):
    registro = MatOrdenEntradaApr.objects.get(Id=Id)
    if registro.Caja.Id == caja.Id:
        return True
    else:
        return False

def cantidadesIguales(cantidadEscaneada,Id):
    registro = MatOrdenEntradaApr.objects.get(Id=Id)
   
    if int(registro.CantidadRecepcionada) == int(cantidadEscaneada):
        return True
    else:
        return False

def itemOAgrupado(Id):
    registro = MatOrdenEntradaApr.objects.get(Id=Id)
    return registro.IdMat.Tipo.Nombre
    

def validarExistenciaUbicacionTecnica(ubicacion,almacen):
    
    if UbicacionesTecnicas.objects.filter(Q(Descripcion=ubicacion) & Q(IdAlmacen=almacen)).exists():
        return True
    
    else:
        return False

def validarUbicacionAPR(Id,escaneada,almacen):
    registro=MatOrdenEntradaApr.objects.get(Id=Id)
    ubicacionAPR = InventarioAprovicionamiento.objects.filter(Q(IdApr__Id=registro.IdAPR.Id) & Q(Almacen__IdSitio=almacen))

    if ubicacionAPR.exists():
        
        if ubicacionAPR[0].IdUbTec.Descripcion == escaneada:
            return "Coincide"

        else:
            return "No coincide"

    else:
        return "APR no existe"

    


    


def validacionPlantillaCaja(df,caja):

    columnasNecesarias = ['Id inventario','Escanea la ubicacion tecnica','Ingresa la cantidad']
    arrayCamposVacios = ['Id inventario','Escanea la ubicacion tecnica','Ingresa la cantidad']
    arrayCamposNumericos = ['Id inventario','Ingresa la cantidad']
    arrayToString=['Id inventario','Escanea la ubicacion tecnica']
    arrayNoRepetidos=['Id inventario']

    validarColumnasNecesarias(columnasNecesarias,df)
    validarCamposVaciosEnColumna(arrayCamposVacios,df)
    validarColumnaNumerica(arrayCamposNumericos,df)
    validarColumnasValoresUnicos(arrayNoRepetidos,df)

    
    

    df['Corresponde a la caja']= df.apply(lambda row: buscarSiIdExisteEnCaja(row['Id inventario'],caja), axis=1)
    dfNoEnCaja = df[df['Corresponde a la caja']==False]
    valores = dfNoEnCaja['Id inventario'].tolist()
    if len(valores) > 0:
        listado = ''.join(str(x)+"," for x in valores)
        raise ValueError ("Los Id's ({}) no pertenencen a la caja {}, eliminelos o vuelva a descargar la plantilla".format(listado,caja.CodigoCaja))


    df['Estatus 9 u 8'] = df.apply(lambda row: validacionDeEstatus(row['Id inventario']), axis=1)
    dfNoEnEstatus = df[df['Estatus 9 u 8']==False]
    valores = dfNoEnEstatus['Id inventario'].tolist()
    if len(valores) > 0:
        listado = ''.join(str(x)+"," for x in valores)
        raise ValueError ("Los Id's ({}) no estan en el estatus necesario para poder ser inventariados, eliminelos o vuelva a descargar la plantilla".format(listado,caja.CodigoCaja))


    df['Cantidades iguales']= df.apply(lambda row: cantidadesIguales(row['Ingresa la cantidad'],row['Id inventario']), axis=1)
    dfCantidadesIncorrectas = df[df['Cantidades iguales']==False]
    valores = dfCantidadesIncorrectas['Id inventario'].tolist()
    if len(valores) > 0:
        listado = ''.join(str(x)+"," for x in valores)
        raise ValueError ("La cantidad escaneada de los registros ({}) no corresponde con la recepcionada ".format(listado))

    df['Ubicacion valida'] = df.apply(lambda row: validarExistenciaUbicacionTecnica(row['Escanea la ubicacion tecnica'],caja.IdOrdenEntradaApr.Almacen.IdSitio), axis=1)
    dfUbicacionesValidas = df[df['Ubicacion valida']==False]
    valores = dfUbicacionesValidas['Id inventario'].tolist()
    if len(valores) > 0:
        listado = ''.join(str(x)+"," for x in valores)
        raise ValueError ("Las ubicaciones escaneadas de los registros ({}) no son validas".format(listado))

   
    df['Item o agrupado']= df.apply(lambda row: itemOAgrupado(row['Id inventario']), axis=1)



    dfAgrupado=df[df['Item o agrupado']=="Agrupado"]
    dfItem=df[df['Item o agrupado']=="Item"]

    if not dfAgrupado.empty:

        dfAgrupado['Coincide ubicacion'] = dfAgrupado.apply(lambda row: validarUbicacionAPR(row['Id inventario'],row['Escanea la ubicacion tecnica'],caja.IdOrdenEntradaApr.Almacen.IdSitio), axis=1)

    if not dfItem.empty:
        dfItem['Creado en inventario'] =  dfItem.apply(lambda row: inventariarItem(row), axis=1)
    
    if not dfAgrupado.empty:
        dfAgrupado['Creado en inventario'] =  dfAgrupado.apply(lambda row: inventariarApr(row), axis=1)

    

    return True



def inventariarItem(row):
    registroMatOrden = MatOrdenEntradaApr.objects.get(Id=row['Id inventario'])
    nuevoItem = InventarioAprovicionamiento(
        Almacen = Sitios.objects.get(IdSitio=registroMatOrden.IdOrdenEntradaApr.Almacen.IdSitio),
        IdUbTec = UbicacionesTecnicas.objects.get(Q(IdAlmacen=registroMatOrden.IdOrdenEntradaApr.Almacen.IdSitio) & Q(Descripcion=row['Escanea la ubicacion tecnica'])),
        CtdTotal = registroMatOrden.CantidadRecepcionada,
        CtdDisponible = registroMatOrden.CantidadRecepcionada,
        CtdReservada = 0,
        Etiqueta = registroMatOrden.etiquetaLogix,
        IdMat = Materiales.objects.get(IdMat=registroMatOrden.IdMat.IdMat)   
    )

    if registroMatOrden.IdMat.Activo:
        nuevoItem.NoSerie = registroMatOrden.NoSerie
        nuevoItem.NoActivo = registroMatOrden.NoActivo

    nuevoItem.save()

    registroMatOrden.IdStatus=EstatusMateriales.objects.get(Id=10)
    registroMatOrden.IdInventario = InventarioAprovicionamiento.objects.get(Id=nuevoItem.Id)
    registroMatOrden.save()



def inventariarApr(row):
    registroMatOrden = MatOrdenEntradaApr.objects.get(Id=row['Id inventario'])

    registroEnInventario = InventarioAprovicionamiento.objects.filter(Q(IdApr__Id = registroMatOrden.IdAPR.Id) & Q(Almacen__IdSitio=registroMatOrden.IdOrdenEntradaApr.Almacen.IdSitio))

    if registroEnInventario.exists():

        registroEnInventario = registroEnInventario[0]
        
        oldDisponible  = registroEnInventario.CtdDisponible
        oldTotal  = registroEnInventario.CtdTotal

        registroEnInventario.CtdDisponible =  oldDisponible + registroMatOrden.CantidadRecepcionada
        registroEnInventario.CtdTotal =  oldTotal + registroMatOrden.CantidadRecepcionada

        registroEnInventario.save()

        registroMatOrden.IdStatus = EstatusMateriales.objects.get(Id=10)
        registroMatOrden.save()

        return True
    
    else:
        nuevoApr = InventarioAprovicionamiento(
            Almacen = Sitios.objects.get(IdSitio=registroMatOrden.IdOrdenEntradaApr.Almacen.IdSitio),
            IdUbTec = UbicacionesTecnicas.objects.get(Q(IdAlmacen=registroMatOrden.IdOrdenEntradaApr.Almacen.IdSitio) & Q(Descripcion=row['Escanea la ubicacion tecnica'])),
            CtdTotal = registroMatOrden.CantidadRecepcionada,
            CtdDisponible = registroMatOrden.CantidadRecepcionada,
            CtdReservada = 0,
            Etiqueta = registroMatOrden.IdAPR.Etiqueta,
            IdApr = CatalogoAPR.objects.get(Id=registroMatOrden.IdAPR.Id) 
        )

        if registroMatOrden.IdAPR.TipoAgrupacion == "Cantidad":
            nuevoApr.IdMat = Materiales.objects.get(IdMat=registroMatOrden.IdAPR.SKUPadre.IdMat)
        
        nuevoApr.save()

        registroMatOrden.IdStatus = EstatusMateriales.objects.get(Id=10)
        registroMatOrden.save()

        

        return True


