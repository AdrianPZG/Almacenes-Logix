import os
from django.core.wsgi import get_wsgi_application
import pandas as pd
import functools
from gtac.models import *
from typing import List


def reporte_bolsa_web(PES):
    class elemento_bolsa:
        def __init__(self,**kwargs):
            
            if "APR" in kwargs.get('titulo'):
                apr = CatalogoAPR.objects.get(Etiqueta=titulo)
                self.sku = kwargs.get('SKU',None)
                self.apr = kwargs.get('titulo')
                self.texto_breve=apr.get_texto_breve()
                self.categoria=apr.get_categoria()
            else:
                elemento = Materiales.objects.get(SKU=titulo)
                self.sku = kwargs.get('titulo')
                self.apr = kwargs.get('APR',None)
                self.texto_breve = elemento.TextoBreve
                self.categoria =  elemento.IdCategoria.Nombre

            self.counter_salida = 0
            self.counter_pendiente_salida = 0
            self.counter_inventariado = 0
            self.counter_pendiente_inventariar = 0
            self.counter_cancelados_salida = 0
            self.counter_pendiente_validar = 0
            self.counter_inventariado_faltante = 0
            self.counter_POD = 0
        

        def __str__(self):
            if self.sku is None:
                return f"{self.apr} {self.counter_salida}"
            elif self.apr is None:
                return f"{self.sku} {self.counter_salida}"

    os_in_pes=CatalogoOS.objects.filter(IdPES = CatalogoPES.objects.get(PES=PES))
    os_array = list(map(lambda x:x.OS,os_in_pes))
    elementos_salida =MatOrdenSalidaApr.objects.filter(IDPMO__in=os_array)
    elementos_entrada = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr__FolioOC=PES)
    index_elementos_salida =0
    dict_bolsa ={}

    while index_elementos_salida != len(elementos_salida):
        current_elemento =  elementos_salida[index_elementos_salida]
        print("Salida",current_elemento.Id)
        current_dict = {
                "Status":current_elemento.IdStatus.Descripcion,
                "Ctd Salida":current_elemento.CtdSalida,
                "IDMO":current_elemento.IDPMO,
                "PES":PES,
                "Sitio":current_elemento.SitioDestino.Nombre,
                "Fecha de salida":str(current_elemento.IdOrdenSalidaApr.FechaSalida),
                "Caja":current_elemento.Caja,
                "Guia":current_elemento.GuiaEnvio,
                "Folio salida":current_elemento.IdOrdenSalidaApr.Folio,
                "Destinatario":current_elemento.Destinatario,
            }

        if current_elemento.SitioOcurre != None:
            current_dict['DHL'] = current_elemento.SitioOcurre.CodigoPostal

        if "APR" in current_elemento.IdInventario.Etiqueta:
            apr  = CatalogoAPR.objects.get(Etiqueta = current_elemento.IdInventario.Etiqueta)
            current_dict["APR"] = current_elemento.IdInventario.Etiqueta
            current_dict["Descripcion"] =apr.get_texto_breve()
            current_dict["Categoria"] = apr.get_texto_breve()
            titulo = current_elemento.IdInventario.Etiqueta

        else:
            current_dict["SKU"] = current_elemento.IdMat.SKU
            current_dict["Descripcion"] =  current_elemento.IdMat.TextoBreve
            current_dict["Categoria"] =  current_elemento.IdMat.IdCategoria.Nombre
            current_dict["No de serie"] =  current_elemento.IdInventario.NoSerie
            titulo =  current_elemento.IdMat.SKU


        if titulo not in dict_bolsa.keys():
            dict_bolsa[titulo] = elemento_bolsa(titulo=titulo)

        current_elemento_bolsa = dict_bolsa.get(titulo)

        if  current_elemento.IdStatus.Id ==15:
            current_elemento_bolsa.counter_cancelados_salida += current_elemento.CtdSalida
        elif  current_elemento.IdStatus.Id ==3 or current_elemento.IdStatus.Id ==4 or current_elemento.IdStatus.Id==1:
            current_elemento_bolsa.counter_pendiente_salida += current_elemento.CtdSalida
        elif  current_elemento.IdStatus.Id ==5:
            current_elemento_bolsa.counter_salida += current_elemento.CtdSalida
        else:
            pass
        
        index_elementos_salida+=1


    index_elementos_entrada =0

    while index_elementos_entrada !=len(elementos_entrada):
       
        current_elemento = elementos_entrada[index_elementos_entrada]
        print("Entrada",current_elemento.Id)
        current_dict={
            "SKU":current_elemento.IdMat.SKU,
            "Descripcion":current_elemento.IdMat.TextoBreve,
            "Categoria":current_elemento.IdMat.TextoBreve,
            "Status":current_elemento.IdStatus.Descripcion,
            "PES":PES,
            "Cantidad POD":current_elemento.CantidadEntrada,
            "Cantidad Inventariada":current_elemento.CantidadRecepcionada,
            "Orden Entrada":current_elemento.IdOrdenEntradaApr.Folio,
            "Caja":current_elemento.Caja.CodigoCaja,
            "Fecha entrada":str(current_elemento.IdOrdenEntradaApr.FechaEntrada)
        }

        if  current_elemento.IdMat.Tipo.Id == 3:
            titulo = current_elemento.IdMat.GrupoAPR.Etiqueta
            current_dict['APR'] =  current_elemento.IdMat.GrupoAPR.Etiqueta
        else:
            titulo =  current_elemento.IdMat.SKU
            current_dict["No de serie"] =  current_elemento.NoSerie

        if titulo not in dict_bolsa.keys():
            dict_bolsa[titulo] = elemento_bolsa(titulo=titulo)
        
        elem =  dict_bolsa.get(titulo)
        
        if  current_elemento.IdStatus.Id == 10:

            if "APR" in titulo and current_elemento.CantidadEntrada > current_elemento.CantidadRecepcionada:
                elem.counter_inventariado_faltante += int(current_elemento.CantidadEntrada) - int(current_elemento.CantidadRecepcionada)
                elem.counter_inventariado +=int(current_elemento.CantidadRecepcionada)
                elem.counter_POD +=int(current_elemento.CantidadEntrada)

            else:
                elem.counter_inventariado +=int(current_elemento.CantidadRecepcionada)
                elem.counter_POD +=int(current_elemento.CantidadEntrada)

        #Pendiente validar existencia en caja
        elif current_elemento.IdStatus.Id == 6:
            elem.counter_pendiente_validar +=int(current_elemento.CantidadEntrada)
            elem.counter_POD +=int(current_elemento.CantidadEntrada)


        #Pendiente ubicacion tecnica
        elif current_elemento.IdStatus.Id == 8:
            elem.counter_POD +=int(current_elemento.CantidadEntrada)
            elem.counter_pendiente_inventariar +=int(current_elemento.CantidadRecepcionada)

        else:
            print("-----",current_elemento.Id)

        index_elementos_entrada+=1

    final_array=[]
    for x in dict_bolsa.items():
        key,val = x[0],x[1]
        final_array.append(val.__dict__)
        
    

    return final_array

