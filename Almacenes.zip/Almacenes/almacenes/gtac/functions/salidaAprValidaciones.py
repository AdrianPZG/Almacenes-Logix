import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from .funcionesGlobales import *
from .crearOrdenSalidaApr import *

array_materiales_a_ingresar=[]
keysOS = ['TEMM','MEGA','BEST']
keysInternas = ['GTAC','OPS','NOC']

arrayMaterialesReingreso=[]

class Material:
    def __init__(self,**kwargs):
        self.sku = kwargs.get('sku')
        self.cantidad = kwargs.get('cantidad')
        self.id_pmo = kwargs.get('id_pmo')
        self.orden_compra = kwargs.get('orden_compra')

    def __str__(self):
        return("{}/{}/{}".format(self.sku,self.id_pmo,self.orden_compra))


    def apr_o_item(self):
        material  = Materiales.objects.get(SKU=self.sku)
        return material


def crearMaterial(row):
    nuevoMaterial = Material(sku=row['SKU'],cantidad=row['Cantidad a retirar'],id_pmo=row['ID PMO'],orden_compra=row['Orden de compra'])
    array_materiales_a_ingresar.append(nuevoMaterial)



def crearSalidaApr(df,request):
    almacen=Sitios.objects.get(IdSitio = 181) #Corresponde a CDMX
    df['Pertenece a cliente'] =df.apply(lambda row: validarSiPerteneceACliente(row),axis=1)
    df['nuevo PMO']=df.apply(lambda row: build_pmo(row),axis=1)
    df['nuevo SKU']=df.apply(lambda row: apr_to_sku(row),axis=1)
    df['SKU'] = df['nuevo SKU'] 
    df['nuevo OC']=df.apply(lambda row: build_oc(row['ID PMO'],row['Orden de compra'],row['nuevo PMO']),axis=1)
    folios_internos = df.loc[df['Pertenece a cliente']==False]
    validar_pmos_folios_internos(folios_internos['nuevo PMO'].unique())
    orden_salida= nuevaOrdenSalidaApr(df,request,almacen)
    crearEntradaApr(df,request,orden_salida.Id)
    return orden_salida.Folio
 



def crearEntradaApr(df,request,orden_salida_id):
   
    usuario = User.objects.get(username=request.user)
    profile = Profile.objects.get(user=usuario)

    status = 1
    if profile.Area.Aprovador.username == usuario.username: status = 17
    
    almacen=Sitios.objects.get(IdSitio = request.POST['almacenSelec'])


    df_filtrado = df.loc[(df['Pertenece a cliente']==True) | ((df['Pertenece a cliente']==False) & (df['Es prestamo']=='Si'))]
    df_filtrado.apply(lambda row:crearMaterial(row),axis=1)

    for orden_servicio in df_filtrado['nuevo PMO'].unique():
        
        materiales_por_oc = df_filtrado.loc[df_filtrado['nuevo PMO']==orden_servicio]

        crear_materiales_orden_entrada_apr(orden_servicio,orden_salida_id,materiales_por_oc,request)


       



def crear_materiales_orden_entrada_apr(orden_servicio,orden_salida_id,materiales,request):

    materiales_por_sku=materiales.groupby(['SKU'])['Cantidad a retirar'].sum().to_frame()

    for index,i in materiales_por_sku.iterrows():
        material_en_sistema = Materiales.objects.get(SKU=index)

        if material_en_sistema.Tipo.Nombre == "Item":
            
            for j in range(i['Cantidad a retirar']):

                nuevo_material = BolsaMaterialesByOs(
                    IdMat = material_en_sistema,
                    IdSalida=OrdenesSalidaApr.objects.get(Id=orden_salida_id),
                    QtySolicitada=1,
                    IdOS=CatalogoOS.objects.get(OS=orden_servicio),
                    IdStatus = EstatusMateriales.objects.get(Id=11),
                )
                nuevo_material.save()

        elif material_en_sistema.Tipo.Nombre == "Agrupado":
            
            nuevo_material = BolsaMaterialesByOs(
                IdMat = material_en_sistema,
                IdSalida=OrdenesSalidaApr.objects.get(Id=orden_salida_id),
                IdOS=CatalogoOS.objects.get(OS=orden_servicio),
                IdStatus = EstatusMateriales.objects.get(Id=11),
                QtySolicitada=i['Cantidad a retirar'],
            )
            nuevo_material.save()
                


def validar_pmos_folios_internos(folios_internos):
    
    for i in folios_internos:
        if not CatalogoOS.objects.filter(OS=i).exists():
            nuevo_folio_interno = CatalogoOS(
                OS=i,
                EsInterna = True
            )
            nuevo_folio_interno.save()

def build_pmo(row):

    if "-" in row['ID PMO']:
        return row['ID PMO']
    else:
        ultimoRegistro = CatalogoOS.objects.filter(OS__contains=row['ID PMO']).order_by('-OS')[0]
        IDPMOSplit = ultimoRegistro.OS.split("-")
        folio = int(IDPMOSplit[1])
        nuevoFolio = row['ID PMO']+"-"+str(folio+1).zfill(4)
        return nuevoFolio


def build_oc(id_pmo,oc,nuevoPMO):
    if any([x in id_pmo for x in keysInternas]):
        return nuevoPMO
    else:
        return oc
        

def apr_to_sku(row):
    texto=row['SKU']
    if "APR" in texto:
        apr = CatalogoAPR.objects.get(Etiqueta = texto)
        material = Materiales.objects.filter(GrupoAPR=apr)[0]
        return material.SKU
    else:
        return texto



def validarSiPerteneceACliente(row):
    
    if any([x in row['ID PMO'] for x in keysOS]):
        return True
    else:
        return False



def salidaAprValidacionesFunciones(reques,df):
   
    columnasNecesarias = ['SKU','Descripción','Cantidad a retirar','ID PMO','Recolecta en almacén','Envio a ocurre','Destinatario','Sitio destino','Es prestamo','Orden de compra']


    for col in columnasNecesarias:
        df[col] = df[col].fillna("empty")
    
    
    df['SKU'] = df.apply(lambda row: sku_conversion(row),axis=1)

    for col in columnasNecesarias:
        if col =="Cantidad a retirar":
            pass
        else:
            df[col] = df[col].apply(lambda x: str(x).strip())


    df['Validacion columnas necesarias'] = validarColumnasNecesarias2(columnasNecesarias,df)
    df['Validacion SKU'] = df.apply(lambda row: validacionSKUExistencia(row,df),axis=1)
    df['Validaciones ID PMO'] = df.apply(lambda row: validacionIDPMO(row,df),axis=1)
    df['Validacion Sitio Destino'] = df.apply(lambda row: validarSitioDestino(row),axis=1)
    df['Validar columna Es prestamo'] = df.apply(lambda row: validarEsPrestamo(row),axis=1)

    errores_validacion_sku = (df['Validacion SKU']!="Aprobado").sum()
    if errores_validacion_sku ==0:
        df['Disponibilidad en inventario'] = df.apply(lambda row: validarExistenciaSKU(row,df),axis=1)

    else:
        df['Disponibilidad en inventario'] ="Todos los SKUS deben ser validos"

    df['Validar tipo envio'] = df.apply(lambda row: validarTipoEnvio(row),axis=1)
    df['Validacion final'] =  df.apply(lambda row: validacionFinal(row),axis=1)

  
    filasConErrores = (df['Validacion final']==False).sum()

    if filasConErrores !=0:    
        return False,df
    else:
        return True,df


def validarEsPrestamo(row):

    if row['Es prestamo'] =="empty":
        return "La columna Es prestamo no puede estar vacia"
    
    if row['Es prestamo'] =="Si" or row['Es prestamo'] =="No":
        return "Aprobado"
    else:
        return "Valores validos Si/No"



def validacionFinal(row):
    if row['Validar columna Es prestamo'] != "Aprobado" or row['Validacion columnas necesarias']!="Aprobado" or row['Validacion SKU']!="Aprobado" or row['Validaciones ID PMO']!="Aprobado" or row['Validacion Sitio Destino'] !="Aprobado" or row['Disponibilidad en inventario']!="Aprobado" or row['Validar tipo envio']!="Aprobado":
        return False
    else:
        return True




def validarTipoEnvio(row):

    if row['Recolecta en almacén'] =="empty" and row['Envio a ocurre'] =="empty":
        return f"Debes llenar por lo menos un metodo de envio"
    
    if row['Recolecta en almacén'] !="empty" and row['Envio a ocurre'] !="empty":
        return f"Solo puedes seleccionar un metodo de envio"
    

    if row['Envio a ocurre']!="empty":
        if row['Destinatario'] =="empty":
            return "La columna es Destinatario es obligatoria con metodo envio a ocurre"

        if not SitiosOcurre.objects.filter(CodigoPostal=row['Envio a ocurre']).exists():
            return f"El sitio ocurre {row['Envio a ocurre']} no existe en sistema"
    
     

    return "Aprobado"
    


def validarSitioDestino(row):
    if row['Sitio destino'] =="empty":
        return "La columna Sitio Destino es obligatoria"
    
    if not  Sitios.objects.filter(Nombre=row['Sitio destino']).exists(): 
        return f"El Sitio destino {row['Sitio destino']} no existe en sistema"
    return "Aprobado"


def validarExistenciaSKU(row,df):

    if 'APR' in row['SKU']:
        material=Materiales.objects.filter(GrupoAPR__Etiqueta=row['SKU'])[0]
    else:
        material= Materiales.objects.get(SKU=row['SKU'])

    if material.Tipo.Nombre =="Item": 
        suma_item=df.groupby(['SKU'])['Cantidad a retirar'].sum()
        
        disponible_inventario = InventarioAprovicionamiento.objects.filter(IdMat__SKU=row['SKU']).aggregate(Sum('CtdDisponible'))['CtdDisponible__sum']

        if disponible_inventario >=suma_item[row['SKU']]:
            return "Aprobado"

        else:
            return f"Solo existen {disponible_inventario} {row['SKU']} en inventario"
        


    elif material.Tipo.Nombre =="Agrupado":

        arraySKUs = [x.SKU for x in Materiales.objects.filter(GrupoAPR__Etiqueta = material.GrupoAPR.Etiqueta)] 
        arraySKUs.append(material.GrupoAPR.Etiqueta)

        df_apr=df[df['SKU'].isin(arraySKUs)]
        
        suma_apr =df_apr['Cantidad a retirar'].sum()
         
        disponible_inventario = InventarioAprovicionamiento.objects.filter(Etiqueta=material.GrupoAPR.Etiqueta).aggregate(Sum('CtdDisponible'))['CtdDisponible__sum']

        if disponible_inventario >=suma_apr:
            return "Aprobado"
        else:
            return f"Solo existen {disponible_inventario} {material.GrupoAPR.Etiqueta} en inventario"
        
    else:
        return "El elemento no esta disponible en Guadalajara"



def validarColumnasNecesarias2(columnas,df):
    
    columnasArchivo = df.columns

    columnas_faltantes = []
    for i in columnas:
        if not i in columnasArchivo: columnas_faltantes.append(i)

    if len(columnas_faltantes)>0:
        return "El archivo tiene columnas faltantes"

    else:
        return "Aprobado"

def validacionSKUExistencia(row,df):

    if row['SKU']=="empty":
        return "La columna SKU es obligatoria"
   
    if row['Cantidad a retirar']=="empty":
        return "La columna Cantidad a retirar es obligatoria"

    tiposDeDatoColumnas = df.dtypes

    if tiposDeDatoColumnas['Cantidad a retirar'] != "int64" : return "La columna Cantidad a retirar solo puede tener numeros enteros"

    if "APR" in row['SKU']:
        if not CatalogoAPR.objects.filter(Etiqueta = row['SKU']).exists(): 
            return f"El APR '{row['SKU']}' no existe en el sistema."
        
        material =Materiales.objects.filter(GrupoAPR__Etiqueta=row['SKU'])[0]
        
    else:
        if not Materiales.objects.filter(SKU=row['SKU']).exists():
            return f"El SKU {row['SKU']} no existe en el sistema"
        
        material =  Materiales.objects.get(SKU=row['SKU'])

    if material.Tipo.Nombre=="Item":
        return "Aprobado"

    elif material.Tipo.Nombre =="Agrupado":
        return "Aprobado"
         
    else:
        return "Material no disponible en Guadalajara"

def sku_conversion(row):
    if row['SKU']=="empty":
        return row['SKU']
    else:    
        return str(row['SKU'])


def validacionIDPMO(row,df):
    if row['ID PMO']=="empty":
        return "La columna ID PMO es obligatoria"
    
    
    OS_Cliente=[x in row['ID PMO'] for x in keysOS]
    OS_Internas=[x in row['ID PMO'] for x in keysInternas]
    
    if not any(OS_Cliente) and not any(OS_Internas):
        return "El ID PMO no es valido"

    
    if any(OS_Cliente):

        if row['Orden de compra'] == "empty":
            return "La columna Orden de compra es obligatoria"

        if "PES-" not in row['Orden de compra']:
            return "La columna Orden de compra no tiene un formato valido"


        if not CatalogoPES.objects.filter(PES=row['Orden de compra']).exists():
            nuevaPES= CatalogoPES(
                    PES=row['Orden de compra'],
                    )
            nuevaPES.save()


        dfPorOs = df.loc[df['ID PMO']==row['ID PMO']]
        nuevo = dfPorOs.groupby(['ID PMO','Orden de compra']).size()
        if len(nuevo.index) != 1: return f"El ID PMO '{row['ID PMO']}' está relacionado con multiples ordenes de compra"
        
        if CatalogoOS.objects.filter(OS=row['ID PMO']).exists():
            osEnSistema = CatalogoOS.objects.get(OS=row['ID PMO'])
            if osEnSistema.IdPES.PES != row['Orden de compra']:
                return "El ID PMO '{}' está relacionado con la orden de compra '{}'".format(row['ID PMO'],osEnSistema.IdPES.PES)
            else:
                return "Aprobado"

        else:
            nuevaOS = CatalogoOS(
                    OS=row['ID PMO'],
                    IdPES=CatalogoPES.objects.get(PES=row['Orden de compra']),
                    EsInterna = False
            )
            nuevaOS.save()
            return "Aprobado"

    if any(OS_Internas):
        
        if "-" in row['ID PMO']:
            if not row['ID PMO'].split("-")[1].isdigit():
                return "Tiene que haber un numero despues del '-' para folios PMO internos"
            
            if not CatalogoOS.objects.filter(OS=row['ID PMO']).exists():
                return f"El folio {row['ID PMO']} no existe en el sistema"
            else:
                return "Aprobado"
        else:
            print(row['ID PMO']) 
            if row['ID PMO'] == "NOC" or row['ID PMO'] == "GTAC" or row['ID PMO'] == 'OPS':
                return "Aprobado"
            else:
                return "El ID PMO tiene que coincidie con NOC,GTAC,OPS"


    
    
    
