
def crearEnInventario(orden):
    print("hola")