import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
import math
import json

def cancelacionDeSalidaApr(orden):
    materialesEnLaOrden = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr = orden)
    materialesEnLaBolsa= BolsaMaterialesByOs.objects.filter(IdSalida = orden)


    incrementarEnInventario(materialesEnLaOrden)
    eliminarMatrerialesBolsaApr(materialesEnLaBolsa)
    orden.IdStatus = Estatus.objects.get(Id=19)
    orden.save()

    return True

def incrementarEnInventario(materiales):

    for i in materiales:
        elemento_en_inventario = InventarioAprovicionamiento.objects.get(Id=i.IdInventario.Id)
        
        elemento_en_inventario.CtdDisponible = elemento_en_inventario.CtdDisponible + i.CtdSalida
        elemento_en_inventario.CtdReservada = elemento_en_inventario.CtdReservada - i.CtdSalida
        
        elemento_en_inventario.save()

        i.IdStatus = EstatusMateriales.objects.get(Id=15)
        i.save()

def eliminarMatrerialesBolsaApr(materiales):

    for i in materiales:
        i.IdStatus = EstatusMateriales.objects.get(Id=15)
        i.save()
