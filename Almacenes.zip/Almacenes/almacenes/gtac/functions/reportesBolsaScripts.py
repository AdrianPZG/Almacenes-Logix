import os
from django.core.wsgi import get_wsgi_application
import pandas as pd
import functools
from gtac.models import *
from typing import List

def get_entradas_by_pes(PES:str)->bool:
    elementos_entrada = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr__FolioOC=PES)
    df =  pd.DataFrame()
    index_entradas = 0

    while index_entradas!=len(elementos_entrada):
        elemento= elementos_entrada[index_entradas]
        current_dict={
            "SKU":elemento.IdMat.SKU,
            "Descripcion":elemento.IdMat.TextoBreve,
            "Categoria":elemento.IdCategoria.Nombre,
            "Status":elemento.IdStatus.Descripcion,
            "PES":PES,
            "Cantidad POD":elemento.CantidadEntrada,
            "Cantidad Inventariada":elemento.CantidadRecepcionada,
            "Orden Entrada":elemento.IdOrdenEntradaApr.Folio,
            "Caja":elemento.Caja.CodigoCaja,
            "Fecha entrada":str(elemento.IdOrdenEntradaApr.FechaEntrada)
        }
        
        if elemento.IdMat.Tipo.Id ==3:
            current_dict['APR'] =  elemento.IdMat.GrupoAPR.Etiqueta
        else:
            current_dict["No de serie"] =  elemento.NoSerie

        df =  pd.concat([df,pd.DataFrame([current_dict])],ignore_index=True)
        index_entradas +=1
    
    return df 


def reporte_skus():
    df =  pd.DataFrame()
    skus =  Materiales.objects.all()
    index_mat = 0
    while index_mat!=len(skus):
        elemento =  skus[index_mat]
        current_dict={
                "SKU":elemento.SKU,
                "Texto breve":elemento.TextoBreve,
                "Categoria": elemento.IdCategoria,
                "Tipo":elemento.Tipo,
                }
        if elemento.Tipo.Id == 3:
            current_dict["APR"] = elemento.GrupoAPR.Etiqueta
        df =  df.append(current_dict,ignore_index=True)
        index_mat+=1
    
    return df


def get_salidas_by_pes(PES:str)->bool:
    df =  pd.DataFrame()    
    os_in_pes=CatalogoOS.objects.filter(IdPES = CatalogoPES.objects.get(PES=PES))
    os_array = list(map(lambda x: x.OS,os_in_pes))
    elementos_salida =MatOrdenSalidaApr.objects.filter(IDPMO__in=os_array)
    index_elementos = 0
    while index_elementos!=len(elementos_salida):
        elemento =  elementos_salida[index_elementos]
        print(elemento.Id)
        current_dict = {
                "Status":elemento.IdStatus.Descripcion,
                "Ctd Salida":elemento.CtdSalida,
                "IDMO":elemento.IDPMO,
                "PES":PES,
                "Sitio":elemento.SitioDestino.Nombre,
                "Fecha de salida":str(elemento.IdOrdenSalidaApr.FechaSalida),
                "Caja":elemento.Caja,
                "Guia":elemento.GuiaEnvio,
                "Folio salida":elemento.IdOrdenSalidaApr.Folio,
                "Destinatario":elemento.Destinatario,
                }
        
        if elemento.SitioOcurre != None:
            current_dict['DHL'] = elemento.SitioOcurre.CodigoPostal

        if  "APR" in elemento.IdInventario.Etiqueta:
            apr  = CatalogoAPR.objects.get(Etiqueta = elemento.IdInventario.Etiqueta)
            current_dict["APR"] = elemento.IdInventario.Etiqueta
            current_dict["Descripcion"] =apr.get_texto_breve()
            current_dict["Categoria"] = apr.get_texto_breve()


        else:
            current_dict["SKU"] = elemento.IdMat.SKU
            current_dict["Descripcion"] =  elemento.IdMat.TextoBreve
            current_dict["Categoria"] =  elemento.IdMat.IdCategoria.Nombre
            current_dict["No de serie"] =  elemento.IdInventario.NoSerie

        df =  pd.concat([df,pd.DataFrame([current_dict])],ignore_index=True)

        index_elementos+=1

    return df


def reporte_bolsa(PES):
    class elemento_bolsa:
        def __init__(self,**kwargs):
            
            if "APR" in kwargs.get('titulo'):
                apr = CatalogoAPR.objects.get(Etiqueta=titulo)
                self.sku = kwargs.get('SKU',None)
                self.apr = kwargs.get('titulo')
                self.texto_breve=apr.get_texto_breve()
                self.categoria=apr.get_categoria()
            else:
                elemento = Materiales.objects.get(SKU=titulo)
                self.sku = kwargs.get('titulo')
                self.apr = kwargs.get('APR',None)
                self.texto_breve = elemento.TextoBreve
                self.categoria =  elemento.IdCategoria.Nombre

            self.counter_salida = 0
            self.counter_pendiente_salida = 0
            self.counter_inventariado = 0
            self.counter_pendiente_inventariar = 0
            self.counter_cancelados_salida = 0
            self.counter_pendiente_validar = 0
            self.counter_inventariado_faltante = 0
            self.counter_POD = 0
        
        def __str__(self):
            if self.sku is None:
                return f"{self.apr} {self.counter_salida}"
            elif self.apr is None:
                return f"{self.sku} {self.counter_salida}"

    os_in_pes=CatalogoOS.objects.filter(IdPES = CatalogoPES.objects.get(PES=PES))
    os_array = list(map(lambda x:x.OS,os_in_pes))
    elementos_salida =MatOrdenSalidaApr.objects.filter(IDPMO__in=os_array)
    elementos_entrada = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr__FolioOC=PES)
    index_elementos_salida =0
    dict_bolsa ={}
    df_salidas=pd.DataFrame()
    df_entradas=pd.DataFrame()

    while index_elementos_salida != len(elementos_salida):
        current_elemento =  elementos_salida[index_elementos_salida]
        print(PES,"Salida",current_elemento.Id)
        current_dict = {
                "Status":current_elemento.IdStatus.Descripcion,
                "Ctd Salida":current_elemento.CtdSalida,
                "IDMO":current_elemento.IDPMO,
                "PES":PES,
                "Sitio":current_elemento.SitioDestino.Nombre,
                "Fecha de salida":str(current_elemento.IdOrdenSalidaApr.FechaSalida),
                "Caja":current_elemento.Caja,
                "Guia":current_elemento.GuiaEnvio,
                "Folio salida":current_elemento.IdOrdenSalidaApr.Folio,
                "Destinatario":current_elemento.Destinatario,
            }

        if current_elemento.SitioOcurre != None:
            current_dict['DHL'] = current_elemento.SitioOcurre.CodigoPostal

        if "APR" in current_elemento.IdInventario.Etiqueta:
            apr  = CatalogoAPR.objects.get(Etiqueta = current_elemento.IdInventario.Etiqueta)
            current_dict["APR"] = current_elemento.IdInventario.Etiqueta
            current_dict["Descripcion"] =apr.get_texto_breve()
            current_dict["Categoria"] = apr.get_texto_breve()
            titulo = current_elemento.IdInventario.Etiqueta

        else:
            current_dict["SKU"] = current_elemento.IdMat.SKU
            current_dict["Descripcion"] =  current_elemento.IdMat.TextoBreve
            current_dict["Categoria"] =  current_elemento.IdMat.IdCategoria.Nombre
            current_dict["No de serie"] =  current_elemento.IdInventario.NoSerie
            titulo =  current_elemento.IdMat.SKU

        df_salidas =  pd.concat([df_salidas,pd.DataFrame([current_dict])],ignore_index=True)

        if titulo not in dict_bolsa.keys():
            dict_bolsa[titulo] = elemento_bolsa(titulo=titulo)

        current_elemento_bolsa = dict_bolsa.get(titulo)

        if  current_elemento.IdStatus.Id ==15:
            current_elemento_bolsa.counter_cancelados_salida += current_elemento.CtdSalida
        elif  current_elemento.IdStatus.Id ==3 or current_elemento.IdStatus.Id ==4 or current_elemento.IdStatus.Id==1:
            current_elemento_bolsa.counter_pendiente_salida += current_elemento.CtdSalida
        elif  current_elemento.IdStatus.Id ==5:
            current_elemento_bolsa.counter_salida += current_elemento.CtdSalida
        else:
            pass
        
        index_elementos_salida+=1


    index_elementos_entrada =0

    while index_elementos_entrada !=len(elementos_entrada):
       
        current_elemento = elementos_entrada[index_elementos_entrada]
        print(PES,"Entrada",current_elemento.Id)
        current_dict={
            "SKU":current_elemento.IdMat.SKU,
            "Descripcion":current_elemento.IdMat.TextoBreve,
            "Categoria":current_elemento.IdMat.TextoBreve,
            "Status":current_elemento.IdStatus.Descripcion,
            "PES":PES,
            "Cantidad POD":current_elemento.CantidadEntrada,
            "Cantidad Inventariada":current_elemento.CantidadRecepcionada,
            "Orden Entrada":current_elemento.IdOrdenEntradaApr.Folio,
            "Caja":current_elemento.Caja.CodigoCaja,
            "Fecha entrada":str(current_elemento.IdOrdenEntradaApr.FechaEntrada)
        }

        if  current_elemento.IdMat.Tipo.Id == 3:
            titulo = current_elemento.IdMat.GrupoAPR.Etiqueta
            current_dict['APR'] =  current_elemento.IdMat.GrupoAPR.Etiqueta
        else:
            titulo =  current_elemento.IdMat.SKU
            current_dict["No de serie"] =  current_elemento.NoSerie

        df_entradas =  pd.concat([df_entradas,pd.DataFrame([current_dict])],ignore_index=True)

        if titulo not in dict_bolsa.keys():
            dict_bolsa[titulo] = elemento_bolsa(titulo=titulo)
        
        elem =  dict_bolsa.get(titulo)
        #Inventariado 
        if  current_elemento.IdStatus.Id == 10:

            if "APR" in titulo and current_elemento.CantidadEntrada > current_elemento.CantidadRecepcionada:
                elem.counter_inventariado_faltante += int(current_elemento.CantidadEntrada) - int(current_elemento.CantidadRecepcionada)
                elem.counter_inventariado +=int(current_elemento.CantidadRecepcionada)
                elem.counter_POD +=int(current_elemento.CantidadEntrada)

            else:
                elem.counter_inventariado +=int(current_elemento.CantidadRecepcionada)
                elem.counter_POD +=int(current_elemento.CantidadEntrada)


        #Pendiente validar existencia en caja
        elif current_elemento.IdStatus.Id == 6:
            elem.counter_pendiente_validar +=int(current_elemento.CantidadEntrada)
            elem.counter_POD +=int(current_elemento.CantidadEntrada)


        #Pendiente ubicacion tecnica
        elif current_elemento.IdStatus.Id == 8:
            elem.counter_POD +=int(current_elemento.CantidadEntrada)
            elem.counter_pendiente_inventariar +=int(current_elemento.CantidadRecepcionada)

        else:
            print("-----",current_elemento.Id)


        index_elementos_entrada+=1

    

    df_bolsa = pd.DataFrame()
    for x in dict_bolsa.values():
        df_bolsa =  pd.concat([df_bolsa,pd.DataFrame([x.__dict__])],ignore_index=True)


    df_bolsa['PES'] =  PES

    df_bolsa = df_bolsa.rename(columns={
        'sku':'SKU',
        'apr':'APR',
        'texto_breve':'Texto breve',
        'categoria':'Categoría',
        'counter_salida':'Salidas',
        'counter_pendiente_salida':'Pendiente Salida',
        'counter_inventariado':'Inventariado',
        'counter_pendiente_inventariar':'Pendiente inventariar',
        'counter_cancelados_salida':'Cancelados Salida',
        'counter_pendiente_validar':'Pendiente validar',
        'counter_POD':'Cantidad POD',
        'counter_inventariado_faltante':'Faltante Recepcionado'
        })


    return df_bolsa,df_salidas,df_entradas

def full_procedure(PES):
    df_bolsa = reporte_bolsa(PES)
    df_entradas = get_entradas_by_pes(PES)    
    df_salidas = get_salidas_by_pes(PES)

    with pd.ExcelWriter(f"/home/maynex/Desktop/{PES}.xlsx",engine='xlsxwriter') as writer:
        df_entradas.to_excel(writer,sheet_name="Entradas",index=False)
        df_salidas.to_excel(writer,sheet_name="Salidas",index=False)
        df_bolsa.to_excel(writer,sheet_name="Bolsa",index=False)

    return True
    


