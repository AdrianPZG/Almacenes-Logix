import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from .funcionesGlobales import *




def validacionesCambioEtiquetasSalidaApr(request,df,orden):
    columnasNecesarias = ['Id','Etiqueta sustituto'] 

    

    for col in columnasNecesarias:
        df[col] = df[col].fillna("empty")

    
    df['Id'] = df.apply(lambda row: sku_conversion(row),axis=1)
    df['Validaciones columna Id'] = df.apply(lambda row: validarColumnaObligatorio(row,df,'Id',orden),axis=1)
    df['Validaciones Etiqueta sustituto'] = df.apply(lambda row: validacionesEtiquetaSustituto(row,df),axis=1)
    df['Validacion final'] = df.apply(lambda row: validacionFinal(row),axis=1)

     
    filasConErrores = (df['Validacion final']==False).sum()

    if filasConErrores !=0:    
        return False,df
    else:
        return True,df



def validacionFinal(row):

    if row['Validaciones columna Id'] != "Aprobado" or "Aprobado" not in row['Validaciones Etiqueta sustituto']:
        return False
    else:
        return True


def sku_conversion(row):
    if row['Id']=="empty":
        return row['Id']
    else:    
        return int(row['Id'])

def validarColumnaObligatorio(row,df,col,orden):
    
    valor_repetido = (df[col]==row[col]).sum()
    if row[col]=="empty":
        return f"La columna {col} no puede estar vacia"
   
    if valor_repetido>1:
        return f"La columna {col} tiene valores repetidos"

    if MatOrdenSalidaApr.objects.filter(Id=row['Id']).exists():
        elemento = MatOrdenSalidaApr.objects.get(Id=row['Id'])
        if elemento.IdOrdenSalidaApr == orden:
            if elemento.IdStatus.Id ==1:
                if elemento.IdMat.Tipo.Nombre =="Item":
                    
                    return "Aprobado"

                else:
                    return f"El Id {row['Id']} no esta asociado a un Item"
            else:
                return f"El Id {row['Id']} no esta en estatus 'Pendiente recoleccion almacenista'"
        else:
            return f"El Id {row['Id']} no coincide con la orden actual"
    else:
        return "El Id no existe en el sistema"


def validacionesEtiquetaSustituto(row,df):
    
    col ="Etiqueta sustituto"
    
    if row['Id']=="empty":
        return "","La columna Id no puede estar vacia"

    elemento_plantilla =  MatOrdenSalidaApr.objects.get(Id=row['Id'])

    if row[col] !="empty":
        valor_repetido = (df[col]==row[col]).sum()
   
        if valor_repetido>1:
            return f"La columna {col} tiene valores repetidos"

        if InventarioAprovicionamiento.objects.filter(Etiqueta=row[col]).exists():
            elemento =  InventarioAprovicionamiento.objects.get(Etiqueta=row[col])
            
            if elemento.IdMat.SKU == elemento_plantilla.IdMat.SKU:

                if elemento.CtdDisponible == 1:

                    return f"Aprobado Libre {elemento.Id}"
                
                if MatOrdenReservaApr.objects.filter(Q(IdInventario__Id=elemento.Id)&Q(IdStatus__Id=13)).exists():
                    try:
                        elemento_en_reserva =  MatOrdenReservaApr.objects.get(Q(IdInventario__Id=elemento.Id)&Q(IdStatus__Id=13))
                        return f"Aprobado Reserva {elemento_en_reserva.Id}"
                    except:
                        return"Mas de un elemento en reserva, contacte al administrador"


                elif MatOrdenSalidaApr.objects.filter(Q(IdInventario__Id=elemento.Id)&Q(IdStatus__Id=1)).exists():

                    try:
                        elemento_en_salida =  MatOrdenSalidaApr.objects.get(Q(IdInventario__Id=elemento.Id)&Q(IdStatus__Id=1))
                        return f"Aprobado Salida {elemento_en_salida.Id}"
                    except:
                        return"Mas de un elemento en salida, contacte al administrador"


                else:
                    return f"La etiqueta {row[col]} ya esta ocupada"
            else:
                return "La etiqueta que ingresaste no corresponde con el elemento a sustituir"

        else:
            return f"La etiqueta {row[col]} no existe en sistema "
    
    else:
        return "Aprobado"
  


   
def swapEtiqueta(row,orden):
    
    if row['Validaciones Etiqueta sustituto'] =="Aprobado":
        return
    tipo_swap, id_target = row['Validaciones Etiqueta sustituto'].split()[1], row['Validaciones Etiqueta sustituto'].split()[2]
    
    registro_original_salida =  MatOrdenSalidaApr.objects.get(Id=row['Id'])
    etiqueta_original_inventario =  InventarioAprovicionamiento.objects.get(Id=registro_original_salida.IdInventario.Id)

    
    
    if tipo_swap == "Libre":
        etiqueta_sustituta_inventario =  InventarioAprovicionamiento.objects.get(Id=id_target)
        
        #Se incrementa en inventario la etiqueta original
        etiqueta_original_inventario.CtdDisponible= 1  
        etiqueta_original_inventario.CtdReservada=0
        etiqueta_original_inventario.save()
        
        #Se decrementa en inventario la etiqueta sustituta
        etiqueta_sustituta_inventario.CtdDisponible =0
        etiqueta_sustituta_inventario.CtdReservada = 1
        etiqueta_sustituta_inventario.save()

        #Se modifica el registro de la salida con el id de la etiqueta sustituta
        registro_original_salida.IdInventario =  etiqueta_sustituta_inventario
        registro_original_salida.save()
        

    elif tipo_swap=="Reserva":

        registro_reserva =  MatOrdenReservaApr.objects.get(Id=id_target)
        sustituto_inventario = InventarioAprovicionamiento.objects.get(Id=registro_reserva.IdInventario.Id)

        # se modifica el regsitro de la reserva con la etiqueta original de la salida
        registro_reserva.IdInventario =  etiqueta_original_inventario
        registro_reserva.save()

        # se modifica la salida con el registro de la reserva
        registro_original_salida.IdInventario =  sustituto_inventario
        registro_original_salida.save()

    
    elif tipo_swap=="Salida":
        
        registro_salida_sustitudo =  MatOrdenSalidaApr.objects.get(Id=id_target)
        sustituto_inventario =  InventarioAprovicionamiento.objects.get(Id=registro_salida_sustitudo.IdInventario.Id)

        registro_salida_sustitudo.IdInventario =  etiqueta_original_inventario
        registro_salida_sustitudo.save()

        registro_original_salida.IdInventario = sustituto_inventario 
        registro_original_salida.save()
    

    

    
        
        

    
        
    
