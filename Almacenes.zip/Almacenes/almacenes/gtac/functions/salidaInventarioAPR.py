import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum


def descuentoDeInventario(df,orden):
    
    for index,row in df.iterrows():

        


        materialEnOrdenSalida = MatOrdenSalidaApr.objects.get(Id=row['Id'])

        

        if materialEnOrdenSalida.IdStatus.Descripcion == "Pendiente salida":
            if pd.isnull(row['Caja']):
                return "El material con el registro "+str(row['Id'])+" no tiene valor en la columna Caja"
            else:

                if materialEnOrdenSalida.IdMat.Tipo.Nombre == "Item":

                        materialEnInventario = InventarioAprovicionamiento.objects.get(Identificador = row['Etiqueta'])

                        

                        materialEnOrdenSalida.Caja = str(row['Caja'])
                        materialEnOrdenSalida.IdInventario = materialEnInventario
                        materialEnOrdenSalida.IdStatus = EstatusMateriales.objects.get(Id=2)


                        materialEnOrdenSalida.save()

                        
                        materialEnInventario.CtdReservada = materialEnInventario.CtdReservada + materialEnOrdenSalida.CtdSalida
                        materialEnInventario.CtdDisponible = materialEnInventario.CtdDisponible - materialEnOrdenSalida.CtdSalida

                        materialEnInventario.save()


                else:
                    materialEnInventario = InventarioAprovicionamiento.objects.get(Id=materialEnOrdenSalida.IdInventario.Id)

                    if materialEnInventario.Identificador == row['Etiqueta']:
                        materialEnOrdenSalida.Caja = str(row['Caja'])
                        materialEnOrdenSalida.IdStatus = EstatusMateriales.objects.get(Id=2)
                        materialEnOrdenSalida.save()

                    else:
                        return "La etiqueta '"+row['Etiqueta']+"' no coincide con la registrada en sistema"
                    
        else:
            pass


    return True
            
        