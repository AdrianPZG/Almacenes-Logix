import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
import math
import json
from django.utils import timezone
from datetime import datetime


def crearSalidaDesdeReserva(PES,grupos,fechaSalida,request):

    nuevaSalida = crearOrdenSalida(request,fechaSalida)
    nuevo_registro_salida_pes = SalidasAprPES(
        IdSalidaApr = nuevaSalida,
        IdPES = CatalogoPES.objects.get(PES=PES)
    )
    nuevo_registro_salida_pes.save()

    for i in grupos:
        materiales_en_peticion = i['materiales']
        
        for mat in materiales_en_peticion:

            materiales_por_grupo = MatOrdenReservaApr.objects.filter(Q(IdStatus__Id=13)&Q(IDPMO__OS=mat['IDPMO'])&Q(SitioDestino__Nombre=mat['SitioDestino']))
           
            crearMaterialEnMatOrdenSalida(materiales_por_grupo,nuevaSalida,mat,i)
            crearRegistrosBolsa(materiales_por_grupo,nuevaSalida)

            for n in materiales_por_grupo:
                n.CtdDisponible = 0
                n.CtdUtilizada = n.CtdReservada
                n.IdStatus = EstatusMateriales.objects.get(Id=14)
                n.IdSalidaApr = nuevaSalida
                n.save()

    return nuevaSalida.Folio

def crearRegistrosBolsa(materiales,salida):

    for i in materiales:
        nuevo_material = BolsaMaterialesByOs(
            IdMat = i.IdMat,
            IdSalida=salida,
            QtySolicitada=i.CtdReservada,
            IdOS=i.IDPMO,
            IdStatus = EstatusMateriales.objects.get(Id=11),
        )
        nuevo_material.save()



def crearMaterialEnMatOrdenSalida(materiales,salida,mat,datosGrupo):

    for i in materiales:

        nuevo = MatOrdenSalidaApr(
            IdMat=i.IdMat,
            IdOrdenSalidaApr=salida,
            IdInventario=i.IdInventario,
            IdStatus=EstatusMateriales.objects.get(Id=1),
            CtdSalida=i.CtdReservada,
            IDPMO=mat['IDPMO'],
            SitioDestino=Sitios.objects.get(Nombre=mat['SitioDestino'])
        )

        if datosGrupo['tipo'] == "Recoleccion en almacen":
            nuevo.RecolectaEnAlmacén = datosGrupo['nombreRecolector']

        elif datosGrupo['tipo']=="Envio Ocurre":
            nuevo.Destinatario = datosGrupo['nombreDestinatario']
            nuevo.SitioOcurre = SitiosOcurre.objects.get(Id=datosGrupo['OcurreId'])
            pass
        nuevo.save()




def crearOrdenSalida(request,fechaSalida):
    usuario = User.objects.get(username = request.user)
    
    aprobador = Profile.objects.get(user=usuario)
    
    # Normalizar fechaSalida a datetime consciente de zona horaria
    fecha_salida_dt = None
    try:
        if not fechaSalida:
            fecha_salida_dt = timezone.now()
        elif isinstance(fechaSalida, datetime):
            fecha_salida_dt = fechaSalida
        elif isinstance(fechaSalida, str):
            try:
                fecha_salida_dt = datetime.fromisoformat(fechaSalida)
            except Exception:
                try:
                    fecha_salida_dt = datetime.strptime(fechaSalida, "%Y-%m-%d")
                except Exception:
                    fecha_salida_dt = timezone.now()
        else:
            fecha_salida_dt = timezone.now()
    except Exception:
        fecha_salida_dt = timezone.now()

    if isinstance(fecha_salida_dt, datetime) and fecha_salida_dt.tzinfo is None:
        fecha_salida_dt = timezone.make_aware(fecha_salida_dt)

    nuevaOrdenSalida = OrdenesSalidaApr(
        CreadoPor = usuario,
        FechaSalida = fecha_salida_dt,
        Almacen = Sitios.objects.get(IdSitio=181),
        IdStatus = Estatus.objects.get(Id=15),
        Aprobador = aprobador.Area.Aprovador
    )

    nuevaOrdenSalida.save()

    folio=str(nuevaOrdenSalida.Id).zfill(5)

    nuevaOrdenSalida.Folio = "SAPR-"+folio
    nuevaOrdenSalida.save()

    return nuevaOrdenSalida




