import pandas as pd
from gtac.models import *



class NewMaterial:
    def __init__(self,sku,cantidad,idPMO,sitioDestino,SitioOcurre,idInv="No aplica"):
        self.SKU=sku
        self.Cantidad=cantidad   
        self.IdPMO=idPMO
        self.SitioDestino=sitioDestino
        self.SitioOcurre=SitioOcurre
        self.IdInv=idInv
        

def desgloceMateriales(df,almacen):
    
    materiales = []
    
    for index,row in df.iterrows():

       

            elemento =  Materiales.objects.get(SKU=row['SKU'])
            if elemento.Tipo.Nombre=="Consumible":
        
                        
                materialesInventario = InventarioAprovicionamiento.objects.filter(IdMat__SKU=row['SKU']).filter(Almacen=almacen).exclude(CtdDisponible=0)
                cantidadOriginal = row['Cantidad a retirar']

                for i in materialesInventario:
                    
                    
                    if cantidadOriginal > i.CtdDisponible:
                        cantidadOriginal = cantidadOriginal-i.CtdDisponible
                        material = NewMaterial(row['SKU'],i.CtdDisponible,row['Id PMO'],row['Sitio destino'],row['Sitio ocurre/Nombre recolector'])
                        materiales.append(material)
                        i.CtdReservada=i.CtdReservada + i.CtdDisponible
                        i.CtdDisponible=0
                        i.save()
                        
                        

                    else:
                        material = NewMaterial(row['SKU'],cantidadOriginal,row['Id PMO'],row['Sitio destino'],row['Sitio ocurre/Nombre recolector'])
                        materiales.append(material)
                        i.CtdDisponible=i.CtdDisponible - cantidadOriginal
                        i.CtdReservada=i.CtdReservada + cantidadOriginal
                        i.save()
                        
                        break
                        
                        

            else:
                for i in range(row['Cantidad a retirar']):
                    elemento2=InventarioAprovicionamiento.objects.filter(IdMat=elemento).filter(Almacen=almacen).exclude(CtdDisponible=0).first()
                    elemento2.CtdDisponible = 0
                    elemento2.CtdReservada = 1
                    elemento2.save()
                    material = NewMaterial(row['SKU'],1,row['Id PMO'],row['Sitio destino'],row['Sitio ocurre/Nombre recolector'],elemento2.Id)
                    materiales.append(material)
                  
                

        

    return materiales
    