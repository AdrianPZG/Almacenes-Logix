from gtac.models import *
from django.db.models import Q
import pandas as pd
import sys, os
from .funcionesGlobales import *
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
from django.db.models import Q,Count,Sum
import json


# -----------------------------------------------------------------------------------
# abajo estan las funciones para la validacion de la entrada

def descontar_materiales_bolsa_entrada_apr(request,df):

    esInterna = True

    if "PES-" in request.headers['PES']: esInterna = False

    
    df_agrupado = df.groupby(['NO DE PARTE'])['QTY'].agg('sum').reset_index()

    lista_elementos_en_df = df_agrupado.values.tolist()

    for i in lista_elementos_en_df:
        
        sku=i[0]
        elementos_archivo=i[1]

        sku_en_sistema = Materiales.objects.get(SKU=sku)

  
        if sku_en_sistema.Tipo.Nombre == "Item":


            
            if not esInterna:
               
                elementos_en_bolsa = BolsaMaterialesByOs.objects.filter(IdMat__SKU=sku,IdStatus__Id=11,IdOS__IdPES__PES=request.headers['PES'])

            else:
               
                elementos_en_bolsa = BolsaMaterialesByOs.objects.filter(IdMat__SKU=sku,IdStatus__Id=11,IdOS__OS=request.headers['PES'])

            
            if len(list(elementos_en_bolsa)) == 0:
                continue

            rango=0            

            if len(elementos_en_bolsa) >= elementos_archivo:
                rango = elementos_archivo
            else:
                rango= len(elementos_en_bolsa)


            for e in range(0,rango):
                
               
                mat_bolsa_a_editar = elementos_en_bolsa[e]

                mat_bolsa_a_editar.IdStatus = EstatusMateriales.objects.get(Id=12)

                mat_bolsa_a_editar.QtyAbastecida = 1

                mat_bolsa_a_editar.save()

        elif sku_en_sistema.Tipo.Nombre == "Agrupado":
            

            elementos_en_el_apr = Materiales.objects.filter(GrupoAPR__Id=sku_en_sistema.GrupoAPR.Id).values('SKU')

            skus_in_apr= []

            for e in elementos_en_el_apr:
                skus_in_apr.append(e['SKU'])

           
            if not esInterna:
               
                elementos_en_bolsa = BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdStatus__Id=11,IdOS__IdPES__PES=request.headers['PES'])
                qty_solicitada_en_bolsa =  BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdOS__IdPES__PES=request.headers['PES']).exclude(IdStatus__Id=15).aggregate(Sum('QtySolicitada'))
                qty_abastecida_en_bolsa =  BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdOS__IdPES__PES=request.headers['PES']).exclude(IdStatus__Id=15).aggregate(Sum('QtyAbastecida'))

            else:
                elementos_en_bolsa = BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdStatus__Id=11,IdOS__OS=request.headers['PES'])
                qty_solicitada_en_bolsa =  BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdOS__OS=request.headers['PES']).exclude(IdStatus__Id=15).aggregate(Sum('QtySolicitada'))
                qty_abastecida_en_bolsa =  BolsaMaterialesByOs.objects.filter(IdMat__SKU__in=skus_in_apr,IdOS__OS=request.headers['PES']).exclude(IdStatus__Id=15).aggregate(Sum('QtyAbastecida'))


            if len(list(elementos_en_bolsa)) == 0:
                continue

            #Si la cantidad abastecida en la bolsa es menor a la que fue solicitada
            
            if qty_abastecida_en_bolsa['QtyAbastecida__sum'] < qty_solicitada_en_bolsa['QtySolicitada__sum']: 
                cantidad_por_abastecer_bolsa = qty_solicitada_en_bolsa['QtySolicitada__sum'] - qty_abastecida_en_bolsa['QtyAbastecida__sum']

                cantidadPorAbastecerArchivo = elementos_archivo

                for apr_en_bolsa in elementos_en_bolsa:
                    
                    
                    if cantidadPorAbastecerArchivo > 0:
                    
                        por_abastecer_registro_bolsa = apr_en_bolsa.QtySolicitada - apr_en_bolsa.QtyAbastecida

                        if cantidadPorAbastecerArchivo <= por_abastecer_registro_bolsa:


                            apr_en_bolsa.QtyAbastecida = apr_en_bolsa.QtyAbastecida + cantidadPorAbastecerArchivo
                            apr_en_bolsa.save()
                            cantidadPorAbastecerArchivo = cantidadPorAbastecerArchivo - por_abastecer_registro_bolsa
                            
                        if cantidadPorAbastecerArchivo > por_abastecer_registro_bolsa: 

                            apr_en_bolsa.QtyAbastecida = apr_en_bolsa.QtyAbastecida + por_abastecer_registro_bolsa
                            apr_en_bolsa.save()
                            cantidadPorAbastecerArchivo = cantidadPorAbastecerArchivo - por_abastecer_registro_bolsa
                           



                        if apr_en_bolsa.QtyAbastecida == apr_en_bolsa.QtySolicitada:
                            apr_en_bolsa.IdStatus = EstatusMateriales.objects.get(Id=12)
                            apr_en_bolsa.save()
       


def es_apr(sku):

    if not Materiales.objects.filter(SKU=sku).exists(): raise ValueError(f"El modelo {sku} no existe en el sistema")



    material = Materiales.objects.get(SKU=sku)


    if material.Tipo.Nombre == "Agrupado":
        return material.GrupoAPR.Etiqueta
    elif material.Tipo.Nombre == "Consumible":
        raise ValueError(f"El modelo {sku} es consumible, contacte al administrador ")    
  
                            
def validar_discrepancias_en_la_bolsa(df,orden_compra):
    
    
    columnasConCamposVacios = df.isna().sum()
    tiposDeColumna = df.dtypes

    columnasNecesarias = ['NO DE PARTE','QTY','CAJA','NO DE SERIE','GUIA/TRANSP.']
    arrayCamposVacios = ['CAJA','QTY','NO DE PARTE']
    arrayCamposNumericos = ['QTY']
   


    esInterna = validarOrdenCompra(orden_compra)
    validarColumnasNecesarias(columnasNecesarias,df)
    validarCamposVaciosEnColumna(arrayCamposVacios,df)
    validarColumnaNumerica(arrayCamposNumericos,df)
    df['APR']= df.apply(lambda row: es_apr(str(row['NO DE PARTE']).replace(".0", "")), axis=1)
    validarExistenciaCajas(df)
    validarDuplicadoNoSerieArchivoComas(df)

    

    
    array_discrepancias,numero_discrepancias = validarMaterialesEnBolsa(orden_compra,df,esInterna)

    

    return array_discrepancias,numero_discrepancias,esInterna

def nueva_entrada_APR(PES,df,fechaEntrada,almacen,request):

    
    arrayToString=['NO DE PARTE','NO DE SERIE']
    
    df = stringifyColumn(arrayToString,df)

    df['GUIA/TRANSP.'] = df['GUIA/TRANSP.'].fillna('')
    
    skusItems, skusAgrupables =  separarSKUs(df['NO DE PARTE'].unique())

    itemsEnOrden = validacionesItems(df,skusItems)

    agrupablesEnOrden = validacionesAgrupables(df,skusAgrupables)

    folio = crearOrdenEntradaApr(itemsEnOrden,agrupablesEnOrden,fechaEntrada,almacen,df,PES,request)

    
    return folio


def crearOrdenEntradaApr(itemsEnOrden,agrupablesEnOrden,fechaEntrada,almacen,df,PES,request):

    usuario = User.objects.get(username=request.user)
    profile = Profile.objects.get(user=usuario)

    
    nuevaOrdenEntrada = OrdenesEntradaApr(
        FolioOC = PES,
        CreadoPor =usuario,
        Aprobador =profile.Area.Aprovador,
        Almacen = Sitios.objects.get(IdSitio = almacen),
        IdStatus = Estatus.objects.get(Id=17),
        FechaEntrada = fechaEntrada

    )

    nuevaOrdenEntrada.save()
    crearCajas(df,nuevaOrdenEntrada)


    for i in itemsEnOrden:

        
        material = MatOrdenEntradaApr(
            IdMat = i.SKU,
            IdOrdenEntradaApr=nuevaOrdenEntrada,
            CantidadEntrada=i.Cantidad,
            Caja=CajasEntradaApr.objects.get(Q(CodigoCaja=i.Caja) & Q(IdOrdenEntradaApr=nuevaOrdenEntrada)),
            Guia=i.NoGuia,
            IdStatus = EstatusMateriales.objects.get(Id=6)
        )


        if i.SKU.Activo:
            material.NoSerie=i.NoSerie

        material.save()

    for i in agrupablesEnOrden:

        
        material = MatOrdenEntradaApr(
            IdMat = i.SKU,
            IdOrdenEntradaApr=nuevaOrdenEntrada,
            CantidadEntrada=i.Cantidad,
            Caja=CajasEntradaApr.objects.get(Q(CodigoCaja=i.Caja) & Q(IdOrdenEntradaApr=nuevaOrdenEntrada)),
            Guia=i.NoGuia,
            IdStatus = EstatusMateriales.objects.get(Id=6),
            IdAPR = i.SKU.GrupoAPR

        )

        material.save()

    enAl = Profile.objects.get(IdRol__IdRol=3)
    correo([enAl.user.email,nuevaOrdenEntrada.CreadoPor.email],"Nueva orden de entrada: {}".format(nuevaOrdenEntrada.Folio),nuevaOrdenEntrada)
    return nuevaOrdenEntrada.Folio



            
def validarMaterialesEnBolsa(PES,df,esInterna):

  
    skus_faltantes_en_bolsa=[]

    numero_discrepancias=0
    array_discrepancias=[]
    faltante = lambda a,b: a-b 

    skus_en_archivo = df['NO DE PARTE'].unique().tolist()

    if not esInterna:

        for i in skus_en_archivo:

            if not BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES = PES).filter(IdStatus__Id=11,IdMat__SKU=i).exists(): skus_faltantes_en_bolsa.append(i)
       

        materiales_en_la_bolsa_por_pes_item = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES = PES).filter(IdStatus__Id=11,IdMat__Tipo__Nombre="Item").values('IdMat__SKU').order_by('IdMat__SKU').annotate(suma=Sum('QtySolicitada'))
        materiales_en_la_bolsa_por_pes_agrupados = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES = PES).filter(IdStatus__Id=11,IdMat__Tipo__Nombre="Agrupado").values('IdMat__GrupoAPR__Etiqueta').order_by('IdMat__GrupoAPR__Etiqueta').annotate(suma=Sum('QtySolicitada'),suma2=Sum('QtyAbastecida'))

    else:

       
        for i in skus_en_archivo:

            if not BolsaMaterialesByOs.objects.filter(IdOS__OS = PES).filter(IdStatus__Id=11,IdMat__SKU=i).exists(): skus_faltantes_en_bolsa.append(i)
       

        materiales_en_la_bolsa_por_pes_item = BolsaMaterialesByOs.objects.filter(IdOS__OS = PES).filter(IdStatus__Id=11,IdMat__Tipo__Nombre="Item").values('IdMat__SKU').order_by('IdMat__SKU').annotate(suma=Sum('QtySolicitada'))
        materiales_en_la_bolsa_por_pes_agrupados = BolsaMaterialesByOs.objects.filter(IdOS__OS = PES).filter(IdStatus__Id=11,IdMat__Tipo__Nombre="Agrupado").values('IdMat__GrupoAPR__Etiqueta').order_by('IdMat__GrupoAPR__Etiqueta').annotate(suma=Sum('QtySolicitada'),suma2=Sum('QtyAbastecida'))



    for mat_bolsa in materiales_en_la_bolsa_por_pes_item:
        mat_df =  df.loc[(df['NO DE PARTE']==mat_bolsa['IdMat__SKU'])]['QTY'].sum()
        mate = Materiales.objects.get(SKU=mat_bolsa['IdMat__SKU'])

        if mat_bolsa['suma'] < mat_df:
            discrepancia = {}
            discrepancia['sku']=mat_bolsa['IdMat__SKU']
            discrepancia['desc']=mate.TextoBreve
            discrepancia['tipo']="Sobrante en la entrada"
            discrepancia['qty']=faltante(mat_df,mat_bolsa['suma'])
            array_discrepancias.append(discrepancia)
            numero_discrepancias+=1

        elif mat_bolsa['suma'] > mat_df:
            discrepancia = {}
            discrepancia['sku']=mat_bolsa['IdMat__SKU']
            discrepancia['desc']=mate.TextoBreve
            discrepancia['tipo']="Faltante en la entrada"
            discrepancia['qty']=faltante(mat_bolsa['suma'],mat_df)
            array_discrepancias.append(discrepancia)
            numero_discrepancias+=1


    for mat_bolsa in materiales_en_la_bolsa_por_pes_agrupados:
       
       
        
        mat_df =  df.loc[(df['APR']==mat_bolsa['IdMat__GrupoAPR__Etiqueta'])]['QTY'].sum()
        cantidad_real=mat_bolsa['suma']-mat_bolsa['suma2']

        apr = CatalogoAPR.objects.get(Etiqueta = mat_bolsa['IdMat__GrupoAPR__Etiqueta'])

        if apr.TipoAgrupacion == "Cantidad":
            texto = apr.SKUPadre.TextoBreve
            print(f"{mat_bolsa}  Cantidad  {texto}")
        else:
            texto = apr.Texto
            print(f"{mat_bolsa}  SKU {texto}")


        if cantidad_real < mat_df:
            discrepancia = {}
            discrepancia['sku']=mat_bolsa['IdMat__GrupoAPR__Etiqueta']
            discrepancia['desc']=texto
            discrepancia['tipo']="Sobrante en la entrada"
            discrepancia['qty']=faltante(mat_df,cantidad_real)
            array_discrepancias.append(discrepancia)
            numero_discrepancias+=1

        elif cantidad_real > mat_df:
            discrepancia = {}
            discrepancia['sku']=mat_bolsa['IdMat__GrupoAPR__Etiqueta']
            discrepancia['desc']=texto
            discrepancia['tipo']="Faltante en la entrada"
            discrepancia['qty']=faltante(cantidad_real,mat_df)
            array_discrepancias.append(discrepancia)
            numero_discrepancias+=1



    for i in skus_faltantes_en_bolsa:

        newdf = df.loc[df['NO DE PARTE']==i]

        suma = newdf['QTY'].sum()
        mate = Materiales.objects.get(SKU=i)

        discrepancia = {}
        discrepancia['sku']=i
        discrepancia['desc']=mate.TextoBreve
        discrepancia['tipo']="Sobrante en la entrada"
        discrepancia['qty']=suma
        array_discrepancias.append(discrepancia)
        numero_discrepancias+=1


    

    return array_discrepancias,numero_discrepancias

        

def validarOrdenCompra(PES):
    

    esInterna = True
    keysPosibles = ['GTAC-','OPS-','NOC-','PES-']
   
    if not any([x in PES for x in keysPosibles]): raise ValueError("Los unicos formatos aceptables son PES,GTAC,OPS,NOC")

   
    if "PES-" in PES:
        esInterna = False

   
    if not esInterna:

        if not CatalogoPES.objects.filter(PES=PES).exists():
        
            nuevaPES=CatalogoPES(
                PES=PES
            )
            nuevaPES.save()
    else:

        if not CatalogoOS.objects.filter(OS=PES).exists(): raise ValueError("El folio interno '{}' no existe en el sistema".format(PES))
    
    return esInterna

    

def crearCajas(df,orden):
    cajas = df['CAJA'].unique()

    for i in cajas:
        nuevaCaja = CajasEntradaApr(
            IdOrdenEntradaApr=orden,
            CodigoCaja=i,
            Estatus="Pendiente verificación"
        )
        nuevaCaja.save()



def correo(destinatarios,asunto,o):

    contenido=" <h3>Datos generales:</h3> <p>Folio: {}</p>  <p>Creado por: {} {} </p>  <p>Fecha de creación: {}</p>  <p>Fecha de entrada: {}</p> {} ".format(o.Folio,o.CreadoPor.first_name,o.CreadoPor.last_name,o.FechaCreacion,o.FechaEntrada,"<p>Para revisar la orden ingresa a: </p><a href='https://logix.gtac.com.mx'>GTAC Almacenes</a>")

    message = Mail(
        from_email='notificaciones@gtac.com.mx',
        to_emails=destinatarios,
        subject=asunto,
        html_content=contenido)

    sg = SendGridAPIClient("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")
    response = sg.send(message)

            
       


