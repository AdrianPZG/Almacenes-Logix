import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum

def validacionIdsSalidaAPR(df,orden):
    materialesList=[]
    materiales = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).values('Id')
    for i in materiales:
        materialesList.append(i['Id'])
    
    
    IdsEnCSV = df['Id'].tolist()


    if len(materiales) ==  len(IdsEnCSV):
        duplicados = df[df['Id'].duplicated()==True]
        if len(duplicados.index) == 0:

            df_final = df[df['Id'].isin(materialesList)==False]
            
            if len(df_final.index) == 0:
                pass
            else:
                noEnLaOrden = df_final['Id'].tolist()
                listToStr = ' '.join([str(elem) for elem in noEnLaOrden])
                
                return "Los Ids ("+listToStr+") no corresponden a la orden "+orden.Folio

        else:
            return "El archivo tiene Ids duplicados"

    else:
        return "La cantidad de registros en el archivo no coincide con la cantidad de registros en el sistema"

        
    


    return True 


def validacionEscaneoEtiquetas(df,orden):


    sinEtiqueta = df[df['Escanea la etiqueta'].isnull()]


    if len(sinEtiqueta.index) == 0:
        
        etiquetas = df[['Id','Escanea la etiqueta']]

        for index,row in etiquetas.iterrows():

            materialEnInv = MatOrdenSalidaApr.objects.get(Id=row['Id'])
            if materialEnInv.IdInventario.Etiqueta == row['Escanea la etiqueta']:
                pass
            else:
                return "La etiqueta escaneada del registro "+str(row['Id'])+" no coincide con la del sistema"


    else:
        return "Todos los registros deben de tener un valor en la columna 'Escanea la etiqueta'"
   
    

    return True


def validacionCajas(df,orden):
    
    materialesList=[]
    materiales = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).exclude(SitioOcurre=None).values('Id')

    for i in materiales:
        materialesList.append(i['Id'])
    
    
    necesitanCaja = df[df['Id'].isin(materialesList)]

    sinCaja=necesitanCaja[necesitanCaja['Caja'].isnull()]


    if len(sinCaja.index) == 0:
        pass

    else:
        listToStr = ' '.join([str(elem) for elem in materialesList])
        return "Los registros ("+listToStr+") necesitan un valor en la columna 'Caja'"
    
    return True


def validacionNumGuia(df,orden):
    materialesList=[]
    materiales = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).exclude(SitioOcurre=None).values('Id')

    for i in materiales:
        materialesList.append(i['Id'])

    necesitanGuia = df[df['Id'].isin(materialesList)]

    sinGuia=necesitanGuia[necesitanGuia['Guía de envio'].isnull()]

    if len(sinGuia.index) == 0:
        pass

    else:
        listToStr = ' '.join([str(elem) for elem in materialesList])
        return "Los registros ("+listToStr+") necesitan un valor en la columna 'Guía de envio'"
    
    return True


