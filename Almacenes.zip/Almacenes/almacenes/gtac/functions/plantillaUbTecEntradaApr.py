from gtac.models import *
from django.db.models import Q
import pandas as pd
import sys, os
from .pandasValidationOrdenEntrada import separarSKUs


def find_technical_location_by_sku(row):
    

    
        
    material = Materiales.objects.get(SKU = row['IdMat__SKU'])
    if material.Tipo.Nombre == "Item": 
        
        
        inventory_record = InventarioAprovicionamiento.objects.filter(IdMat__SKU=str(row['IdMat__SKU'])).exclude(IdUbTec=None).first()
        if inventory_record == None:
            return "No hay ubicación tecnica sugerida"



    else:

        print("No es Item")


    return inventory_record.IdUbTec.Descripcion




def getPlantillaUbTecEntradaApr(orden,request):

        
    df = pd.DataFrame(list(MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr= orden).filter(IdInventario__Estatus="Pendiente ubicación Tecnica").values(
                'Id',
                'IdMat__SKU',
                'IdMat__TextoBreve',
                'NoSerie',
                'IdInventario__Etiqueta',
                'IdAPR__Etiqueta',
                'CantidadEntrada',
                'Caja__CodigoCaja',
                'Guia',
                'IdStatus__Descripcion',
    )))
    
    df['Ubicacion tecnica sugerida'] = df.apply(find_technical_location_by_sku,axis=1)
    
    
            
    

    return df
        

   