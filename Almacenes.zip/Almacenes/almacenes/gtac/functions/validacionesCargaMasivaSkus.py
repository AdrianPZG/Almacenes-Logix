import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from .funcionesGlobales import *



def validacionesArchivoSKUS(request,df):
    columnasNecesarias = ['SKU','Item/APR','Categoria',"EsActivo","TextoBreve","NuevoAPR","TipoAPR","APRAsociado"]

    for col in columnasNecesarias:
        df[col] = df[col].fillna("empty")
    
    
    df['SKU'] = df.apply(lambda row: sku_conversion(row),axis=1)

    for col in columnasNecesarias:
        df[col] = df[col].apply(lambda x: x.strip())

    df['Columna SKU,Categoria,TextoBreve obligatoria'] = df.apply(lambda row: validarColumnaSKUObligatorio(row),axis=1)
    df['Existe SKU en sistema'] = df.apply(lambda row: validarNoExistenciaDeSKU(row,df),axis=1)
    df['Existe Categoria en sistema']=df.apply(lambda row: validarExistenciaCategoria(row),axis=1)
    df['Columna Item/APR opcion valida']=df.apply(lambda row: validarColumnaIA(row),axis=1)
    df['Columna EsActivo opcion valida']=df.apply(lambda row: validarColumnaEsActivo(row),axis=1)
    df['Columna NuevoAPR opcion valida']=df.apply(lambda row: validarColumnaNuevoAPR(row),axis=1)
    df['Columna TipoAPR opcion valida']=df.apply(lambda row: validarColumnaTipoAPR(row),axis=1)
    df['Columna APRAsociado validacion']=df.apply(lambda row: validarAPRAsociado(row),axis=1)
    
    df['Validacion final'] = df.apply(lambda row: validacionFinal(row),axis=1)
    
    filasConErrores = (df['Validacion final']==False).sum()

    if filasConErrores !=0:    
        return False,df
    else:
        return True,df


def sku_conversion(row):
    if row['SKU']=="empty":
        return row['SKU']
    else:    
        return str(row['SKU'])


def validacionFinal(row):
    if row['Columna APRAsociado validacion']!="Aprobado" or   row['Columna TipoAPR opcion valida']!="Aprobado" or  row['Columna NuevoAPR opcion valida']!="Aprobado" or  row['Columna SKU,Categoria,TextoBreve obligatoria'] != "Aprobado" or row['Existe SKU en sistema']!="Aprobado" or row['Existe Categoria en sistema']!="Aprobado" or row['Columna Item/APR opcion valida']!="Aprobado" or row["Columna EsActivo opcion valida"]!="Aprobado":
        return False
    else:
        return True


def validarColumnaSKUObligatorio(row):
    if row['SKU']=="empty" or row['Categoria']=="empty" or row['TextoBreve']=="empty" or row['Item/APR'] == "empty" or row['EsActivo'] =="empty":
        return "Las columnas SKU,Item/APR,Categoria,EsActivo,TextoBreve son obligatorias"
    else:
        return "Aprobado"

def validarColumnaEsActivo(row):

    if row['EsActivo']=="empty":
        return "La columna EsActivo no puede estar vacia"


    if row['EsActivo'] == "Si" or row['EsActivo'] == "No":
        return "Aprobado"
    else:
        return "El valor debe ser Si o No"


def validarColumnaIA(row):

    if row['Item/APR']=="empty":
        return "La columna Item/APR no puede estar vacia"
   

    if row['Item/APR'] == "Item":
        if row['NuevoAPR']!="empty" or row['TipoAPR']!="empty" or row['APRAsociado']!="empty":
            return "Las columnas NuevoAPR,TipoAPR,APRAsociado deben estar vacias"
        else:
            return "Aprobado"

    elif row['Item/APR'] == "APR":
        return "Aprobado"
    else:
        return "El valor debe ser Item o APR"



def validarColumnaNuevoAPR(row):
    if row['Item/APR'] == "APR":
        if row['NuevoAPR'] == "Si":
            if row['TipoAPR'] =="empty":
                return "La columna TipoAPR no puede estar vacia"
            else:
                return "Aprobado"

        elif row['NuevoAPR']=="No":
            if row['TipoAPR'] =="empty" and row['APRAsociado'] !="empty":
                return "Aprobado"
            else:
                return"La columna TipoAPR tiene que estar vacia y la columna APRAsociado debe tener un valor"
        else:
            return "El valor debe ser Si o No"
    else:
        return "Aprobado"


def validarColumnaTipoAPR(row):
    if row['Item/APR'] == "APR":

        if row['NuevoAPR'] == "Si":

            if row['TipoAPR'] == "Cantidad" or row['TipoAPR'] =="SKU":
                return "Aprobado"
            else:
                return "La columna TipoAPR debe ser SKU o Cantidad"

        elif row['NuevoAPR']=="No":
            return "Aprobado"

        else:
            return "La columna NuevoAPR debe tener un valor valido"
    else:
        return "Aprobado"


def validarAPRAsociado(row):
    if row['Item/APR'] == "APR":

        if row['NuevoAPR'] == "No":
            
            if CatalogoAPR.objects.filter(Etiqueta=row['APRAsociado']).exists():

                if CatalogoAPR.objects.get(Etiqueta=row['APRAsociado']).TipoAgrupacion =="SKU":
                    return "Aprobado"
                else:
                    return "El tipo de agrupacion del APR debe ser SKU"
            else:
                return f"El APR {row['APRAsociado']} no existe en el sistema"

        elif row['NuevoAPR']=="Si":
            return "Aprobado"

        else:
            return "La columna NuevoAPR debe tener un valor valido"
    else:
        return "Aprobado"





def validarExistenciaCategoria(row):
    if row['Categoria']=="empty":
        return "La columna Categoria no puede estar vacia"

    if Categorias.objects.filter(Nombre=row['Categoria']).exists():
        return "Aprobado"
    else:
        return "La categoria no existe en el sistema"



def validarNoExistenciaDeSKU(row,df):
    sku_repetido = (df['SKU']==row['SKU']).sum()
 
    if row['SKU']=="empty":
        return "La columna SKU no puede estar vacia"
   
    if sku_repetido>1:
        return f"El sku {row['SKU']} esta repetido con la columna SKU"

    if Materiales.objects.filter(SKU=row['SKU']).exists():
        return "El SKU ya existe en el sistema"
    else:
        return "Aprobado"





def crearSKUsCargaMasiva(df):
    df['Estado creacion'] = df.apply(lambda row: iteracionCrearSKUS(row),axis=1)

def iteracionCrearSKUS(row):
    activo = True
    last_element = Materiales.objects.latest('IdMat')
    
    if row['EsActivo'] =="No":
        activo=False

    if row['Item/APR'] =="Item":
        nuevoElemento =  Materiales(
                IdMat=(int(last_element.IdMat))+1,
                SKU=row['SKU'],
                TextoBreve = row['TextoBreve'],
                IdCategoria = Categorias.objects.get(Nombre=row['Categoria']),
                Tipo=CatTipoMat.objects.get(Nombre="Item"),
                Activo =activo,
                )
        nuevoElemento.save()
    else:
        if row['NuevoAPR'] =="No":
            apr_asociado =  CatalogoAPR.objects.get(Etiqueta=row['APRAsociado'])
            nuevoElemento =  Materiales(
                IdMat=(int(last_element.IdMat))+1,
                SKU=row['SKU'],
                TextoBreve = row['TextoBreve'],
                IdCategoria = Categorias.objects.get(Nombre=row['Categoria']),
                Tipo=CatTipoMat.objects.get(Nombre="Agrupado"),
                Activo =activo,
                GrupoAPR=apr_asociado
                )
            nuevoElemento.save()
        else:
            if row['TipoAPR'] =="SKU":
                newId,APR = returnValidAPR()
                
                nuevoAPR=CatalogoAPR(
                    Id=newId,
                    Etiqueta=APR,
                    Texto = row['TextoBreve'],
                    TipoAgrupacion ="SKU",
                ) 
                nuevoAPR.save()

                nuevoElemento =  Materiales(
                    IdMat=(int(last_element.IdMat))+1,
                    SKU=row['SKU'],
                    TextoBreve = row['TextoBreve'],
                    IdCategoria = Categorias.objects.get(Nombre=row['Categoria']),
                    Tipo=CatTipoMat.objects.get(Nombre="Agrupado"),
                    Activo =activo,
                    GrupoAPR=nuevoAPR
                    )
                nuevoElemento.save()

            else:

                newId,APR = returnValidAPR()
                nuevoAPR=CatalogoAPR(
                    Id=newId,
                    Etiqueta=APR,
                    TipoAgrupacion ="Cantidad",
                ) 
                nuevoAPR.save()

                nuevoElemento =  Materiales(
                    IdMat=(int(last_element.IdMat))+1,
                    SKU=row['SKU'],
                    TextoBreve = row['TextoBreve'],
                    IdCategoria = Categorias.objects.get(Nombre=row['Categoria']),
                    Tipo=CatTipoMat.objects.get(Nombre="Agrupado"),
                    Activo =activo,
                    GrupoAPR=nuevoAPR
                    )
                nuevoElemento.save()

                nuevoAPR.SKUPadre =  nuevoElemento 
                nuevoAPR.save()
                
                
               
def returnValidAPR():
    ultimo =  CatalogoAPR.objects.latest('Etiqueta')

    return ultimo.Id+1,"APR"+str(int(ultimo.Etiqueta.split("APR")[1])+1).zfill(4)
