import pandas as pd
from gtac.models import *
from django.db.models import Q,Count
from django.db.models import Sum
from .funcionesGlobales import *
from .crearOrdenSalidaApr import *
import math


array_materiales_a_ingresar=[]
keysOS = ['TEMM-','MEGA-','BEST-']
keysInternas = ['GTAC','OPS','NOC']

arrayMaterialesReingreso=[]

class Material:
    def __init__(self,**kwargs):
        self.sku = kwargs.get('sku')
        self.cantidad = kwargs.get('cantidad')
        self.id_pmo = kwargs.get('id_pmo')
        self.orden_compra = kwargs.get('orden_compra')

    def __str__(self):
        return("{}/{}/{}".format(self.sku,self.id_pmo,self.orden_compra))


    def apr_o_item(self):
        material  = Materiales.objects.get(SKU=self.sku)
        return material


def crearMaterial(row):
    nuevoMaterial = Material(sku=row['SKU'],cantidad=row['Cantidad a retirar'],id_pmo=row['ID PMO'],orden_compra=row['Orden de compra'])
    array_materiales_a_ingresar.append(nuevoMaterial)

    
def validar_pmos_folios_internos(folios_internos):
    
    for i in folios_internos:
        if not CatalogoOS.objects.filter(OS=i).exists():
            
            nuevo_folio_interno = CatalogoOS(
                OS=i,
                EsInterna = True
            )
            nuevo_folio_interno.save()

def apr_to_sku(texto):

    aux = str(texto)

    if "APR" in aux:
        
        if not CatalogoAPR.objects.filter(Etiqueta = aux).exists(): raise ValueError(f"El APR '{aux}' no existe en el sitema.")
        
        apr = CatalogoAPR.objects.get(Etiqueta = aux)

        material = Materiales.objects.filter(GrupoAPR=apr)[0]

        return material.SKU

    else:
        return texto
    




def validacionesArchivoDeSalida(request,df,almacen):

    columnasNecesarias = ['SKU','Descripción','Cantidad a retirar','ID PMO','Recolecta en almacén','Envio a ocurre','Destinatario','Sitio destino','Es prestamo','Orden de compra']
    arrayCamposVacios = ['SKU','Cantidad a retirar','Sitio destino','ID PMO','Es prestamo']
    arrayCamposNumericos = ['Cantidad a retirar']
    arrayColumnasToStr = ['ID PMO','Orden de compra']
    df = stringifyColumn(arrayColumnasToStr,df)
    validarColumnasNecesarias(columnasNecesarias,df)  #Aprobado
    validarCamposVaciosEnColumna(arrayCamposVacios,df) 
    validarColumnaNumerica(arrayCamposNumericos,df)
    validarTipoDeValorEnColumna(['Si','No'],df,'Es prestamo')
    creacionPES(df)
    validacionOSPES(df)
    df['Pertenece a cliente'] =df.apply(lambda row: validarSiPerteneceACliente(row['ID PMO'],row['Orden de compra']),axis=1)
    df['nuevo PMO']=df.apply(lambda row: build_pmo(row['ID PMO'],row['Orden de compra']),axis=1)
    df['nuevo SKU']=df.apply(lambda row: apr_to_sku(row['SKU']),axis=1)
    df['SKU'] = df['nuevo SKU'] 
    folios_internos = df.loc[df['Pertenece a cliente']==False]
    validar_pmos_folios_internos(folios_internos['nuevo PMO'].unique())
    df['nuevo OC']=df.apply(lambda row: build_oc(row['ID PMO'],row['Orden de compra'],row['nuevo PMO']),axis=1)
    validarExistenciaSKU(df,almacen)
    validacionEnvio(df)
    validacionSitioDestino(df)
    
    orden_salida= nuevaOrdenSalidaApr(df,request,almacen)
    crearEntradaApr(df,request,orden_salida.Id)

    return orden_salida.Folio


def build_oc(id_pmo,oc,nuevoPMO):

    if any([x in id_pmo for x in keysInternas]):
        return nuevoPMO
    else:
        return oc
        
        

def build_pmo(id_pmo,oc):

    if "-" in id_pmo:
        return id_pmo 
    else:
        ultimoRegistro = CatalogoOS.objects.filter(OS__contains=id_pmo).order_by('-OS')[0]
        
        IDPMOSplit = ultimoRegistro.OS.split("-")
        folio = int(IDPMOSplit[1])
        nuevoFolio = id_pmo+"-"+str(folio+1).zfill(4)
        
        return nuevoFolio




def validarSiPerteneceACliente(idPMO,oc):


    if any([x in idPMO for x in keysOS]):
        
        if oc == 'nan':
            raise ValueError("El ID PMO '{}' debe de tener una orden de compra asignada".format(idPMO))

        return True
    else:
        return False
           
def crearEntradaApr(df,request,orden_salida_id):
   
    usuario = User.objects.get(username=request.user)
    profile = Profile.objects.get(user=usuario)

    status = 1
    if profile.Area.Aprovador.username == usuario.username: status = 17
    
    almacen=Sitios.objects.get(IdSitio = request.POST['almacenSelec'])


    df_filtrado = df.loc[(df['Pertenece a cliente']==True) | ((df['Pertenece a cliente']==False) & (df['Es prestamo']=='Si'))]
    df_filtrado.apply(lambda row:crearMaterial(row),axis=1)

    for orden_servicio in df_filtrado['nuevo PMO'].unique():
        
        materiales_por_oc = df_filtrado.loc[df_filtrado['nuevo PMO']==orden_servicio]

        crear_materiales_orden_entrada_apr(orden_servicio,orden_salida_id,materiales_por_oc,request)


       



def crear_materiales_orden_entrada_apr(orden_servicio,orden_salida_id,materiales,request):

    materiales_por_sku=materiales.groupby(['SKU'])['Cantidad a retirar'].sum().to_frame()

    for index,i in materiales_por_sku.iterrows():
        material_en_sistema = Materiales.objects.get(SKU=index)

        if material_en_sistema.Tipo.Nombre == "Item":
            
            for j in range(i['Cantidad a retirar']):

                nuevo_material = BolsaMaterialesByOs(
                    IdMat = material_en_sistema,
                    IdSalida=OrdenesSalidaApr.objects.get(Id=orden_salida_id),
                    QtySolicitada=1,
                    IdOS=CatalogoOS.objects.get(OS=orden_servicio),
                    IdStatus = EstatusMateriales.objects.get(Id=11),
                )
                nuevo_material.save()

        elif material_en_sistema.Tipo.Nombre == "Agrupado":
            
            nuevo_material = BolsaMaterialesByOs(
                IdMat = material_en_sistema,
                IdSalida=OrdenesSalidaApr.objects.get(Id=orden_salida_id),
                IdOS=CatalogoOS.objects.get(OS=orden_servicio),
                IdStatus = EstatusMateriales.objects.get(Id=11),
                QtySolicitada=i['Cantidad a retirar'],
            )
            nuevo_material.save()
                

def creacionPES(df):

    pesEnElArchivo = df['Orden de compra'].dropna().unique()


    
    for i in pesEnElArchivo:
        
        if i != 'nan':
            if  'PES-' not in i: raise ValueError('La orden de compra {} tiene un formato invalido'.format(i))

            if not CatalogoPES.objects.filter(PES=i).exists():

                nuevaPES = CatalogoPES(
                    PES=i
                )

                nuevaPES.save()



def validacionOSPES(df):
    
    OrdenesServicio = df['ID PMO'].unique()

    for i in OrdenesServicio:
        if any([x in i for x in keysOS]):
            
            dfPorOs = df.loc[df['ID PMO']==i]

            nuevo = dfPorOs.groupby(['ID PMO','Orden de compra']).size()
            if len(nuevo.index) != 1: raise ValueError("El ID PMO '{}' está relacionado con multiples ordenes de compra".format(i)) 
            if not CatalogoOS.objects.filter(OS=i).exists():


                nuevaOS = CatalogoOS(
                    OS=i,
                    IdPES=CatalogoPES.objects.get(PES=dfPorOs.iloc[0]['Orden de compra']),
                    EsInterna = False
                )

                nuevaOS.save()
            else:
                osEnSistema = CatalogoOS.objects.get(OS=i)

                if osEnSistema.IdPES.PES != dfPorOs.iloc[0]['Orden de compra']:
                    raise ValueError("El ID PMO '{}' está relacionado con la orden de compra '{}'".format(i,osEnSistema.IdPES.PES))


            
        elif any([x in i for x in keysInternas]):
            if "-" in i:
                if not CatalogoOS.objects.filter(OS=i).exists():
                    raise ValueError("El folio '{}' no existe en el sistema".format(i))
            
        else: 
            raise ValueError("El ID PMO '{}' es invalido".format(i))
        


def validarTipoDeValorEnColumna(arrayValores,df,columna):
    valoresErroneos = df[~df[columna].isin(arrayValores)]    

    if len(valoresErroneos.index)!=0:
        raise ValueError("La columna {} tiene valores diferentes a {}".format(columna,arrayValores))


def validarExistenciaSKU(df,almacen):


    materiales_por_cantidad=df.groupby(['SKU'])['Cantidad a retirar'].sum().to_frame()
 
    for sku,i in materiales_por_cantidad.iterrows():
       
        if not Materiales.objects.filter(SKU=sku).exists():  raise ValueError("El SKU '{}' no existe en sistema".format(sku))

        material = Materiales.objects.get(SKU=sku)

        if material.Tipo.Nombre == "Item":

            cantidadEnInventario = InventarioAprovicionamiento.objects.filter(IdMat__SKU = sku).filter(Almacen=almacen).aggregate(Sum('CtdDisponible'))

            if cantidadEnInventario['CtdDisponible__sum'] == None:
                raise ValueError("El SKU "+sku+" no está disponble en el almacén "+almacen.Nombre)

            else:
                    
                cantidadAlmacen = cantidadEnInventario['CtdDisponible__sum']
                if cantidadAlmacen >= i['Cantidad a retirar']:
                    pass
                else:
                    raise ValueError("La cantidad que intentas retirar del SKU "+sku+" es mayor a la disponible")


        elif material.Tipo.Nombre == "Agrupado" :

            etiquetaAPR = material.GrupoAPR.Etiqueta

            cantidadEnInventario = InventarioAprovicionamiento.objects.filter(Etiqueta = etiquetaAPR).filter(Almacen=almacen).aggregate(Sum('CtdDisponible'))
            if cantidadEnInventario['CtdDisponible__sum'] == None:
                raise ValueError("La etiqueta "+etiquetaAPR+" no está disponble en el almacén "+almacen.Nombre)

            else:
            
                cantidadAlmacen = cantidadEnInventario['CtdDisponible__sum']
                if cantidadAlmacen >= i['Cantidad a retirar']:
                    pass
                else:
                    raise ValueError("La cantidad que intentas retirar del material {} ({}) es mayor a la disponible".format(sku,etiquetaAPR))
                
                   

   

def validacionEnvio(df):

    
    if df['Envio a ocurre'].dtypes == "object" or  len(df['Envio a ocurre'].value_counts()) == 0:

    
        conAmbosValores =  df[(df['Recolecta en almacén'].notnull()) & (df['Envio a ocurre'].notnull())]
        
        if len(conAmbosValores.index) == 0:
            
            
            sinAmbosValores = df[(df['Recolecta en almacén'].isnull()) & (df['Envio a ocurre'].isnull())]
            if len(sinAmbosValores.index) == 0:
                
                
                ocurreSinDestinatario = df[(df['Envio a ocurre'].notnull()) & (df['Destinatario'].isnull())]
                if len(ocurreSinDestinatario.index) == 0:
                    
                    
                    ocurreConDestinatario = df[(df['Envio a ocurre'].notnull()) & (df['Destinatario'].notnull())]
                    catalogoOcurres = ocurreConDestinatario['Envio a ocurre'].unique()

                    for ocurre in catalogoOcurres:
                        

                        if len(ocurre) < 10:
                            
        
                            consulta = SitiosOcurre.objects.filter(CodigoPostal=ocurre)
                            
                            if consulta.exists():
                                pass
                            else:
                                raise ValueError("El ocurre "+ocurre+" no esta dado de alta en el sistema")
                        else:
                            raise ValueError("No puede haber ocurres con mas de 20 caracteres")
                            
                else:
                    raise ValueError("No puede haber registros con 'Envio a ocurre' sin un destinatario")

            else:
                raise ValueError("Hay registros con datos faltantes")

        else:
            raise ValueError("Hay registros con datos extras")
    
    else:
        raise ValueError("La columna 'Envio a ocurre' no puede tener solo datos númericos")



def validacionSitioDestino(df):



    catalogoSitiosCSV = df['Sitio destino'].unique()

    for sitio in catalogoSitiosCSV:
        existenciaEnBase = Sitios.objects.filter(Nombre=sitio)
        if existenciaEnBase.exists():
            pass
        else:
            raise ValueError("El sitio "+sitio+" no existe dentro en el sistema")


   
    













    

