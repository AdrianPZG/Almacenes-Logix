from gtac.models import *
import pandas as pd

from django.db.models import Q,Count

def maquilarNotficacionSalidaApr(orden):

    materiales_tabla=""
    items = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr__Id = orden.Id)
    ocurre = "No aplica"
    destinatario = "No aplica"
    recolector = "No aplica"


    for i in items:
        if i.SitioOcurre != None: ocurre = i.SitioOcurre.CodigoPostal 
        if i.Destinatario!= None: destinatario = i.Destinatario
        if i.RecolectaEnAlmacén!= None: recolector = i.RecolectaEnAlmacén

        pes = "No aplica"

        orden_servicio =  CatalogoOS.objects.get(OS=i.IDPMO) 

        if not orden_servicio.EsInterna:
            pes = orden_servicio.IdPES.PES
            


        if  i.IdMat == None or i.IdMat.Tipo.Nombre == "Agrupado":

            apr = CatalogoAPR.objects.get(Etiqueta = i.IdInventario.Etiqueta)

            if apr.TipoAgrupacion == "Cantidad":
                texto = """
                <tr>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>

                </tr>

                """.format(
                    apr.SKUPadre.SKU,
                    apr.SKUPadre.TextoBreve,
                    i.CtdSalida,
                    i.IDPMO,
                    pes,
                    i.SitioDestino.Nombre,
                    ocurre,
                    destinatario,
                    recolector,
                    i.Caja,
                    i.GuiaEnvio
                    )

                materiales_tabla = materiales_tabla + texto

            else:
                texto = """
                <tr>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>

                </tr>

                """.format(
                    apr.Etiqueta,
                    apr.Texto,
                    i.CtdSalida,
                    i.IDPMO,
                    pes,
                    i.SitioDestino.Nombre,
                    ocurre,
                    destinatario,
                    recolector,
                    i.Caja,
                    i.GuiaEnvio
                    )

                materiales_tabla = materiales_tabla + texto

        
        elif i.IdMat.Tipo.Nombre == "Item":
            texto = """
                <tr>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>
                    <td>{}</td>

                </tr>

            """.format(
                i.IdMat.SKU,
                i.IdMat.TextoBreve,
                i.CtdSalida,
                i.IDPMO,
                pes,
                i.SitioDestino.Nombre,
                ocurre,
                destinatario,
                recolector,
                i.Caja,
                i.GuiaEnvio
                )

            materiales_tabla = materiales_tabla + texto
        




    contenido = """ 
        
        <h1>Packing list: {}</h1>
        <hr>
        <p>Buen día, </p>
        <p>Les comparto el packing list de la salida {}.</p>
        <table cellpadding="0" cellspacing="0"  align="left" border="1" style='text-align:center;'>
            <thead style='background-color:#0099ff; color:#ffffff'>
                <th>SKU</th>
                <th>Texto breve</th>
                <th>Cantidad</th>
                <th>Id PMO</th>
                <th>PES</th>
                <th>Sitio destino</th>
                <th>Sitio ocurre</th>
                <th>Destinatario</th>
                <th>Recolecta en almacén</th>
                <th>Caja</th>
                <th>Guía de envio</th>
            </thead>

            <tbody>
               {}
            </tbody>
        </table>
        <hr>
        <p>Saludos</p>
    
    """.format(orden.Folio,orden.Folio,materiales_tabla)



    return contenido


def getEntradaByPES(df):

    unique_pes = df['IdOS__IdPES__PES'].unique()

    df['Orden_Entrada'] = ""

    for pes in unique_pes:
        arrayEntradas = []

        if OrdenesEntradaApr.objects.filter(FolioOC=pes).exists():

            ordenes = OrdenesEntradaApr.objects.filter(FolioOC=pes).values('Folio')

            for orden in ordenes:

                arrayEntradas.append(orden['Folio'])

            
            df.loc[df['IdOS__IdPES__PES']==pes,'Orden_Entrada'] = str(arrayEntradas)



    return df


def getUbTecSugerida(sku,almacen):
    material =Materiales.objects.get(SKU=sku)
   

    if material.Tipo.Nombre =="Agrupado":
        inventarioAPR = InventarioAprovicionamiento.objects.filter(Q(IdApr__Id= material.GrupoAPR.Id) & Q(Almacen__IdSitio=almacen))
        if inventarioAPR.exists():
            return inventarioAPR[0].IdUbTec.Descripcion
        else:
            return ("No hay una ubicacíon sugerida")

    else:
        inventarioItem = InventarioAprovicionamiento.objects.filter(Q(IdMat= material) & Q(Almacen__IdSitio=almacen))
        
        if inventarioItem.exists():
            return inventarioItem[0].IdUbTec.Descripcion
        else:
            return ("No hay una ubicacíon sugerida")


def validarNumSerieOSKU(sku_numSerie):

    if Materiales.objects.filter(SKU=sku_numSerie).exists():
        material = Materiales.objects.get(SKU=sku_numSerie)
        if material.Tipo.Nombre == "Item":
            raise ValueError("El valor {} corresponde al SKU de un item. Escanea al número de serie".format(material.SKU))

        elif material.Tipo.Nombre == "Agrupado":
            return "Agrupado"


        elif material.Tipo.Nombre == "Consumible": raise ValueError("El SKU {} esta dado de alta como consumible, contacte al administrador")

    else:
        return "NoSerie"

            
def validarColumnasNecesarias(columnas,df):
    
    columnasArchivo = df.columns

    for i in columnas:
        if not i in columnasArchivo: raise ValueError('La columna {} es necesaria en el archivo'.format(i))


def validarCamposVaciosEnColumna(columnas,df):
    columnasConCamposVacios = df.isna().sum()

    for i in columnas:
        if columnasConCamposVacios[i] != 0 : raise ValueError("La columna {} no puede tener campos vacios".format(i))


def validarColumnaNumerica(columnas,df):
    tiposDeDatoColumnas = df.dtypes

    for i in columnas:
        if tiposDeDatoColumnas[i] != "int64" : raise ValueError("La columna {} solo puede tener numeros enteros".format(i))



def validarColumnasValoresUnicos(columnas,df):

    for i in columnas:
        if not df[i].dropna().is_unique : raise ValueError("La columna {} tiene valores repetidos".format(i))


def stringifyColumn(columnas,df):

    for i in columnas:
        df[i]=df[i].astype(str)

    return df

def separarSKUs(skus):

    skusItems=[]

    skusAgrupables=[]

    for sku in skus:

        if not Materiales.objects.filter(SKU=sku).exists(): raise ValueError("El No de parte '{}' no esta registrado en el sistema".format(sku))

        material = Materiales.objects.get(SKU=sku)

        
        if material.Tipo.Nombre == "Item" : 
            skusItems.append(sku)
            continue 

        elif material.Tipo.Nombre == "Agrupado": 
            skusAgrupables.append(sku)
            continue
        
        elif material.Tipo.Nombre == "Consumible":  
            raise ValueError("El No de parte '{}' tiene información faltante, contacte al administrador".format(sku))


    return skusItems,skusAgrupables

def validacionesAgrupables(df,skusAgrupables):
    class Agrupable:
        def __init__(self,row):
            material = Materiales.objects.get(SKU=row['NO DE PARTE'])

            if material.GrupoAPR == None: raise ValueError("El No de parte '{}' no tiene asignado un grupo APR, contacte al administrador".format(row['NO DE PARTE']))

            self.SKU = material
            self.Cantidad = row['QTY']
            self.NoGuia= row['GUIA/TRANSP.']
            self.Caja= row['CAJA']
            
        
        
    
    agrupablesEnOrden = []

    for agr in skusAgrupables:
        skuAgr = df[df['NO DE PARTE']==agr]
        

        for index,row in skuAgr.iterrows():
            nuevoAgrupable = Agrupable(row)
            agrupablesEnOrden.append(nuevoAgrupable)

    return agrupablesEnOrden


def validacionesItems(df,skusItems):
    class Item:
        def __init__(self,row,numSerie):

            material = Materiales.objects.get(SKU=row['NO DE PARTE'])

            self.SKU = material
            self.Cantidad = 1
            self.NoSerie = numSerie
            self.NoGuia= row['GUIA/TRANSP.']
            self.Caja= row['CAJA']
        

    itemsEnOrden=[]

    for sku in skusItems:
        skuDF = df[df['NO DE PARTE']==sku]
        material = Materiales.objects.get(SKU=sku)

        
        for index,row in skuDF.iterrows():
            if material.Activo:
                
                splitNumSerie = row['NO DE SERIE'].split(',')

                if len(splitNumSerie) != row['QTY'] : raise ValueError("Los números de serie del No de parte '{}' no coinciden en cantidad".format(row['NO DE PARTE']))

                for nserie in splitNumSerie:
                    newItem = Item(row,nserie)
                    itemsEnOrden.append(newItem)
            else:
                for i in range(row['QTY']):
                    newItem = Item(row,'')
                    itemsEnOrden.append(newItem)


    return itemsEnOrden


def validarExistenciaCajas(df):

    cajas = df['CAJA'].unique()

    for i in cajas:
        
        if CajasEntradaApr.objects.filter(CodigoCaja=i).exists(): raise ValueError("La caja {} ya esta registrada en el sistema".format(i))
        




def validarDuplicadoNoSerieArchivoComas(df):

  
    arrayNumerosDeSerie = []
    df['NO DE PARTE'] = df['NO DE PARTE'].astype(str)
    df['TIPO'] = df.apply(lambda row: clasificar_sku(row['NO DE PARTE']), axis=1)

    dfItems = df.loc[df['TIPO']=="Item"]



    dfItems.apply(lambda row: validar_numeros_serie_cantidad(row['NO DE PARTE'],row['QTY'],row['NO DE SERIE']), axis=1)

    numerosDeSerie = dfItems['NO DE SERIE'].tolist()

    arrayNumerosDeSerie = []


    for i in numerosDeSerie:
        registroSplit = str(i).split(",")
        for j in registroSplit:
            arrayNumerosDeSerie.append(j)

    
    dfNumerosSerie = pd.DataFrame(arrayNumerosDeSerie,columns=['NO DE SERIE'])

    if dfNumerosSerie['NO DE SERIE'].duplicated().any(): raise ValueError("No puede haber números de serie duplicados en el archivo")

   

    for i in  dfNumerosSerie['NO DE SERIE'].tolist():
        validar_existencia_noserie_en_sistema(i)


   

   

def validar_numeros_serie_cantidad(sku,qty,nos_serie):

    if str(nos_serie) == "nan": raise ValueError("Los elementos que sean tipo item, deben de tener un número de serie")
    
    
    if len(str(nos_serie).split(",")) != qty: raise ValueError("Los números de serie del SKU '{}' no coinciden en cantidad".format(sku))

def validar_existencia_noserie_en_sistema(noSerie):

    if MatOrdenEntradaApr.objects.filter(NoSerie=noSerie).exists() or  InventarioAprovicionamiento.objects.filter(NoSerie=noSerie).exists(): raise ValueError("El número de serie '{}' ya esta dado de alta en la plataforma".format(str(noSerie)))




def clasificar_sku(sku):

    material = Materiales.objects.get(SKU=sku)

    if material.Tipo.Nombre == "Item":
        return "Item"

    elif material.Tipo.Nombre =="Agrupado":
        return "Agrupado"


