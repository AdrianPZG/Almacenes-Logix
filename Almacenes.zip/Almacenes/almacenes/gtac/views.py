import logging
import random
import string
from socket import CAN_RAW
from sys import flags
from django.shortcuts import render, redirect, HttpResponse
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.template.loader import get_template
from django.template import Context, Template
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.models import User
from django.contrib import messages
from django.core import serializers
from django.core.paginator import Paginator 
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives, EmailMessage
from django.template.loader import render_to_string
from django.http import HttpResponseRedirect
from django.db.models import Q, Count, Sum
from django.core import mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.contrib.staticfiles.storage import staticfiles_storage
import pandas as pd
from itertools import chain
from datetime import datetime, timezone, timedelta, date
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Attachment, FileContent, FileName, FileType, Disposition, Cc
import re
import time
import pytz
from itertools import chain
from requests.exceptions import Timeout

from PIL import Image
from brother_ql.conversion import convert
from brother_ql.backends.helpers import send
from brother_ql.raster import BrotherQLRaster
from PIL import Image, ImageDraw, ImageFont
import qrcode
import csv
import secrets

import usb.core
import usb.util
import requests
import json
from gtac.models import *

from gtac.functions.pandasValidationSalidaApr import *
from gtac.functions.pandasValidationRecolecccionApr import *
from gtac.functions.recoleccionInventarioApr import *
from gtac.functions.desgloceMatOrdenSalida import *
from gtac.functions.salidaInventarioAPR import *
from gtac.functions.crearOrdenSalidaApr import *
from gtac.functions.pandasValidationOrdenEntrada import *
from gtac.functions.inventariarOrdenEntradaApr import *
from gtac.functions.plantillaUbTecEntradaApr import *
from gtac.functions.funcionesGlobales import *
from gtac.functions.validacionesPlantillaCajaEntradaApr import *
from gtac.functions.pandasValidationReservaApr import *
from gtac.functions.liberarReservaFunctions import *
from gtac.functions.eliminarReservaApr import *
from gtac.functions.cancelarSalidaApr import *
from gtac.functions.validacionesCargaMasivaSkus import *
from gtac.functions.validacionesCambioEtiquetasSalidaApr import *
from gtac.functions.salidaAprValidaciones import *
from gtac.functions.cruce_os_pes import reporte_bolsa_web
from gtac.functions.reportesBolsaScripts import get_entradas_by_pes,get_salidas_by_pes,reporte_bolsa


from django.http import JsonResponse
from django.core.serializers.json import DjangoJSONEncoder
from django.http.multipartparser import MultiPartParser
from io import BytesIO
import threading
import base64

def reporteBolsa(request,PES):
 
    def faltante(row):
        return row['Salidas'] - row['Inventariado']

    def sin_POD(row):
        return row['Salidas'] - row['Cantidad POD']

   
    df_bolsa,df_salidas,df_entradas = reporte_bolsa(PES)

    if len(df_bolsa)>0:
        df_bolsa['Faltantes'] =  df_bolsa.apply(faltante,axis=1)
        df_bolsa['Sin POD'] =  df_bolsa.apply(sin_POD,axis=1)

        df_bolsa = df_bolsa[[
        "PES",
        'SKU',
        "APR",
        "Texto breve",
        "Categoría",
        "Cancelados Salida",
        "Pendiente Salida",
        "Salidas",
        "Cantidad POD",
        "Sin POD",
        "Faltante Recepcionado",
        "Pendiente validar",
        "Pendiente inventariar",
        "Inventariado",
        "Faltantes"
        ]]

    with BytesIO() as b:
        writer = pd.ExcelWriter(b, engine='xlsxwriter')
        df_salidas.to_excel(writer, sheet_name='Salida')
        df_bolsa.to_excel(writer, sheet_name='Bolsa')
        df_entradas.to_excel(writer, sheet_name='Entradas')

        writer.close()
        filename = f'{PES}.xlsx'
        response = HttpResponse(
            b.getvalue(),
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename=%s' % filename
        return response

    return HttpResponse(200)


def reporteBolsaGlobal(request):
    if request.method =="POST":
        
        body=json.loads(request.body)

        array_PES = [x.PES for x in CatalogoPES.objects.all()]
        t =  threading.Thread(target=thread_reporte_global,args=[array_PES,body['correo']],daemon=True)
        t.start()
        response_data={}
        response_data['icon'] = "success"  
        response_data['text'] = "El reporte sera enviado al correo ingresado"
        response_data['title'] = f"Operacion exitosa"
        return HttpResponse(json.dumps(response_data), content_type="application/json")
    else:
        return HttpResponse(400)

def thread_reporte_global(array_PES,correo):
    df_entradas_global =  pd.DataFrame(columns=[])
    df_salidas_global =  pd.DataFrame(columns=[])
    df_bolsa_global =  pd.DataFrame(columns=[])

    for x in array_PES:
        df_bolsa,df_salidas,df_entradas = reporte_bolsa(x)
        df_entradas_global =  pd.concat([df_entradas_global,df_entradas])
        df_salidas_global =  pd.concat([df_salidas_global,df_salidas])
        df_bolsa_global =  pd.concat([df_bolsa_global,df_bolsa])


    def faltante(row):
        return row['Salidas'] - row['Inventariado']

    def sin_POD(row):
        return row['Salidas'] - row['Cantidad POD']

    if len(df_bolsa_global)>0:
        df_bolsa_global['Faltantes'] =  df_bolsa_global.apply(faltante,axis=1)
        df_bolsa_global['Sin POD'] =  df_bolsa_global.apply(sin_POD,axis=1)


        df_bolsa_global = df_bolsa_global[[
        "PES",
        'SKU',
        "APR",
        "Texto breve",
        "Categoría",
        "Cancelados Salida",
        "Pendiente Salida",
        "Salidas",
        "Cantidad POD",
        "Sin POD",
        "Faltante Recepcionado",
        "Pendiente validar",
        "Pendiente inventariar",
        "Inventariado",
        "Faltantes"
        ]]


        
    encoded_file =base64.b64encode(df_bolsa_global.to_csv(index=False).encode()).decode()
    encoded_file2 =base64.b64encode(df_entradas_global.to_csv(index=False).encode()).decode()
    encoded_file3 =base64.b64encode(df_salidas_global.to_csv(index=False).encode()).decode()

    attachedFile = Attachment(
        FileContent(encoded_file),
        FileName('ReporteGlobalBolsa.csv'),
        FileType('application/csv'),
        Disposition('attachment')
    )

    attachedFile2 = Attachment(
        FileContent(encoded_file2),
        FileName('ReporteGlobalEntradas.csv'),
        FileType('application/csv'),
        Disposition('attachment')
    )


    attachedFile3 = Attachment(
        FileContent(encoded_file3),
        FileName('ReporteGlobalSalidas.csv'),
        FileType('application/csv'),
        Disposition('attachment')
    )

    message = Mail(
            from_email='notificaciones@gtac.com.mx',
            to_emails=correo,
            subject="Reporte global logix",
            html_content="<p>Reportes globales logix</p>")

    message.attachment = [attachedFile,attachedFile2,attachedFile3]

    sg = SendGridAPIClient(
            "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")
    response = sg.send(message)

    
    return True


def getMaterialsByOcurreAndSKU(request, ocurre, ordenId):

    try:
        criterio1 = Q(IdOrdenSalidaApr=ordenId)
        criterio2 = Q(SitioOcurre__CodigoPostal=ocurre)

        inventario = MatOrdenSalidaApr.objects.filter(criterio1).filter(criterio2).values(
            'IdMat__SKU', 'IdInventario__Etiqueta', 'CtdSalida', 'IDPMO', 'SitioDestino__Nombre')

        serialized_q = json.dumps(list(inventario), cls=DjangoJSONEncoder)

        return JsonResponse(serialized_q, safe=False)

    except Exception as e:

        return JsonResponse({"message": str(e)}, status=503)


def getMaterialsByRecolectorAndSKU(request, recolector, ordenId):

    try:

        criterio1 = Q(IdOrdenSalidaApr=ordenId)
        criterio2 = Q(RecolectaEnAlmacén=recolector)

        inventario = MatOrdenSalidaApr.objects.filter(criterio1).filter(criterio2).values(
            'IdMat__SKU', 'IdInventario__Etiqueta', 'CtdSalida', 'IDPMO', 'SitioDestino__Nombre')

        serialized_q = json.dumps(list(inventario), cls=DjangoJSONEncoder)

        return JsonResponse(serialized_q, safe=False)

    except Exception as e:

        return JsonResponse({"message": str(e)}, status=503)

def getOcurres(request):

    try:

        ocurres= SitiosOcurre.objects.all().values('Id','CodigoPostal','Oficina')

        serialized_q = json.dumps(list(ocurres), cls=DjangoJSONEncoder)

        return JsonResponse(serialized_q, safe=False)

    except Exception as e:
        print(e)
        return JsonResponse({"message": str(e)}, status=503)


@login_required
def liberarReservaApr(request):
    try:

        body = json.loads(request.body)
        gruposMateriales = body['gruposMateriales']
        fechaSalida = body['fechaSalida']
        PES = body['PES']
        folioSalida = crearSalidaDesdeReserva(PES,gruposMateriales,fechaSalida,request)
        
        return JsonResponse({"message": f"Orden de salida {folioSalida} creada correctamente","result":"Ok"}, status=200)

    except Exception as e:
        print(e)
        return JsonResponse({"message": str(e),"result":"Error"}, status=503)

#Comentario

@login_required
def cancelarSalidaAPR(request):
    try:

        body = json.loads(request.body)
        ordenSalida = OrdenesSalidaApr.objects.get(Id=body['idSalida'])

        cancelacionDeSalidaApr(ordenSalida)

        return JsonResponse({"message": f"La orden de salida '{ordenSalida.Folio}' se canceló correctamente","result":"Ok"}, status=200)

    except Exception as e:
        print(e)
        return JsonResponse({"message": str(e),"result":"Error"}, status=503)






@login_required
def getMaterialsBySitioPMO(request):
    try:
        body = json.loads(request.body)
        materiales= MatOrdenReservaApr.objects.filter(IDPMO__OS=body['PMO'],SitioDestino__Nombre=body['sitio']).values('IdMat__TextoBreve','IdMat__SKU','IdMat__GrupoAPR__Etiqueta','CtdDisponible','IdMat__Tipo__Nombre','IdStatus__Id')
        

        
        for i in materiales:
            if i['IdMat__Tipo__Nombre'] == "Item":
                i['sku_apr'] = i['IdMat__SKU']
            else:
                i['sku_apr'] = i['IdMat__GrupoAPR__Etiqueta']

            

        serialized_q = json.dumps(list(materiales), cls=DjangoJSONEncoder)

        return JsonResponse(serialized_q, safe=False)

    except Exception as e:
        return JsonResponse({"message": str(e)}, status=503)


def getMaterialsByCaja(request, caja):

    try:
        cajaObjecto = CajasEntradaApr.objects.get(Id=caja)

        inventario = MatOrdenEntradaApr.objects.filter(Caja=cajaObjecto).values(
            'IdMat__SKU', 'IdMat__GrupoAPR__Etiqueta', 'CantidadEntrada', 'NoSerie')

        serialized_q = json.dumps(list(inventario), cls=DjangoJSONEncoder)

        return JsonResponse(serialized_q, safe=False)

    except Exception as e:
        print(e)

        return JsonResponse({"message": str(e)}, status=503)

def eliminarReservaApr(request):
    try:

        body = json.loads(request.body)
        eliminarReservaAprBySitioOS(body['Sitio'],body['IDPMO']) 
        return JsonResponse({"message": "Reserva eliminada correctamente","result":"Ok"}, status=200)

    except Exception as e:
        return JsonResponse({"message": str(e),"result":"Error"}, status=200)





@login_required
def validarMaterialOrdenEntradaApr(request):
    body = json.loads(request.body)
    orden = OrdenesEntradaApr.objects.get(Id=body['IdOrden'])
    response_data = validacionMatEntradaEscaneo(
        body['sku'], orden, body['IdCaja'])

    return HttpResponse(json.dumps(response_data), content_type="application/json")


@login_required
def getOsByPES(request):
    try:
        def count_elementos_by_OS(OS):

            elementos = MatOrdenSalidaApr.objects.filter(
                IDPMO=OS).exclude(IdStatus__Id=15).aggregate(elementos=Sum('CtdSalida'))
            return elementos['elementos']

        class orden_servicio:
            def __init__(self, OS):

                self.OS = OS
                self.elementos = count_elementos_by_OS(OS)

        def count_elementos_entrada_apr(folio_entrada):

            elementos = MatOrdenEntradaApr.objects.filter(
                IdOrdenEntradaApr__Folio=folio_entrada).aggregate(elementos=Sum('CantidadEntrada'))

            return elementos['elementos']

        class entradas:
            def __init__(self, folio):
                self.folio = folio
                self.elementos_entrada = count_elementos_entrada_apr(folio)

        body = json.loads(request.body)


        if body['esInterna'] == "False":

            PES = CatalogoPES.objects.get(PES=body['PES'])
            materiales = [] 

            for i in PES.datos_cuadre: 
                materiales.append(i.__dict__)


            for i in PES.cuadre_apr: 
                materiales.append(i.__dict__)
                


            #materiales_en_bolsa = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES=body['PES']).exclude(IdStatus__Id=15).values('IdMat__SKU' ,'IdMat__GrupoAPR__Etiqueta', 'IdMat__TextoBreve','Id').order_by('IdMat__SKU').annotate(elementosSolicitados=Sum('QtySolicitada'), elementosAbastecidos=Sum('QtyAbastecida'))


            #materiales2 =  BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES=body['PES']).exclude(IdStatus__Id=15).values('IdMat__SKU','IdMat__GrupoAPR__Etiqueta','IdMat__TextoBreve').distinct().annotate(elementosSolicitados=Sum('QtySolicitada'),elementosAbastecidos=Sum('QtyAbastecida'))



            #for i in materiales2:
                #elementosInventariados =  MatOrdenEntradaApr.objects.filter(Q(IdStatus__Id=10)&Q(IdOrdenEntradaApr__FolioOC=body['PES']) & Q(IdMat__SKU=i['IdMat__SKU'])).aggregate(Sum('CantidadRecepcionada'))

                #i['elementosInventariados'] =  elementosInventariados['CantidadRecepcionada__sum']


            materiales_pendientes_en_bolsa = json.dumps(
                list(materiales), cls=DjangoJSONEncoder)

            ordenes_servicio_asociadas = CatalogoOS.objects.filter(
                IdPES__PES=body['PES']).values('OS')

            entrada_asociadas_a_la_pes = OrdenesEntradaApr.objects.filter(
                FolioOC=body['PES'])

            array_ordenes_asociadas = []
            array_entradas_asociadas = []

            for i in ordenes_servicio_asociadas:
                objeto = orden_servicio(i['OS'])
                array_ordenes_asociadas.append(json.dumps(objeto.__dict__))

            for i in entrada_asociadas_a_la_pes:
                objecto = entradas(i.Folio)
                array_entradas_asociadas.append(json.dumps(objecto.__dict__))

            respuesta = {
                "elementos_en_bolsa": materiales_pendientes_en_bolsa,
                "os_asociadas": array_ordenes_asociadas,
                "entradas": array_entradas_asociadas
            }

        else:
            materiales_en_bolsa = BolsaMaterialesByOs.objects.filter(IdOS__OS=body['PES']).exclude(IdStatus__Id=15).values('IdMat__SKU', 'IdMat__GrupoAPR__Etiqueta', 'IdMat__TextoBreve').order_by(
                'IdMat__SKU').annotate(elementosSolicitados=Sum('QtySolicitada'), elementosAbastecidos=Sum('QtyAbastecida'))
            materiales_pendientes_en_bolsa = json.dumps(
                list(materiales_en_bolsa), cls=DjangoJSONEncoder)
            array_ordenes_asociadas = []

            objeto = orden_servicio(body['PES'])

            array_ordenes_asociadas.append(json.dumps(objeto.__dict__))

            respuesta = {
                "elementos_en_bolsa": materiales_pendientes_en_bolsa,
                "os_asociadas": array_ordenes_asociadas,
                "entradas":[]
            }

        return JsonResponse(respuesta, safe=False)

    except Exception as e:
        print(e)
        return JsonResponse({"message": str(e)}, status=503)


@login_required
def getMaterialsByOS(request):
    try:

        body = json.loads(request.body)

        materiales = MatOrdenSalidaApr.objects.filter(IDPMO=body['OS']).exclude(IdStatus__Id=15).values(
            'IdMat__SKU', 'IdInventario__IdApr__Etiqueta', 'CtdSalida', 'IdMat__TextoBreve', 'IdOrdenSalidaApr__Folio', 'IdOrdenSalidaApr__Id')
        materiales = json.dumps(list(materiales), cls=DjangoJSONEncoder)

        respuesta = {
            "materiales": materiales
        }

        return JsonResponse(respuesta, safe=False)

    except Exception as e:
        print(e)
        return JsonResponse({"message": str(e)}, status=503)


@login_required
def getPlantillaInventariarCaja(request):
    response_data = {}
    try:
        body = json.loads(request.body)
        materiales = MatOrdenEntradaApr.objects.filter(
            Q(Caja__Id=body['idCaja']) & Q(Q(IdStatus__Id=8) | Q(IdStatus__Id=9)))

        if materiales.count() == 0:
            raise ValueError("No hay elementos por inventariar en esta caja")
        df = pd.DataFrame(list(materiales.values(
            'Id',
            'IdStatus__Descripcion',
            'IdMat__SKU',
            'etiquetaLogix',
            'NoSerie',
            'IdAPR__Etiqueta',
            'CantidadEntrada',
            'CantidadRecepcionada',
            'IdOrdenEntradaApr__Almacen__IdSitio'

        )))

        df.loc[df["etiquetaLogix"].isnull(
        ), 'etiquetaLogix'] = df["IdAPR__Etiqueta"]
        df['Ubicación sugerida'] = df.apply(lambda row: getUbTecSugerida(
            row['IdMat__SKU'], row['IdOrdenEntradaApr__Almacen__IdSitio']), axis=1)
        df = df.rename(columns={
            'Id': 'Id inventario',
            'IdStatus__Descripcion': 'Estatus',
            'IdMat__SKU': 'SKU',
            'etiquetaLogix': 'Etiqueta logix',
            'NoActivo': 'Etiqueta activo fijo',
            'NoSerie': 'Numero de serie',
            'CantidadEntrada': 'Cantidad en la orden',
            'CantidadRecepcionada': 'Cantidad recepcionada',

        })

        df['Escanea la ubicacion tecnica'] = ""
        df['Ingresa la cantidad'] = ""
        del df['IdOrdenEntradaApr__Almacen__IdSitio']
        del df['IdAPR__Etiqueta']

        response_data = HttpResponse(content_type='text/csv')
        response_data['Content-Disposition'] = 'attachment; filename="Inventario' + \
            str(date.today())+'.csv"'
        df.to_csv(path_or_buf=response_data, index=False)
        return HttpResponse(response_data, content_type="text/csv")

    except Exception as e:

        response_data['result'] = "Error"
        response_data['message'] = str(e)
        return HttpResponse(json.dumps(response_data), content_type="application/json")


@login_required
def notificacionSalidaApr(request):
    response_data = {}
    try:
        body = json.loads(request.body)
        orden = OrdenesSalidaApr.objects.get(Id=body['idOrdenSalida'])

        contenido = maquilarNotficacionSalidaApr(orden)

        message = Mail(
            from_email='notificaciones@gtac.com.mx',
            to_emails=body['principal'],
            subject="Control de envío de material de stock GTAC-{}".format(
                str(orden.FechaSalida).split(" ")[0]),
            html_content=contenido)

        if len(body['copia']) != 0:
            correosCopia = body['copia'].split(",")
            listaCopia = []
            for i in correosCopia:
                listaCopia.append(Cc(i, i))

            message.add_cc(listaCopia)

        sg = SendGridAPIClient(
            "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")
        response = sg.send(message)

        response_data['result'] = "Ok"
        response_data['message'] = "Correo enviado"
        return HttpResponse(json.dumps(response_data), content_type="application/json")

    except Exception as e:
        response_data['result'] = "Error"
        response_data['message'] = str(e)
        return HttpResponse(json.dumps(response_data), content_type="application/json")



@login_required
def inventariarItemNoActivo(request):
    response_data = {}
    try:
        body = json.loads(request.body)

        materialesDisponibles = MatOrdenEntradaApr.objects.filter(
            Q(Caja__Id=body['idCaja']) & Q(IdMat__SKU=body['sku']) & Q(IdStatus__Id=6))

        if len(materialesDisponibles) == 0:
            raise ValueError("No hay materiales disponibles")
        if not "GDL" in body['logix']:
            raise ValueError("La etiqueta '{}' no tiene el formato correcto").format(
                body['logix'])
        if InventarioAprovicionamiento.objects.filter(Etiqueta=body['logix']).exists():
            raise ValueError(
                "La etiqueta logix '{}' ya esta dada de alta en el sistema ".format(body['logix']))
        if MatOrdenEntradaApr.objects.filter(etiquetaLogix=body['logix']).exists():
            raise ValueError(
                "La etiqueta logix '{}' ya esta dada de alta en el sistema ".format(body['logix']))

        materialAEditar = materialesDisponibles[0]
        materialAEditar.etiquetaLogix = body['logix']
        materialAEditar.IdStatus = EstatusMateriales.objects.get(Id=8)
        materialAEditar.CantidadRecepcionada = 1

        materialAEditar.save()

        response_data['result'] = "Ok"
        response_data['message'] = "Información guardada correctamente"
        return HttpResponse(json.dumps(response_data), content_type="application/json")

    except Exception as e:
        response_data['result'] = "Error"
        response_data['message'] = str(e)
        return HttpResponse(json.dumps(response_data), content_type="application/json")


@login_required
def inventariarElementoApr(request):
    response_data = {}
    try:
        body = json.loads(request.body)

        registro = MatOrdenEntradaApr.objects.get(Id=body['idMatOrden'])

        if registro.IdMat.Tipo.Nombre == "Item":

            #if not 'GDL' in body['logix']:
            # Validar que la etiqueta contenga GDL o CDMX
            if not ('GDL' in body['logix'] or 'CDMX' in body['logix']):
                raise ValueError(
                    "La etiqueta logix '{}' no cumple con las especificaciones".format(body['logix']))
            if InventarioAprovicionamiento.objects.filter(Etiqueta=body['logix']).exists():
                raise ValueError(
                    "La etiqueta logix '{}' ya esta dada de alta en el sistema ".format(body['logix']))
            if MatOrdenEntradaApr.objects.filter(etiquetaLogix=body['logix']).exists():
                raise ValueError(
                    "La etiqueta logix '{}' ya esta dada de alta en el sistema ".format(body['logix']))

            if InventarioAprovicionamiento.objects.filter(NoActivo=body['etiquetaActivo']).exists():
                raise ValueError("La etiqueta de activo '{}' ya esta dada de alta en el sistema ".format(
                    body['etiquetaActivo']))
            if MatOrdenEntradaApr.objects.filter(NoActivo=body['etiquetaActivo']).exists():
                raise ValueError("La etiqueta de activo '{}' ya esta dada de alta en el sistema ".format(
                    body['etiquetaActivo']))

            registro.etiquetaLogix = body['logix']
            registro.IdStatus = EstatusMateriales.objects.get(Id=8)
            registro.CantidadRecepcionada = 1
            registro.NoActivo = body['etiquetaActivo']

            registro.save()

            response_data['result'] = "Ok"
            response_data['message'] = "La información se guardo correctamente."
            return HttpResponse(json.dumps(response_data), content_type="application/json")

    except Exception as e:

        print(e)
        response_data['result'] = "Error"
        response_data['message'] = str(e)
        return HttpResponse(json.dumps(response_data), content_type="application/json")


@login_required
def inventariarAgrupadoApr(request):

    body = json.loads(request.body)

    response_data = {}

    materiales = MatOrdenEntradaApr.objects.filter(
        Q(IdMat__SKU=body['sku']) & Q(Caja__Id=body['idCaja']) & Q(IdStatus__Id=6))

    if materiales.exists():

        sumatoria = 0

        for i in materiales:
            sumatoria = sumatoria + i.CantidadEntrada

        cantidadBody = int(body['cantidad'])
        for j in materiales:

            if j.CantidadEntrada > cantidadBody:
                j.CantidadRecepcionada = cantidadBody
                j.IdStatus = EstatusMateriales.objects.get(Id=9)
                j.save()
                cantidadBody = 0
                break

            if j.CantidadEntrada < cantidadBody:
                j.CantidadRecepcionada = j.CantidadEntrada
                j.IdStatus = EstatusMateriales.objects.get(Id=8)
                j.save()
                cantidadBody = cantidadBody - j.CantidadRecepcionada

            if j.CantidadEntrada == cantidadBody:
                j.CantidadRecepcionada = cantidadBody
                j.IdStatus = EstatusMateriales.objects.get(Id=8)
                j.save()
                cantidadBody = 0

                break

        if cantidadBody > 0:
            untracked = UntrackedItemsApr(
                IdMat=Materiales.objects.get(SKU=body['sku']),
                Cantidad=cantidadBody,
                Caja=CajasEntradaApr.objects.get(Id=body['idCaja']),
                IdStatus=EstatusMateriales.objects.get(Id=7)
            )

            untracked.save()
            response_data['result'] = "Ok"
            response_data['message'] = "La orden tiene registrados {} elementos, los cuales fueron recepcionados, aparte {} elementos y espere indicaciones".format(
                sumatoria, cantidadBody)
            return HttpResponse(json.dumps(response_data), content_type="application/json")

        response_data['result'] = "Ok"
        response_data['message'] = "Elementos registrados correctamente".format(
            sumatoria, cantidadBody)
        return HttpResponse(json.dumps(response_data), content_type="application/json")

    else:
        untracked = UntrackedItemsApr(
            IdMat=Materiales.objects.get(SKU=body['sku']),
            Cantidad=body['cantidad'],
            Caja=CajasEntradaApr.objects.get(Id=body['idCaja']),
            IdStatus=EstatusMateriales.objects.get(Id=7)
        )

        untracked.save()

        response_data['result'] = "Error"
        response_data['message'] = "El material no está en la orden, apartelos y espere indicaciones"

        return HttpResponse(json.dumps(response_data), content_type="application/json")

    response_data['result'] = "Ok"
    response_data['message'] = "Elemento creado"

    return HttpResponse(json.dumps(response_data), content_type="application/json")


@login_required
def nuevaReservaApr(request):

    if request.method == "POST":

        if "loadPlantillaReserva" in request.POST:

            user = request.user
            userProfile = Profile.objects.get(user=user)
            archivo = request.FILES['archivo']

            try:

                df = pd.read_csv(archivo, dtype={'SKU': str})

            except Exception as e:
                messages.success(
                    request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
                return redirect("/nuevaReservaApr")

            try:

                almacen = Sitios.objects.get(IdSitio=request.POST['almacen'])
                folio_orden_reserva = validacionesArchivoReserva(request, df, almacen)
                messages.success(request, "Reserva '{}' generada exitosamente.".format(folio_orden_reserva))
                return redirect("/nuevaReservaApr")

            except Exception as e:
                print(e)

                messages.success(request, e)
                return redirect("/nuevaReservaApr")

        if "plantillaReserva" in request.POST:

            response = HttpResponse(content_type="text/csv")
            writer = csv.writer(response)
            writer.writerow(['SKU', 'Descripción', 'Cantidad a retirar',
                            'ID PMO', 'Orden de compra', 'Sitio destino'])

            response['Content-Disposition'] = 'attachment; filename="Plantilla_Reserva_Aprovicionamiento.csv"'
            return response

        if "getInventario" in request.POST:

            e = date.today()
            almacen = Sitios.objects.get(IdSitio=request.POST['almacen'])


            response = HttpResponse(content_type="text/csv")
            writer = csv.writer(response)
            writer.writerow(
                ['Tipo', 'SKU', 'Texto breve', 'Cantidad Disponible'])
            itemsEnAlmacen = InventarioAprovicionamiento.objects.filter(Almacen=almacen).filter(
                IdMat__Tipo__Nombre="Item").values('IdMat__SKU', 'IdMat__TextoBreve').distinct()

            aprsEnAlmacen = InventarioAprovicionamiento.objects.filter(
                Almacen=almacen).filter(Etiqueta__contains="APR")

            for apr in aprsEnAlmacen:

                if apr.IdApr.TipoAgrupacion == "SKU":
                    writer.writerow(
                        ["Agrupable", apr.Etiqueta, apr.IdApr.Texto, apr.CtdDisponible])
                else:
                    writer.writerow(["Agrupable", apr.IdApr.SKUPadre.SKU,
                                    apr.IdApr.SKUPadre.TextoBreve, apr.CtdDisponible])

            for mat in itemsEnAlmacen:
                sku = mat['IdMat__SKU']
                txt = mat['IdMat__TextoBreve']
                cantidadEnInventario = InventarioAprovicionamiento.objects.filter(
                    Almacen=almacen).filter(IdMat__SKU=sku).aggregate(Sum('CtdDisponible'))
                writer.writerow(
                    ["Item", sku, txt, cantidadEnInventario['CtdDisponible__sum']])

            response['Content-Disposition'] = 'attachment; filename="Inventario-' + \
                str(e)+'.csv"'
            return response

    return render(request, "nuevaReservaApr.html")


@login_required
def validarNoSerieEntradaApr(request):
    response_data = {}
    try:
        body = json.loads(request.body)

        if InventarioAprovicionamiento.objects.filter(NoSerie=body['noSerie']).exists():
            raise ValueError(
                "El número de serie '{}' ya existe en el inventario".format(body['noSerie']))

        elemento = MatOrdenEntradaApr.objects.filter(
            Q(NoSerie=body['noSerie']) & Q(IdMat__SKU=body['sku']))

        if elemento.exists():

            if elemento[0].IdStatus.Id != 6:
                raise ValueError(
                    "El elemento no esta en el status 'Pendiente validar existencia en caja'")

            if str(elemento[0].IdOrdenEntradaApr.Id) == str(body['ordenId']):
                response_data['result'] = "ItemEnLaOrden"
                response_data['modal'] = "modalRecolectarInfo"
                response_data['esActivo'] = elemento[0].IdMat.Activo
                response_data['IdMatOrden'] = elemento[0].Id
                return HttpResponse(json.dumps(response_data), content_type="application/json")

            else:

                response_data['result'] = "Error"
                response_data['message'] = "El número de serie '{}' esta asociado a otra orden de entrada, apartelo y notifique al administrador".format(
                    body['noSerie'])
                return HttpResponse(json.dumps(response_data), content_type="application/json")

        else:
            if UntrackedItemsApr.objects.filter(NumeroSerie=body['noSerie']).exists():
                raise ValueError(
                    "El elemento tiene información faltante, apartelo y espere indicaciones.")

            untrackedItem = UntrackedItemsApr(
                IdMat=Materiales.objects.get(SKU=body['sku']),
                NumeroSerie=body['noSerie'],
                Cantidad=1,
                Caja=CajasEntradaApr.objects.get(Id=body['caja']),
                IdStatus=EstatusMateriales.objects.get(Id=7)
            )

            untrackedItem.save()

            response_data['result'] = "Información faltante"
            response_data['message'] = "El elemento tiene información faltante, apartelo y espere indicaciones."

            return HttpResponse(json.dumps(response_data), content_type="application/json")

        response_data['result'] = "Ok"
        response_data['message'] = "Validado"
        return HttpResponse(json.dumps(response_data), content_type="application/json")

    except Exception as e:
        response_data['result'] = "Error"
        response_data['message'] = str(e)
        return HttpResponse(json.dumps(response_data), content_type="application/json")


# -----------------------------------------------------------------------------------------------------------------


@login_required 
def cruce_os_pes2(request):
    response_data = {}
    if request.method =="POST":
        body =  json.loads(request.body)

        if body['action'] == "getBolsa":
            pes =  CatalogoPES.objects.get(PES=body['pes'])
            entradas = OrdenesEntradaApr.objects.filter(FolioOC=body['pes']).values('Folio')
            salidas =  MatOrdenSalidaApr.objects.filter(IDPMO__in=pes.os_in_pes).values('IdOrdenSalidaApr__Folio','IDPMO').distinct()
            
            os_dict =  pes.os_in_pes_dict

            for x in os_dict:
                os = CatalogoOS.objects.get(OS=x['OS'])
                x['elementos_Salida'] = os.elementos_Salida
            
            
            for x in salidas:
                salida = OrdenesSalidaApr.objects.get(Folio=x['IdOrdenSalidaApr__Folio'])
                x['elementos_Salida'] = salida.elementos_Salida
                x['elementos_Cancelados'] = salida.elementos_Cancelados
                x['elementos_Pendientes'] = salida.elementos_Pendientes

             
            for x in entradas:
                entrada=OrdenesEntradaApr.objects.get(Folio=x['Folio'])
                x['elementos_POD'] = entrada.elementos_POD
                x['elementos_Inventariados'] = entrada.elementos_Inventariados
                x['elementos_Pendientes'] = entrada.elementos_Pendientes


            array_bolsa =  reporte_bolsa_web(body['pes'])
            query_entradas_s = json.dumps(array_bolsa, cls=DjangoJSONEncoder)
            query_folios_entrada = json.dumps(list(entradas), cls=DjangoJSONEncoder)
            query_folios_salida = json.dumps(list(salidas), cls=DjangoJSONEncoder)
            query_os = json.dumps(list(os_dict), cls=DjangoJSONEncoder)

             
            response_data['last_entry']= pes.ultima_entrada
            response_data['first_out'] = pes.primera_salida

            response_data['result'] = "Ok"
            response_data['entradas'] =query_entradas_s
            response_data['Oentradas'] =query_folios_entrada
            response_data['Osalidas'] =query_folios_salida
            response_data['os'] =query_os


            return HttpResponse(json.dumps(response_data), content_type="application/json")
    

    total =  CatalogoPES.objects.all()

    return render(request,"cruce_os_pes.html",{
        "total":total
        })


@login_required
def cruce_os_pes(request):

    class PES_OS:
        def __init__(self, Id, OS):
            self.Id = Id
            self.OS = OS

    ordenes_compra = BolsaMaterialesByOs.objects.filter(
        IdOS__EsInterna=False).exclude(IdStatus__Id=15).values('IdOS__IdPES__PES', 'IdOS__EsInterna').distinct()


    def last_entry(PES):
        ultima_entrada = OrdenesEntradaApr.objects.filter(FolioOC = PES).exclude(IdStatus__Id=15).order_by('FechaEntrada')
        
        if len(ultima_entrada) != 0:
            x = ultima_entrada[0].FechaEntrada

            return x.strftime("%d-%m-%Y")

        else:
            return "Sin entradas"


    def first_out(PES):
        
        os_asociadas = CatalogoOS.objects.filter(IdPES__PES = PES)
        
        os_asociadas_array = []

        for i in os_asociadas:
            os_asociadas_array.append(i.OS)

        primera_salida= MatOrdenSalidaApr.objects.filter(IDPMO__in= os_asociadas_array).exclude(IdStatus__Id=15).order_by('-IdOrdenSalidaApr__FechaSalida')
        if len(primera_salida) != 0:
            x = primera_salida[0].IdOrdenSalidaApr.FechaSalida
            return x.strftime("%d-%m-%Y")
        else:
            return "Sin salidas"


    def suma_por_abastecer(PES):
        #materiales_en_pes = BolsaMaterialesByOs.objects.filter(IdOS__IdPES__PES = PES ).exclude(IdStatus__Id=15).aggregate(Sum('QtySolicitada'),Sum('QtyAbastecida'))
        
        os_asociadas =CatalogoOS.objects.filter(IdPES__PES=PES)
        os_array=[]
        for i in os_asociadas:
            os_array.append(i.OS)


        enSalida =  MatOrdenSalidaApr.objects.filter(IDPMO__in=os_array).exclude(IdStatus__Id=15).aggregate(Sum('CtdSalida'))

        enEntrada = MatOrdenEntradaApr.objects.filter(Q(IdOrdenEntradaApr__FolioOC=PES)&Q(IdStatus__Id=10)).aggregate(Sum('CantidadRecepcionada'))
        
        #por_abastecer = materiales_en_pes['QtySolicitada__sum']-materiales_en_pes['QtyAbastecida__sum'] 
        

        if enEntrada['CantidadRecepcionada__sum'] == None:
            enEntrada['CantidadRecepcionada__sum'] = 0
         

        por_abastecer2 =enSalida['CtdSalida__sum'] - enEntrada['CantidadRecepcionada__sum']

        print(PES)
        print(enSalida['CtdSalida__sum'])
        print(enEntrada['CantidadRecepcionada__sum'])
        print("--------")
        return por_abastecer2




    def suma_por_abastecer_orden_interna(OS):
        materiales_en_pes = BolsaMaterialesByOs.objects.filter(IdOS__OS = OS ).exclude(IdStatus__Id=15).aggregate(Sum('QtySolicitada'),Sum('QtyAbastecida'))
        por_abastecer = materiales_en_pes['QtySolicitada__sum']-materiales_en_pes['QtyAbastecida__sum'] 
        return por_abastecer




    for i in ordenes_compra:
        i['Last_entry']  = last_entry(i['IdOS__IdPES__PES'])
        i['First_out'] = first_out(i['IdOS__IdPES__PES']) 
        i['por_abastecer']  = suma_por_abastecer(i['IdOS__IdPES__PES'])
        
        if i['por_abastecer'] == 0:
            i['color'] = "bg-success"
        elif i['Last_entry'] != "Sin entradas":
            i['color'] = "bg-warning"
        else:
            i['color']  = "bg-danger"
 
    ordenes_internas = BolsaMaterialesByOs.objects.filter(
        IdOS__EsInterna=True).exclude(IdStatus__Id=15).values('IdOS__OS', 'IdOS__EsInterna').distinct()



    for i in ordenes_internas:
        i['por_abastecer']  = suma_por_abastecer_orden_interna(i['IdOS__OS'])
        
        i['color']  = "bg-warning"
        if i['por_abastecer'] == 0:
            i['color'] = "bg-success"
 


    total = list(chain(ordenes_compra, ordenes_internas))


    if request.method == "POST":
        if 'getReporteCruce' in request.POST:


            materiales = BolsaMaterialesByOs.objects.all()

            df = pd.DataFrame(list(materiales.values(
                'IdMat__SKU',
                'IdMat__TextoBreve',
                'IdMat__GrupoAPR__Etiqueta',
                'IdMat__IdCategoria__Nombre',
                'IdOS__OS',
                'IdOS__IdPES__PES',
                'IdSalida__Folio',
                'IdSalida__FechaSalida',
                'QtySolicitada',
                'QtyAbastecida',
            )))

            df = df.assign(Cantidad_por_abastecer=lambda x: (
                x['QtySolicitada']-x['QtyAbastecida']))
            df = getEntradaByPES(df)

            df = df.rename(columns={
                'IdMat__SKU': 'SKU',
                'IdMat__TextoBreve': 'Descripcion',
                'IdMat__GrupoAPR__Etiqueta': 'Grupo APR',
                'IdMat__IdCategoria__Nombre': 'Categoria',
                'IdOS__OS': 'Orden de servicio',
                'IdOS__IdPES__PES': 'PES',
                'IdSalida__Folio': 'Orden de salida',
                'IdSalida__FechaSalida': 'Fecha Salida',
                'QtySolicitada': 'Cantida Solicitada',
                'QtyAbastecida': 'Cantidad abastecida',

            })

            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="Reporte-Global-Bolsa' + \
                str(date.today())+'.csv"'

            df.to_csv(path_or_buf=response, index=False)

            return response

        elif 'getReporteCruceRealidad' in request.POST:
  
            consulta = BolsaMaterialesByOs.objects.all().values('IdMat__SKU','IdMat__TextoBreve','IdOS__IdPES__PES').distinct().annotate(Sum('QtySolicitada'),Sum('QtyAbastecida'))

            df = pd.DataFrame(list(consulta))   
            def get_skus_entrada(row):

                materiales = MatOrdenEntradaApr.objects.filter(Q(IdStatus__Id=10)&Q(IdMat__SKU=row['IdMat__SKU'])&Q(IdOrdenEntradaApr__FolioOC = row['IdOS__IdPES__PES'])).values('IdMat__SKU').distinct().annotate(Sum('CantidadRecepcionada'))  
                try:
                    num =  materiales[0]['CantidadRecepcionada__sum']
                except Exception as e:
                    num = 0
                    
                return num

            df['Cantidad inventariada'] = df.apply(lambda row: get_skus_entrada(row),axis=1) 


            df = df.rename(columns={
                'IdMat__SKU': 'SKU',
                'IdMat__TextoBreve': 'Descripcion',
                'QtySolicitada__sum': 'Cantidad salida',
                'QtyAbastecida__sum': 'Cantidad POD',
                'CantidadRecepcionada__sum':'Inventariado real'
            })

            




            response = HttpResponse(content_type='text/csv')

            response['Content-Disposition'] = 'attachment; filename="Reporte-In-vs-Out-' + \
                str(date.today())+'.csv"'
            
            df.to_csv(path_or_buf=response, index=False)
            return response





    return render(request, "cruce_os_pes.html", {

        "total": total
    })


@login_required
def detallesCajaEntradaApr(request, idCaja):

    caja = CajasEntradaApr.objects.get(Id=idCaja)
    materiales = MatOrdenEntradaApr.objects.filter(Caja=caja)
    totalElementos = MatOrdenEntradaApr.objects.filter(
        Caja=caja).aggregate(Sum('CantidadEntrada'))['CantidadEntrada__sum']
    items = MatOrdenEntradaApr.objects.filter(Caja=caja, IdMat__Tipo__Nombre="Item").aggregate(
        Sum('CantidadEntrada'))['CantidadEntrada__sum']
    agrupables = MatOrdenEntradaApr.objects.filter(Caja=caja, IdMat__Tipo__Nombre="Agrupado").aggregate(
        Sum('CantidadEntrada'))['CantidadEntrada__sum']

    if items == None:
        items = 0
    if agrupables == None:
        agrupables = 0
    if totalElementos == None:
        totalElementos = 0

    if request.method == "POST":
        if "uploadPlantillaCaja" in request.POST:
            archivo = request.FILES['plantillaCaja']

            try:
                df = pd.read_csv(archivo)

            except Exception as e:
                messages.success(
                    request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
                return redirect("/detallesCajaEntradaApr/"+str(caja.Id))

            try:

                responseValidacion = validacionPlantillaCaja(df, caja)
                if responseValidacion == True:
                    messages.success(request, "Exito")
                    return redirect("/detallesCajaEntradaApr/"+str(caja.Id))

                else:
                    messages.success(request, responseValidacion)
                    return redirect("/detallesCajaEntradaApr/"+str(caja.Id))

            except Exception as e:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]

                messages.success(request, str(e))
                return redirect("/detallesCajaEntradaApr/"+str(caja.Id))

    return render(request, 'movimientosAPR/detallesCajaEntradaApr.html', {
        "caja": caja,
        "materiales": materiales,
        "totalElementos": totalElementos,
        "items": items,
        "agrupables": agrupables

    })


@login_required
def recepcionCajasEntradaApr(request):

    if request.method == "POST":
        if "reporteCajasPorIngresar" in request.POST:

            df = pd.DataFrame(list(CajasEntradaApr.objects.filter(IdOrdenEntradaApr__FechaEntrada__lt=date.today()+timedelta(days=4)).exclude(Estatus="Verificada").values(
                'IdOrdenEntradaApr__Folio',
                'IdOrdenEntradaApr__FechaEntrada',
                'Estatus',
                'CodigoCaja',
            )))

            if df.empty:
                messages.success(request, "No hay cajas por recepcionar")
                return redirect("/recepcionCajasEntradaApr")

            df = df.rename(columns={
                'IdOrdenEntradaApr__Folio': 'Folio orden entrada',
                'IdOrdenEntradaApr__FechaEntrada': 'Fecha de entrada',
                'CodigoCaja': 'Codigo de la caja',
            })

            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="Recepción-Cajas-Intervalo-' + \
                str(date.today()+timedelta(days=3))+'.csv"'

            df.to_csv(path_or_buf=response, index=False)
            return response

        if "validarCaja" in request.POST:
            codigo = request.POST['CodigoCaja']

            if CajasEntradaApr.objects.filter(CodigoCaja=codigo).exists():

                caja = CajasEntradaApr.objects.get(CodigoCaja=codigo)
                if caja.Estatus == "Pendiente verificación":

                    caja.Estatus = "Verificada"
                    caja.save()
                    messages.success(
                        request, "La caja {} se verificó correctamente".format(str(codigo)))
                    return redirect("/recepcionCajasEntradaApr")
                else:
                    messages.success(
                        request, "La caja {} ya está verificada".format(str(codigo)))
                    return redirect("/recepcionCajasEntradaApr")

            else:
                messages.success(
                    request, "La caja {} no está registrada en el sistema".format(str(codigo)))
                return redirect("/recepcionCajasEntradaApr")

    cajas = CajasEntradaApr.objects.all()

    return render(request, "movimientosAPR/recepcionCajasEntradaApr.html", {
        "cajas": cajas
    })


@login_required
def catalogoDHL(request):

    catalogoDHL = SitiosOcurre.objects.all()

    if request.method == "POST":

        if "crearOcurre" in request.POST:

            cp = request.POST['cp']

            cp = "DHL-"+str(cp)

            if not SitiosOcurre.objects.filter(CodigoPostal=cp).exists():

                ocurre = SitiosOcurre(
                    CodigoPostal=cp,
                    Oficina=request.POST['direccion']
                )

                ocurre.save()

                messages.success(
                    request, f"El sitio ocurre {ocurre.CodigoPostal} fue creado exitosamente")
                return redirect("/catalogoDHL")

            else:
                messages.success(
                    request, f"Ya existe un sitio ocurre asociado al código postal {request.POST['cp']}")
                return redirect("/catalogoDHL")

    return render(request, "catalogoDHL.html", {
        "catalogoDHL": catalogoDHL
    })


@login_required
def ordenesEntradaApr(request):

    ordenes = OrdenesEntradaApr.objects.all()

    if request.method == "POST":

        if "getReporteEntradas" in request.POST:

            if request.POST['IdOrdenEntrada'] == "all":
                materiales = MatOrdenEntradaApr.objects.all()
            else:
                materiales = MatOrdenEntradaApr.objects.filter(
                    IdOrdenEntradaApr__Id=request.POST['IdOrdenEntrada'])

            df = pd.DataFrame(list(materiales.values(
                'IdMat__SKU',
                'IdMat__TextoBreve',
                'IdMat__IdCategoria__Nombre',
                'IdAPR__Etiqueta',
                'CantidadEntrada',
                'CantidadRecepcionada',
                'NoSerie',
                'NoActivo',
                'etiquetaLogix',
                'IdOrdenEntradaApr__Folio',
                'IdOrdenEntradaApr__FolioOC',
                'IdOrdenEntradaApr__FechaEntrada',
                'IdOrdenEntradaApr__FechaCreacion',
                'IdStatus__Descripcion'
            )))

            df = df.rename(columns={
                'IdMat__SKU': 'SKU',
                'IdMat__TextoBreve': 'Descripcion',
                'IdAPR__Etiqueta': 'Grupo APR',
                'IdMat__IdCategoria__Nombre': 'Categoria',
                'CantidadEntrada': 'Cantidad en la entrada',
                'CantidadRecepcionada': 'Cantidad recepcionada',
                'NoSerie': 'Numero de serie',
                'NoActivo': 'Numero de activo',
                'etiquetaLogix': 'Etiqueta logix',
                'IdOrdenEntradaApr__Folio': 'Orden de entrada',
                'IdOrdenEntradaApr__FolioOC': 'Orden de compra',
                'IdOrdenEntradaApr__FechaEntrada': 'Fecha de entrada',
                'IdStatus__Descripcion': 'Estatus del material'
            })

            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="Reporte-Entradas-Aprovicionamiento-' + \
                str(date.today())+'.csv"'

            df.to_csv(path_or_buf=response, index=False)

            return response

    return render(request, "movimientosAPR/ordenesEntradaApr.html", {
        "ordenes": ordenes
    })


@login_required
def detallesOrdenEntradaApr(request, IdOs):

    orden = OrdenesEntradaApr.objects.get(Id=IdOs)

    cajas = CajasEntradaApr.objects.filter(IdOrdenEntradaApr=orden)

    materiales = MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr=orden)

    return render(request, "movimientosAPR/detallesOrdenEntradaAPR.html", {
        "orden": orden,
        "cajas": cajas,
        "materiales": materiales
    })


@login_required
def reporteTodosLosMovimientosAPR(request):

    df = pd.DataFrame(list(MatOrdenSalidaApr.objects.all().values(
        'Id',
        'IdMat__SKU',
        'IdMat__TextoBreve',
        'IdOrdenSalidaApr__Folio',
        'IdOrdenSalidaApr__FechaSalida',
        'IdOrdenSalidaApr__FechaCreacion',
        'IdInventario__Etiqueta',
        'IdInventario__IdApr__Etiqueta',
        'IdStatus__Descripcion',
        'CtdSalida',
        'IDPMO',
        'Caja',
        'RecolectaEnAlmacén',
        'Destinatario',
        'GuiaEnvio',
        'SitioOcurre__CodigoPostal',
        'SitioOcurre__Oficina',
        'SitioDestino__Nombre'

    )))

    df.loc[df["IdMat__SKU"].isnull(
    ), 'IdMat__SKU'] = df["IdInventario__IdApr__Etiqueta"]
    del df['IdInventario__IdApr__Etiqueta']

    df = df.rename(columns={
        'Id': 'Id de salida',
        'IdMat__SKU': 'SKU/APR',
        'IdMat__SKU':'Descripcion',
        'IdOrdenSalidaApr__Folio': 'Folio orden',
        'IdInventario__Etiqueta': 'Etiqueta logix',
        'IdStatus__Descripcion': 'Estatus',
        'CtdSalida': 'Cantidad',
        'IDPMO': 'Id PMO',
        'Caja': 'Caja',
        'RecolectaEnAlmacén': 'Recolector en almacén',
        'Destinatario': 'Destinatario',
        'GuiaEnvio': 'Guía de envio',
        'SitioOcurre__CodigoPostal': 'Ocurre CP',
        'SitioOcurre__Oficina': 'Ocurre',
        'SitioDestino__Nombre': 'Sitio destino'

    })

    def getPES(row):
        os = CatalogoOS.objects.get(OS=row['Id PMO'])

        if not os.EsInterna: return os.IdPES.PES
 
    df['PES'] = df.apply(lambda row: getPES(row),axis=1)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Reporte-Completo-' + \
        str(date.today())+'.csv"'

    df.to_csv(path_or_buf=response, index=False)
    return response


@login_required
def reporteReservasApr(request):
    tipo = request.POST['selectedReserva']
    if tipo == "all":
        consulta = MatOrdenReservaApr.objects.all().values('IdMat__SKU','IdMat__GrupoAPR__Etiqueta','IdMat__TextoBreve','IDPMO__OS','IDPMO__IdPES__PES','SitioDestino__Nombre','IdStatus__Descripcion','CtdDisponible','CtdDisponible','CtdUtilizada','IdSalidaApr__Folio')

    else:

        consulta = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=tipo).values('IdMat__SKU','IdMat__GrupoAPR__Etiqueta','IdMat__TextoBreve','IDPMO__OS','IDPMO__IdPES__PES','SitioDestino__Nombre','IdStatus__Descripcion','CtdDisponible','CtdDisponible','CtdUtilizada','IdSalidaApr__Id')


    df = pd.DataFrame(list(consulta))
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Reporte-Reservas-' + str(date.today())+'.csv"'
    df.to_csv(path_or_buf=response, index=False)
    return response




@login_required
def reporteMaterialesSalidaAPR(request, ordenId):

    orden = OrdenesSalidaApr.objects.get(Id=ordenId)

    df = pd.DataFrame(list(MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).values(
        'Id',
        'IdMat__SKU',
        'IdOrdenSalidaApr__Folio',
        'IdInventario__Etiqueta',
        'IdInventario__IdApr__Etiqueta',
        'IdStatus__Descripcion',
        'CtdSalida',
        'IDPMO',
        'Caja',
        'RecolectaEnAlmacén',
        'Destinatario',
        'GuiaEnvio',
        'SitioOcurre__CodigoPostal',
        'SitioOcurre__Oficina',
        'SitioDestino__Nombre'

    )))

    df.loc[df["IdMat__SKU"].isnull(
    ), 'IdMat__SKU'] = df["IdInventario__IdApr__Etiqueta"]
    del df['IdInventario__IdApr__Etiqueta']

    df = df.rename(columns={
        'Id': 'Id de salida',
        'IdMat__SKU': 'SKU/APR',
        'IdOrdenSalidaApr__Folio': 'Folio orden',
        'IdInventario__Etiqueta': 'Etiqueta logix',
        'IdStatus__Descripcion': 'Estatus',
        'CtdSalida': 'Cantidad',
        'IDPMO': 'Id PMO',
        'Caja': 'Caja',
        'RecolectaEnAlmacén': 'Recolector en almacén',
        'Destinatario': 'Destinatario',
        'GuiaEnvio': 'Guía de envio',
        'SitioOcurre__CodigoPostal': 'Ocurre CP',
        'SitioOcurre__Oficina': 'Ocurre',
        'SitioDestino__Nombre': 'Sitio destino'

    })

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="Reporte-' + \
        orden.Folio+'-'+str(date.today())+'.csv"'

    df.to_csv(path_or_buf=response, index=False)
    return response


@login_required
def verInventarios(request):

    almacenes = Sitios.objects.filter(EsAlmacen=True)

    if request.method == "POST":

        if "inventario" in request.POST:
            almacenSelec = Sitios.objects.get(IdSitio=request.POST['almacen'])
            if almacenSelec.Tipo == "Refacciones":

                df = pd.DataFrame(list(Inventario.objects.filter(IdAlmacen=almacenSelec).values(
                    'Id',
                    'IdMat__SKU',
                    'IdMat__TextoBreve',
                    'IdMat__IdCategoria__Nombre',
                    'FechaCreacion',
                    'CtdDis',
                    'CtdRes',
                    'NumeroSerie',
                    'NumActivoFijo',
                    'NumEtiqueta',
                    'IdUbicacionTec__Descripcion',

                )))

                df = df.rename(columns={
                    'Id': 'Id inventario',
                    'IdMat__SKU': 'SKU',
                    'IdMat__TextoBreve': 'Texto breve',
                    'IdMat__IdCategoria__Nombre': 'Categoria',
                    'FechaCreacion': 'Fecha de ingreso',
                    'CtdDis': 'Cantidad disponible',
                    'CtdRes': 'Cantidad reservada',
                    'NumeroSerie': 'Número de serie',
                    'NumActivoFijo': 'Número de activo fijo',
                    'NumEtiqueta': 'Etiqueta logix',
                    'IdUbicacionTec__Descripcion': 'Ubicación tecnica'

                })

                response = HttpResponse(content_type='text/csv')
                response['Content-Disposition'] = 'attachment; filename="Inventario-' + \
                    almacenSelec.Nombre+'-'+str(date.today())+'.csv"'

                df.to_csv(path_or_buf=response, index=False)
                return response

            else:

                df = pd.DataFrame(list(InventarioAprovicionamiento.objects.filter(Almacen=almacenSelec).values(
                    'Id',
                    'IdMat__SKU',
                    'IdMat__TextoBreve',
                    'IdMat__IdCategoria__Nombre',
                    'FechaCreacion',
                    'CtdDisponible',
                    'CtdReservada',
                    'NoSerie',
                    'NoActivo',
                    'Etiqueta',
                    'IdUbTec__Descripcion',
                    'IdApr__Texto'
                )))
                df.loc[df["IdMat__SKU"].isnull(), 'IdMat__SKU'] = df["Etiqueta"]
                df.loc[df["IdMat__TextoBreve"].isnull(
                ), 'IdMat__TextoBreve'] = df["IdApr__Texto"]
                del df['IdApr__Texto']

                df = df.rename(columns={
                    'Id': 'Id inventario',
                    'IdMat__SKU': 'SKU',
                    'IdMat__TextoBreve': 'Texto breve',
                    'IdMat__IdCategoria__Nombre': 'Categoria',
                    'FechaCreacion': 'Fecha ingreso',
                    'CtdDisponible': 'Cantidad disponible',
                    'CtdReservada': 'Cantidad reservada',
                    'NoSerie': 'Número de serie',
                    'NoActivo': 'Número de activo fijo',
                    'Etiqueta': 'Etiqueta logix',
                    'IdUbTec__Descripcion': 'Ubicación tecnica',
                })

                response = HttpResponse(content_type='text/csv')
                response['Content-Disposition'] = 'attachment; filename="Inventario-' + \
                    almacenSelec.Nombre+'-'+str(date.today())+'.csv"'

                df.to_csv(path_or_buf=response, index=False)
                return response

    return render(request, "inventario.html", {
        'almacenes': almacenes,


    })


@login_required
def verReservasApr(request):

    reservas= MatOrdenReservaApr.objects.exclude(IDPMO__EsInterna=True).values('IDPMO__IdPES__PES').distinct()
   
    def process_PES_elements(PES):

        consulta_reservados = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=PES).exclude(IdStatus__Id=15).aggregate(reservados=Sum('CtdReservada'))
        consulta_disponibles = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=PES).filter(IdStatus__Id=13).aggregate(disponibles =Sum('CtdDisponible'))
        consulta_count_os = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=PES).values('IDPMO__OS').distinct().count()    

        return consulta_reservados,consulta_disponibles,consulta_count_os

    for i in reservas:
        reservados, disponibles, count_os = process_PES_elements(i['IDPMO__IdPES__PES'])

        i['elementos_reservados'] = reservados['reservados']
        i['elementos_disponibles'] = disponibles['disponibles']
        i['numero_os'] = count_os


    return render(request, 'verReservasApr.html', {
        'reservas':reservas 

    })




@login_required
def ordenesSalidaApr(request):
    ordenes = OrdenesSalidaApr.objects.all()

    return render(request, 'movimientosAPR/ordenesSalidaApr.html', {
        'ordenes': ordenes

    })

@login_required
def detallesReservaApr(request,IdOs):
    materiales = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=IdOs)

    salidas_asociadas  = SalidasAprPES.objects.filter(IdPES__PES=IdOs)

    def genereteRandomId():
        letters = string.ascii_lowercase
        result_str = ''.join(random.choice(letters) for i in range(6))
        return result_str


    mat_sitio_os = MatOrdenReservaApr.objects.filter(IDPMO__IdPES__PES=IdOs,IdStatus__Id=13).values('IDPMO__OS','SitioDestino__Nombre').distinct().annotate(suma_elementos = Sum("CtdDisponible"))


    for i in mat_sitio_os:
        i['Id']=genereteRandomId()


    for i in materiales:
        if i.IdMat.Tipo.Nombre == "Item":
            i.SKU_APR = i.IdMat.SKU
        else:
            i.SKU_APR = i.IdMat.GrupoAPR.Etiqueta



    return render(request,"detallesReservaApr.html",{
        'materiales':materiales,
        'PES':IdOs,
        'mat_sitio_os':mat_sitio_os,
        'salidas_asociadas':salidas_asociadas
        })



@login_required
def detallesOrdenSalidaApr(request, IdOs):
    orden = OrdenesSalidaApr.objects.get(Id=IdOs)

    conjuntoOcurres = []
    conjuntoRecolectores = []

    class conjuntoOcurre:

        def __init__(self, ocurre):
            material = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).filter(
                SitioOcurre__CodigoPostal=ocurre['SitioOcurre__CodigoPostal']).first()
            self.ocurre = ocurre['SitioOcurre__CodigoPostal']
            self.estatus = material.IdStatus.Descripcion
            self.IdStatus = material.IdStatus.Id

    class conjuntoRecolector:

        def __init__(self, recolector):
            recolector = recolector['RecolectaEnAlmacén']
            material = MatOrdenSalidaApr.objects.filter(
                IdOrdenSalidaApr=orden).filter(RecolectaEnAlmacén=recolector).first()
            self.recolector = recolector
            self.estatus = material.IdStatus.Descripcion
            self.IdStatus = material.IdStatus.Id

    sitiosOcurre = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).exclude(
        SitioOcurre=None).values('SitioOcurre__CodigoPostal').distinct()
    recolectores = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).exclude(
        RecolectaEnAlmacén=None).values('RecolectaEnAlmacén').distinct()

    for ocurre in sitiosOcurre:
        newOcurre = conjuntoOcurre(ocurre)

        conjuntoOcurres.append(newOcurre)

    for recolector in recolectores:
        newRecolector = conjuntoRecolector(recolector)

        conjuntoRecolectores.append(newRecolector)

    if request.method == "POST":

        if "salida" in request.POST:

            if request.POST['modo'] == "recolector":

                materiales = MatOrdenSalidaApr.objects.filter(
                    IdOrdenSalidaApr=orden).filter(RecolectaEnAlmacén=request.POST['valor'])
                for i in materiales:
                    i.IdStatus = EstatusMateriales.objects.get(Id=5)
                    i.save()

            else:
                materiales = MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=orden).filter(
                    SitioOcurre__CodigoPostal=request.POST['valor'])
                for i in materiales:
                    i.IdStatus = EstatusMateriales.objects.get(Id=5)
                    i.save()

            messages.success(request, "Materiales liberados correctamente")
            return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

        if "getEtiquetasForCambio" in request.POST:


            df = pd.DataFrame(list(MatOrdenSalidaApr.objects.filter(Q(IdOrdenSalidaApr=orden.Id)&Q(IdMat__Tipo__Nombre="Item")&Q(IdStatus__Id=1)).values('Id','IdMat__SKU','IdInventario__Etiqueta','IdInventario__IdUbTec__Descripcion')))

            df['Etiqueta sustituto'] = ""
            df=df.rename(columns={
                'IdMat__SKU':'SKU',
                'IdInventario__Etiqueta':'Etiqueta original',
                'IdInventario__IdUbTec__Descripcion':'Ubicacion original'
                })

            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = f'attachment; filename="Items-{orden.Folio}.csv"'
            df.to_csv(path_or_buf=response, index=False)
            return response
        
        if "loadArchivoCambioEtiquetas" in request.POST:

            archivo = request.FILES['etiquetas']
            try:

                df = pd.read_csv(archivo)
            except Exception as e:
                messages.success(request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
                return redirect("/materiales/")
            
            elementosNecesarios =  MatOrdenSalidaApr.objects.filter(Q(IdOrdenSalidaApr__Id=orden.Id)&Q(IdMat__Tipo__Nombre="Item")&Q(IdStatus__Id=1)).count()
            if elementosNecesarios != len(df):
                messages.success(request, f"La plantilla tiene que contener {elementosNecesarios} filas")
                return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))
            

            estado,df =  validacionesCambioEtiquetasSalidaApr(request,df,orden)            
            

            if estado is False:
                response = HttpResponse(content_type='text/csv')
                response['Content-Disposition'] = 'attachment; filename="Cambio_Etiquetas_Errores.csv"'
                df.to_csv(path_or_buf=response, index=False)
                return response
            else:
                df.apply(lambda row: swapEtiqueta(row,orden),axis=1)
                messages.success(request, "El cambio de etiquetas se hizo correctamente")
                return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))
        
 

        if "getOrden" in request.POST:

            response = HttpResponse(
                content_type='text/csv',
                headers={
                    'Content-Disposition': 'attachment; filename="'+orden.Folio+'.csv"'},
            )

            writer = csv.writer(response)
            writer.writerow(['Id', 'Status', 'SKU', 'Texto breve', 'Cantidad', 'IdPMO', 'Sitio destino', 'Sitio ocurre', 'Destinatario',
                            'Recolecta en almacén', 'Etiqueta', 'Ubicación tecnica', 'Caja', 'Escanea la etiqueta', 'Guía de envio'])

            materialesDeLaOrden = MatOrdenSalidaApr.objects.filter(
                IdOrdenSalidaApr=orden)

            for i in materialesDeLaOrden:

                recolectaEnAlmacen = i.RecolectaEnAlmacén
                EnvioAOcurre = i.SitioOcurre
                Destinatario = i.Destinatario

                if recolectaEnAlmacen == None:
                    recolectaEnAlmacen = ""
                    EnvioAOcurre = i.SitioOcurre.CodigoPostal

                if EnvioAOcurre == None:
                    EnvioAOcurre = ""
                    Destinatario = ""

                if "APR" in i.IdInventario.Etiqueta:

                    if i.IdInventario.IdApr.TipoAgrupacion == "SKU":

                        writer.writerow([i.Id, i.IdStatus.Descripcion, i.IdInventario.Etiqueta, i.IdInventario.IdApr.Texto, i.CtdSalida, i.IDPMO,
                                        i.SitioDestino.Nombre, EnvioAOcurre, Destinatario, recolectaEnAlmacen, i.IdInventario.Etiqueta, i.IdInventario.IdUbTec.Descripcion])
                    else:
                        writer.writerow([i.Id, i.IdStatus.Descripcion, i.IdInventario.IdMat.SKU, i.IdMat.TextoBreve, i.CtdSalida, i.IDPMO, i.SitioDestino.Nombre,
                                        EnvioAOcurre, Destinatario, recolectaEnAlmacen, i.IdInventario.Etiqueta, i.IdInventario.IdUbTec.Descripcion])

                else:
                    writer.writerow([i.Id, i.IdStatus.Descripcion, i.IdMat.SKU, i.IdMat.TextoBreve, i.CtdSalida, i.IDPMO, i.SitioDestino.Nombre,
                                    EnvioAOcurre, Destinatario, recolectaEnAlmacen, i.IdInventario.Etiqueta, i.IdInventario.IdUbTec.Descripcion])

            return response

        if "loadOrden" in request.POST:
            archivo = request.FILES['materiales']
            df = pd.read_csv(archivo)

            ids = validacionIdsSalidaAPR(df, orden)

            if ids == True:

                guias = validacionNumGuia(df, orden)

                if guias == True:

                    cajas = validacionCajas(df, orden)

                    if cajas == True:

                        escaneoEtiquetas = validacionEscaneoEtiquetas(
                            df, orden)
                        if escaneoEtiquetas == True:

                            salida = realizarSalidaDeInventario(df, orden)
                            messages.success(
                                request, "La orden se marco como recolectada")
                            return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

                        else:
                            messages.success(request, escaneoEtiquetas)
                            return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

                    else:
                        messages.success(request, cajas)
                        return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

                else:
                    messages.success(request, guias)
                    return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

            else:
                messages.success(request, ids)
                return redirect("/detallesOrdenSalidaApr/"+str(orden.Id))

    return render(request, 'movimientosAPR/detallesOrdenSalidaAPR.html', {
        'orden': orden,
        'conjuntoOcurres': conjuntoOcurres,
        'conjuntoRecolectores': conjuntoRecolectores,

    })


@login_required
def ordenSalidaApr(request):

    almacenesAPR = Sitios.objects.filter(
        EsAlmacen=True).filter(Tipo="Aprovicionamiento")

    if request.method == "POST":

        if "plantillaSalida" in request.POST:

            response = HttpResponse(content_type="text/csv")
            writer = csv.writer(response)
            writer.writerow(['SKU', 'Descripción', 'Cantidad a retirar', 'ID PMO', 'Es prestamo',
                            'Orden de compra', 'Recolecta en almacén', 'Envio a ocurre', 'Destinatario', 'Sitio destino'])

            response['Content-Disposition'] = 'attachment; filename="PlantillaSalidaAprovicionamiento.csv"'
            return response

        if "getInventario" in request.POST:
            e = date.today()
            almacen = Sitios.objects.get(IdSitio=request.POST['almacen'])

            response = HttpResponse(content_type="text/csv")
            writer = csv.writer(response)
            writer.writerow(
                ['Tipo', 'SKU', 'Texto breve', 'Cantidad Disponible'])

            itemsEnAlmacen = InventarioAprovicionamiento.objects.filter(Almacen=almacen).filter(
                IdMat__Tipo__Nombre="Item").values('IdMat__SKU', 'IdMat__TextoBreve').distinct()

            aprsEnAlmacen = InventarioAprovicionamiento.objects.filter(
                Almacen=almacen).filter(Etiqueta__contains="APR")


            for apr in aprsEnAlmacen:
                if apr.IdApr.TipoAgrupacion == "SKU":
                    writer.writerow(
                        ["Agrupable", apr.Etiqueta, apr.IdApr.Texto, apr.CtdDisponible])
                else:
                    writer.writerow(["Agrupable", apr.IdApr.SKUPadre.SKU,
                                    apr.IdApr.SKUPadre.TextoBreve, apr.CtdDisponible])

            for mat in itemsEnAlmacen:
                sku = mat['IdMat__SKU']
                txt = mat['IdMat__TextoBreve']
                cantidadEnInventario = InventarioAprovicionamiento.objects.filter(
                    Almacen=almacen).filter(IdMat__SKU=sku).aggregate(Sum('CtdDisponible'))
                writer.writerow(
                    ["Item", sku, txt, cantidadEnInventario['CtdDisponible__sum']])

            response['Content-Disposition'] = 'attachment; filename="Inventario-' + \
                str(e)+'.csv"'
            return response

        elif 'cargarArchivo2' in request.POST:

            user = request.user
            userProfile = Profile.objects.get(user=user)
            archivo = request.FILES['archivoMateriales']

            try:

                df = pd.read_csv(archivo)
                df['SKU'] = df['SKU'].astype(str)

            except Exception as e:
                messages.success(
                    request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
                return redirect("/ordenSalidaApr")

            try:

                almacen = Sitios.objects.get(
                    IdSitio=request.POST['almacenSelec'])
                folio_orden_salida = validacionesArchivoDeSalida(
                    request, df, almacen)

                messages.success(request, "Orden de salida '{}' generada exitosamente.".format(
                    folio_orden_salida))
                return redirect("/ordenSalidaApr")

            except Exception as e:

                messages.success(request, e)
                return redirect("/ordenSalidaApr")


        elif 'cargarArchivo' in request.POST:
            user = request.user
            userProfile = Profile.objects.get(user=user)
            archivo = request.FILES['archivoMateriales']

            try:

                df = pd.read_csv(archivo)

            except Exception as e:
                messages.success(
                    request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
                return redirect("/ordenSalidaApr")

         
            if len(df)==0:
                messages.success(request, "El archivo esta vacio")
                return redirect("/ordenSalidaApr/")

                    
            estado,newdf = salidaAprValidacionesFunciones(request,df)
            


            if estado is False:
                response = HttpResponse(content_type='text/csv')
                response['Content-Disposition'] = 'attachment; filename="Salida_Apr_Errores.csv"'
                df.to_csv(path_or_buf=response, index=False)
                return response
            else:
                folio = crearSalidaApr(newdf,request)
                messages.success(request, f"Salida exitosa: {folio}")
                return redirect("/ordenSalidaApr/")




    return render(request, "movimientosAPR/ordenSalidaApr.html", {
        "almacenesAPR": almacenesAPR,

    })


@login_required
def ordenEntradaApr(request):

    almacenes = Sitios.objects.filter(Tipo="Aprovicionamiento")

    def entry_point_crear_entrada(request, df):

        descontar_materiales_bolsa_entrada_apr(request, df)

        folio = nueva_entrada_APR(
            request.headers['PES'], df, request.headers['fechaEntrada'], request.headers['almacen'], request)

        return folio

    if request.method == "POST":

        if "getPlantilla" in request.POST:
            response = HttpResponse(content_type="text/csv")
            writer = csv.writer(response)
            writer.writerow(['NO DE PARTE',	'DESCRIPCION', 'QTY',
                            'NO DE SERIE', 'CAJA', 'GUIA/TRANSP.'])

            response['Content-Disposition'] = 'attachment; filename="PlantillaEntradaAprovicionamiento.csv"'
            return response

        if request.headers['Action'] == "validarArchivo":

            try:

                df = pd.read_csv(request.FILES.get('archivo'))

                discrepancias, numero_discrepancias, esInterna = validar_discrepancias_en_la_bolsa(
                    df, request.headers['PES'])

                if numero_discrepancias != 0:

                    return JsonResponse({"ordenCreada": False, "discrepancias": json.dumps(discrepancias, default=str), "esInterna": esInterna})
                else:

                    folio = entry_point_crear_entrada(request, df)
                    return JsonResponse({"ordenCreada": True, "folio": folio})

            except Exception as e:
                return JsonResponse({"message": "Error", "error": str(e)})

        if request.headers['Action'] == 'crearEntrada':

            try:
                df = pd.read_csv(request.FILES.get('archivo'))

                folio = entry_point_crear_entrada(request, df)
                nuevoComentario = ComentariosEntradasApr(
                    IdOrdenEntradaApr=OrdenesEntradaApr.objects.get(
                        Folio=folio),
                    Comentario=request.headers['comentario'],
                    CreadoPor=User.objects.get(username=request.user)
                )

                nuevoComentario.save()

                return JsonResponse({"ordenCreada": True, "folio": folio})
            except Exception as e:
                print(e)
                return JsonResponse({"message": "Error", "error": str(e)})

    return render(request, "movimientosAPR/ordenEntradaApr.html", {
        'almacenes': almacenes
    })


def generar_password():
    password = secrets.token_urlsafe(7)
    password = str(password)
    return(password)


def restaurarContraseña(request):
    if request.method == "POST":
        user = request.POST['user']

        if User.objects.filter(username=user).exists():
            usuario = User.objects.get(username=user)
            pasw = generar_password()
            usuario.set_password(pasw)
            usuario.save()

            correoReenvioPwd(usuario.email, pasw, usuario.username)
            messages.success(
                request, "Tu contraseña fue restablecida correctamente, se envio a tu correo proporcionado.")

        else:

            messages.success(
                request, "El username que ingresaste no existe dentro de la plataforma.")

    return render(request, 'reenviar_contraseña.html')


@login_required
def nuevaOrdenEntrada(request):

    materiales = Materiales.objects.all()

    if request.method == "POST":
        objeto = json.loads(request.POST['djMateriales'])
        request.session['materiales'] = objeto
        return redirect("/datosOrdenEntrada")

    return render(request, "nuevaOrdenEntrada.html", {
        "materiales": materiales
    })


@login_required
def actualizarCatalogo(request):
    if request.method == "POST":
        archivo = request.FILES['archivo']
        df = pd.read_csv(archivo)
        for index, i in df.iterrows():
            actualizar = Profile.objects.get(user=i['Id'])
            actualizar.Telefono = i['Telefono']
            actualizar.save()

        messages.success(request, "Catalogo Actualizado")

    return render(request, 'actualizarCatalogo.html', {

    })


def generarTicketAbastecimiento(usuario, almacen, motivo, fechaEntrada, fechaSalida, telefono):
    url = 'https://accounts.zoho.com/oauth/v2/token'
    myobj = {
        "refresh_token": "1000.5c9d14b727e182b2e32e038479f8b6f2.4805c39bc60d7bfce204996d86f3c103",
        "grant_type": "refresh_token",
        "client_id": "1000.V7XQQOMPF3VH3OQ7DY22F3VX8B3FIR",
        "client_secret": "4fe487cfb940fee018fd6af014f4a6f1432331c178",
        "redirect_uri": "https://www.zoho.com",
        "scope": "SDPOnDemand.requests.ALL"
    }

    x = requests.post(url, data=myobj)
    json_data = x.json()
    access_token = "Zoho-oauthtoken "+json_data["access_token"]

    urlServiceDesk = "https://sdpondemand.manageengine.com/api/v3/requests"

    body = {"input_data": json.dumps({"request": {"description": str(motivo), "template": {"name": "Solicitud de accesos", }, "request_type": {"name": "Accesos", }, "subject": "ALMACEN || Entrada/Salida", "technician": {"name": "Hugo Arrizaga Palomo"}, "assets": [{"name": str(almacen)}], "udf_fields": {"udf_date6": {"value": str(
        fechaEntrada)}, "udf_date7": {"value": str(fechaSalida)}, "udf_date3": {"display_value": "21 Oct 2021, 16:18:04"}, "udf_char39": "PM", "udf_char40": "Administrativa", "udf_char71": str(telefono), "udf_char74": "VMnEn82176", "udf_char70": str(usuario), "udf_char72": "N/A", "udf_char43": "No", "udf_char64": "Entrada/Salida de Material", "udf_char72": "No"}}})}

    headers = {
        "Accept": "application/vnd.manageengine.sdp.v3+json",
        "Authorization": access_token,
        "Content-Type": "application/x-www-form-urlencoded"
    }

    a = requests.post(urlServiceDesk, headers=headers, data=body)
    a = a.content
    # print(a)
    a = a.decode()
    a = json.loads(a)
    display_id = a['request']['display_id']

    # print("fecha: "+ a['request']['udf_fields']['udf_date6']['display_value'])
    # print("value: "+ a['request']['udf_fields']['udf_date6']['value'])
    # print("display id: "+str(display_id))

    return display_id


def ticketSDAbastecimiento(request):

    almacenes = Sitios.objects.filter(EsAlmacen=True)
    misTicketsSD = TicketSD.objects.filter(CreadoPor=request.user)

    if request.method == "POST":

        usuario = Profile.objects.get(user=request.user)
        persona = User.objects.get(username=request.user)
        almacen = Sitios.objects.get(IdSitio=request.POST['almacen'])

        d = datetime.strptime(
            request.POST['fechaEntrada'], "%Y-%m-%dT%H:%M")
        d = d + timedelta(hours=5)
        estampa1 = int(d.timestamp()*1000)

        f = datetime.strptime(
            request.POST['fechaSalida'], "%Y-%m-%dT%H:%M")
        f = f + timedelta(hours=5)
        estampa2 = int(f.timestamp()*1000)

        motivo = request.POST['motivo']

        if len(request.POST['personaExtra']) != 0:
            motivo = motivo + " /  Persona Extra: " + \
                request.POST['personaExtra']

        try:
            nuevoTicketSD = TicketSD(
                CreadoPor=User.objects.get(username=request.user),
                Almacen=Sitios.objects.get(IdSitio=request.POST['almacen']),
                Motivo=request.POST['motivo'],
                FechaEntrada=request.POST['fechaEntrada'],
                FechaSalida=request.POST['fechaSalida'],
                IdTicket=generarTicketAbastecimiento(
                    persona.first_name, almacen.Nombre, motivo, estampa1, estampa2, usuario.Telefono)
            )
            nuevoTicketSD.save()
            messages.success(request, "El ticket se genero correctamente.")
        except:
            messages.success(request, "Ups! Sucedio un error.")

    return render(request, 'formularioTicketSD.html', {
        "almacenes": almacenes,
        "misTicketsSD": misTicketsSD
    })


@login_required
def Reporte(request, almacen):
    e = datetime.now()
    response = HttpResponse(content_type="text/csv")
    writer = csv.writer(response)
    writer.writerow(['SKU', 'Descripcion', 'Es Activo', 'Número de etiqueta', 'Número de serie', 'Cantidad Total', 'Cantidad Reservada',
                    'Cantidad Disponible', 'Ubicación Técnica', 'Fecha de Ingreso', 'Número de activo', 'Comentarios de entrada'])
    for mat in Inventario.objects.filter(IdAlmacen=almacen).values_list('IdMat__SKU', 'IdMat__TextoBreve', 'IdMat__Activo', 'NumEtiqueta', 'NumeroSerie', 'Ctd', 'CtdRes', 'CtdDis', 'IdUbicacionTec__Descripcion', 'FechaCreacion', 'NumActivoFijo', 'DescripcionEntrada'):
        writer.writerow(mat)

    response['Content-Disposition'] = 'attachment; filename="Inventario-' + \
        str(e)+'.csv"'
    return response


def imprimirEtiqueta(request, etiqueta, cantidad, impresora):

    qr = qrcode.QRCode(
        version=1,
        box_size=10,
        border=0)
    qr.add_data(etiqueta)
    qr.make(fit=True)
    img = qr.make_image(fill='black', back_color='white')

    if os.environ['ENV'] == "PRO":

        urlqr = "/data/almacenes/static/qr.png"
        urlet = "/data/almacenes/static/etiqueta.png"
        urltxt = "/data/almacenes/static/text.png"
        urlfont = "/data/almacenes/static/arial.ttf"
    else:

        urlqr = "static/qr.png"
        urlet = "static/etiqueta.png"
        urltxt = "static/text.png"
        urlfont = "static/arial.ttf"

    img.save(urlqr)

    imgTexto = Image.new('RGB', (306, 306), "white")

    d = ImageDraw.Draw(imgTexto)
    font = ImageFont.truetype(urlfont, 33)
    d.text((25, 0), etiqueta, "black", font)
    imgTexto.save(urltxt)
    imgQr = qrcode.make(id)
    imgQr.resize((250, 250))

    img1 = Image.open(urltxt)
    img2 = Image.open(urlqr)

    img3 = img2.resize((165, 165))
    etiqueta = Image.new('RGB', (202, 202), "white")

    etiqueta.paste(img1, (0, 0))
    etiqueta.paste(img3, (5, 30))
    etiqueta.save(urlet, "PNG")

    im = Image.open(urlet)
    a = im.resize((202, 202))

    backend = 'network'    # 'pyusb', 'linux_kernal', 'network'
    model = 'QL-800'  # your printer model.
    # Get these values from the Windows usb driver filter.  Linux/Raspberry Pi uses '/dev/usb/lp
    printer = 'tcp://'+impresora

    # backend = 'pyusb'    # 'pyusb', 'linux_kernal', 'network'
    # model = 'QL-800' # your printer model.
    # printer = 'usb://0x04f9:0x209c'    # Get these values from the Windows usb driver filter.  Linux/Raspberry Pi uses '/dev/usb/lp

    qlr = BrotherQLRaster(model)
    qlr.exception_on_warning = True

    instructions = convert(

        qlr=qlr,
        images=[a],  # Takes a list of file names or PIL objects.
        label='23x23',
        rotate='90',    # 'Auto', '0', '90', '270'
        threshold=70.0,    # Black and white threshold in percent.
        dither=False,
        compress=False,
        red=False,    # Only True if using Red/Black 62 mm label tape.
        dpi_600=False,
        hq=True,    # False for low quality.
        cut=True

    )

    for i in range(1):

        send(instructions=instructions, printer_identifier=printer,
             backend_identifier=backend, blocking=True)


@login_required
def ubtecSugerida(request, IdOsI):

    orden = OrdenEntrada.objects.get(IdOsI=IdOsI)
    impresora = orden.IdDestino.IpImpresora

    if request.method == "POST":

        orden = OrdenEntrada.objects.get(IdOsI=IdOsI)
        if request.POST['tipomat'] == "1":

            matEntrada = MatOrdenEntrada.objects.get(
                Id=request.POST['matEntrada'])
            registro = Inventario.objects.filter(IdUbicacionTec=request.POST['ubsuger']).filter(
                IdMat__SKU=matEntrada.IdMat.SKU).filter(IdAlmacen=orden.IdDestino.IdSitio).first()

            matEntrada.NumEtiqueta = registro.NumEtiqueta
            matEntrada.UbicacionTecnicaDestino = registro.IdUbicacionTec

            registro.Ctd = registro.Ctd + matEntrada.CtdEntrada
            registro.CtdDis = registro.CtdDis + matEntrada.CtdEntrada

            try:

                imprimirEtiqueta(request, registro.NumEtiqueta,
                                 int(matEntrada.CtdEntrada), impresora)
            except:
                registro.save()
                matEntrada.StatusMaterial = "Material Ingresado a Inventario"

            registro.save()
            matEntrada.StatusMaterial = "Material Ingresado a Inventario"
            matEntrada.save()
            messages.success(request, "Material Ingresado a Inventario")
        else:
            matEntrada = MatOrdenEntrada.objects.get(
                Id=request.POST['matEntrada'])
            registro = Inventario.objects.filter(IdUbicacionTec=request.POST['ubsuger']).filter(
                IdMat__SKU=matEntrada.IdMat.SKU).filter(IdAlmacen=orden.IdDestino.IdSitio).first()

            matEntrada.UbicacionTecnicaDestino = registro.IdUbicacionTec

            inv = Inventario.objects.get(NumEtiqueta=matEntrada.NumEtiqueta)
            inv.IdUbicacionTec = UbicacionesTecnicas.objects.get(
                Id=request.POST['ubsuger'])

            inv.save()

            matEntrada.StatusMaterial = "Material Ingresado a Inventario"
            matEntrada.save()
            messages.success(request, "Material Ingresado a inventario")

    return redirect("/ingresarOrdenEntrada/"+IdOsI)


@login_required
def añadirubTec(request, IdOsI):

    if request.method == "POST":

        registro = Inventario.objects.get(Id=request.POST['IdEnInventario'])
        material = MatOrdenEntrada.objects.get(Id=request.POST['matEn'])

        try:
            registro.IdUbicacionTec = UbicacionesTecnicas.objects.get(
                Descripcion=request.POST['ubtec'])
            material.UbicacionTecnicaDestino = UbicacionesTecnicas.objects.get(
                Descripcion=request.POST['ubtec'])
        except:
            messages.success(request, "Ubicación técnica no existente")
            return redirect("/ingresarOrdenEntrada/"+IdOsI)

        registro.save()
        material.StatusMaterial = "Material Ingresado a Inventario"
        material.save()
        messages.success(request, "Ubicación técnica registrada")

    return redirect("/ingresarOrdenEntrada/"+IdOsI)


@login_required
def generarEtiqueta(request, IdOsI):

    def crearEnInventario(material, orden):
        nuevoIngreso = Inventario.objects.create(
            IdMat=Materiales.objects.get(IdMat=material.IdMat.IdMat),
            IdAlmacen=Sitios.objects.get(IdSitio=orden.IdDestino.IdSitio),
            NumEtiqueta=material.NumEtiqueta,
            Ctd=material.CtdEntrada,
            CtdDis=material.CtdEntrada,
            CtdRes=0,
            NumeroSerie=material.NumeroSerie,
            NumActivoFijo=material.NumActivo,
            DescripcionEntrada=material.DescripcionEntrada
        )
        nuevoIngreso.save()

        idEnInventario = nuevoIngreso.Id

        material.IdEnInventario = Inventario.objects.get(Id=idEnInventario)
        material.save()
        impresora = "192.168.99.3"

        imprimirEtiqueta(request, material.NumEtiqueta,
                         material.CtdEntrada, impresora)

    if request.method == "POST":

        # tipo=request.POST['tipo']
        orden = OrdenEntrada.objects.get(IdOsI=IdOsI)
        impresora = orden.IdDestino.IpImpresora
        material = MatOrdenEntrada.objects.get(Id=request.POST['idEn'])
        try:

            ultimoRegistroInv = Inventario.objects.filter(IdAlmacen=orden.IdDestino).filter(
                NumEtiqueta__startswith=str(orden.IdDestino.Imputacion)).order_by('-Id')[0]
            ultimaEtiqueta = ultimoRegistroInv.NumEtiqueta

        except:
            ultimaEtiqueta = "S01"

        ultimaEtiqueta = re.findall(r'\d+', ultimaEtiqueta)
        nuevaEtiqueta = int(ultimaEtiqueta[0].lstrip('+-0'))+1
        nuevaEtiqueta = orden.IdDestino.Imputacion+str(nuevaEtiqueta).zfill(6)

        material.NumEtiqueta = nuevaEtiqueta

        material.save()

        try:
            crearEnInventario(material, orden)

        except Exception as e:
            print("se ejecuto este exception")
            messages.success(request, e)
            material.StatusMaterial = "Pendiente ubicación técnica"  # aquiii
            material.save()
            return redirect("/ingresarOrdenEntrada/"+str(orden.IdOsI))

        material.StatusMaterial = "Pendiente ubicación técnica"
        material.save()

        # messages.success(request,"Etiqueta asignada, porfavor escanea la ubicación técnica")
        return redirect("/ingresarOrdenEntrada/"+str(orden.IdOsI))

    return redirect("/ingresarOrdenEntrada/"+IdOsI)


@login_required
def ingresosAInventario(request):

    ordenesEntrada = OrdenEntrada.objects.filter(
        asignadoA=request.user).exclude(IdStatus=1).exclude(IdStatus=3)

    return render(request, "ingresosAInventario.html", {
        'ordenesEntrada': ordenesEntrada
    })


@login_required
def materiales(request):

    if request.method =="POST" and "loadPlantillaSKUS" in request.POST:
        archivo = request.FILES['archivo']
        try:

            df = pd.read_csv(archivo)
        except Exception as e:
            messages.success(request, "El archivo contiene caractéres especiales. Elimínelos para poder continuar")
            return redirect("/materiales/")
        
        estado,newdf = validacionesArchivoSKUS(request,df)

        if estado is False:
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="Carga_Materiales_Errores.csv"'
            df.to_csv(path_or_buf=response, index=False)
            return response
        else:
            crearSKUsCargaMasiva(df)

        messages.success(request, "Carga masiva exitosa")
        return redirect("/materiales/")

    if request.method =="POST" and "getCatalogoMateriales" in request.POST:
        
        df_materiales =  pd.DataFrame(list(Materiales.objects.all().values('SKU','TextoBreve','IdCategoria__Nombre','Tipo__Nombre')))
        df_APR= pd.DataFrame(list(CatalogoAPR.objects.all().values('Etiqueta','TipoAgrupacion','Texto','SKUPadre__SKU')))

        
        with BytesIO() as b:
            writer = pd.ExcelWriter(b, engine='xlsxwriter')
            df_materiales.to_excel(writer, sheet_name='Materiales')
            df_APR.to_excel(writer, sheet_name='APRs')
            writer.close()
            filename = 'CatalogoMateriales.xlsx'
            response = HttpResponse(
                b.getvalue(),
                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            response['Content-Disposition'] = 'attachment; filename=%s' % filename
            return response

    if request.method =="POST" and "getPlantilla" in request.POST:
        response = HttpResponse(content_type="text/csv")
        writer = csv.writer(response)
        writer.writerow(['SKU','Item/APR','Categoria','EsActivo','TextoBreve','NuevoAPR','TipoAPR','APRAsociado'])
        response['Content-Disposition'] = 'attachment; filename="Plantilla-CargaMasiva-SKUs.csv"'
        return response


    if request.method =="POST" and "getCatalogoMateriales" in request.POST:
        df_materiales =  pd.DataFrame(list(Materiales.objects.all().values('SKU','TextoBreve','IdCategoria__Nombre','Tipo__Nombre')))
        df_APR= pd.DataFrame(list(CatalogoAPR.objects.all().values('Etiqueta','TipoAgrupacion','Texto','SKUPadre__SKU')))
        response = HttpResponse(content_type='text/csv')

        df.to_csv(path_or_buf=response, index=False)
        return response
    
    if request.method=="POST" and "nuevaCategoria" in request.POST:
        
        if Categorias.objects.filter(Nombre=str(request.POST['categoria']).strip()).exists():
            messages.success(request, "La categoría ya existe en sistema")
            return redirect("/materiales/")

        nueva_categoria =  Categorias(
            Nombre=str(request.POST['categoria']).strip()
        )
        nueva_categoria.save()
        messages.success(request, "La categoría se creó exitosamente")
        return redirect("/materiales/")

       




    if request.method=="POST" and "editarMaterial" in request.POST:
        try:
            m = Materiales.objects.get(IdMat=request.POST['IdMat'])
            m.TextoBreve = str(request.POST['texto_breve']).strip()
            m.IdCategoria = Categorias.objects.get(Id=request.POST['categoria_id'])
            m.Tipo = CatTipoMat.objects.get(Id=request.POST['tipo_id'])
            m.save()
            messages.success(request, "Material actualizado correctamente")
        except Exception as e:
            messages.success(request, str(e))
        return redirect("/materiales/")

    items =  Materiales.objects.values('IdMat','SKU','Tipo__Id','IdCategoria__Id','IdCategoria__Nombre','TextoBreve','Activo','Tipo__Nombre','GrupoAPR__Etiqueta')
    categorias = Categorias.objects.all()
    tipos = CatTipoMat.objects.all()
    
    return render(request, "materiales.html",{
        "materiales":items,
        "categorias":categorias,
        "tipos":tipos
        })


@login_required
def ordenesEntrada(request):

    ordenesEntrada = OrdenEntrada.objects.all()

    return render(request, "ordenesEntrada.html", {
        'ordenes': ordenesEntrada,
        'label': "entrada"
    })


@login_required
def ordenesSalida(request):

    ordenesSalida = OrdenSalida.objects.all()

    return render(request, "ordenesEntrada.html", {
        'ordenes': ordenesSalida,
        'label': "salida"

    })


@login_required
def recolectorAlmacen(request, IdOs):

    ordenARecolectar = OrdenSalida.objects.get(IdOs=IdOs)
    materiales = MatOrden.objects.filter(IdOs=IdOs)

    materialesRestantes = MatOrden.objects.filter(
        IdOs=IdOs, StatusMaterial="Por Recolectar").count()

    if materialesRestantes == 0:
        flag = True
    else:
        flag = False

    if request.method == "POST":

        matALiberar = MatOrden.objects.get(Id=request.POST['Id'])
        matInv = Inventario.objects.get(Id=matALiberar.IdMaterialInventario.Id)

        NumEtiqueta = matInv.NumEtiqueta
        if len(NumEtiqueta) == 0:

            messages.success(
                request, "El material no cuenta con una etiqueta registrada en el sistema")

        else:

            if NumEtiqueta == request.POST['Scanner']:

                matALiberar.StatusMaterial = "Material Recolectado"
                matALiberar.save()
            else:
                messages.success(request, "Id Incorrecto")

        return redirect("/recolectorAlmacen/"+str(IdOs))

    return render(request, "ordenARecolectar.html", {
        'ordenARecolectar': ordenARecolectar,
        'materiales': materiales,
        'flag': flag
    })


@login_required
def descripcionCajas(request, IdOs):

    ordenARecolectar = OrdenSalida.objects.get(IdOs=IdOs)
    materiales = MatOrden.objects.filter(IdOs=IdOs)

    if request.method == "POST":
        if len(request.POST['descripcionCajas']) <= 1:
            messages.success(
                request, "La descripción de la caja no puede estar vacia")

        else:
            nuevoIngresoPaqueteria = PaqueteriaOs.objects.create(
                IdOs=OrdenSalida.objects.get(IdOs=IdOs),
                DescripcionDeLasCajas=request.POST['descripcionCajas'],
            )

            nuevoIngresoPaqueteria.save()

            ordenSalida = OrdenSalida.objects.get(IdOs=IdOs)
            ordenSalida.IdStatus = Estatus.objects.get(Id=6)
            ordenSalida.save()

            creador = ordenSalida.CreadoPor.email
            asunto = "LogiX: Orden recolectada ("+str(ordenSalida.Folio)+")"
            correo(creador, asunto, ordenSalida)

            creador = ordenSalida.CreadoPor.email
            asunto = "LogiX: Pendiente guías ("+str(ordenSalida.Folio)+")"
            correo(creador, asunto, ordenSalida)

            logMovimiento(ordenSalida, Estatus.objects.get(
                Id=6), ordenSalida.recolectorAlmacen)

            messages.success(request, "Orden " + ordenSalida.Folio +
                             " liberada, puedes retirarte del almacén")

            return redirect("/")

    return render(request, "descripcionCajas.html", {
        'ordenARecolectar': ordenARecolectar
    })


@login_required
def ubicacionTecnicaDestino(request, IdOs):
    orden = OrdenSalida.objects.get(IdOs=IdOs)

    if orden.IdStatus.Id == 5 or orden.IdStatus.Id == 9:

        flag = 0

        materiales = MatOrden.objects.filter(IdOs=IdOs)
        items = MatOrden.objects.filter(IdOs=IdOs).filter(
            IdMaterialInventario__IdMat__Tipo__Id=2)

        if(len(items) == 0):
            return redirect("/instalarEnSitio/"+str(IdOs))

        materialesConUbicacionTecnica = MatOrden.objects.filter(
            IdOs=IdOs).filter(StatusMaterial="Con Ubicacion Tecnica Destino")

        if len(items) == len(materialesConUbicacionTecnica):
            flag = 1

        if request.method == "POST":

            material = MatOrden.objects.get(Id=request.POST['IdMatOrden'])

            material.UbicacionTecnicaDestino = request.POST['UbTecDes']
            material.StatusMaterial = "Con Ubicacion Tecnica Destino"

            material.save()
            messages.success(
                request, "Se asignó ubicación tecnica al material")
            return redirect("/ubicacionTecnicaDestino/"+str(orden.IdOs))

        return render(request, "ubicacionTecnicaDestino.html", {
            'orden': orden,
            'materiales': materiales,
            'items': items,
            'flag': flag
        })

    else:
        messages.success(request, "Ups! Algo Salio Mal")
        return redirect("/")


@login_required
def ingresarOrdenEntrada(request, IdOs):

    orden = OrdenEntrada.objects.get(IdOsI=IdOs)
    if orden.IdStatus.Id != 2:

        messages.success(request, "Ups! Ocurrio un error")

        return redirect("/")

    if request.path == "/finalizarOrdenEntrada/"+str(IdOs):
        orden.IdStatus = Estatus.objects.get(Id=13)
        orden.save()
        st = Estatus.objects.get(Id=13)
        logEntrada(orden.IdOsI, st, orden.asignadoA)

        destinario = [orden.CreadoPor.email]
        asunto = "LogiX: Orden de entrada finalizada ("+str(orden.Folio)+")"
        correoEntrada(destinario, asunto, orden)

        messages.success(request, "La orden de entrada " +
                         orden.Folio + " fue concluida correctamente.")
        return redirect("/")

    materiales = MatOrdenEntrada.objects.filter(IdOsI=IdOs)
    ubtec = UbicacionesTecnicas.objects.all()

    totalMateriales = len(materiales)

    materialesLiberados = MatOrdenEntrada.objects.filter(IdOsI=IdOs).exclude(
        UbicacionTecnicaDestino__isnull=True).exclude(NumEtiqueta__isnull=True)
    materialesLiberados = len(materialesLiberados)

    if totalMateriales == materialesLiberados:

        flag = True
    else:
        flag = False

        #

    for i in materiales:
        if Inventario.objects.filter(IdMat=i.IdMat).filter(IdAlmacen=orden.IdDestino.IdSitio).exclude(IdUbicacionTec__isnull=True).exists():

            i.ubsuge = Inventario.objects.values('IdUbicacionTec__Descripcion', 'IdUbicacionTec').filter(IdMat=i.IdMat).filter(
                IdAlmacen=orden.IdDestino.IdSitio).exclude(IdUbicacionTec__isnull=True).annotate(Count('IdUbicacionTec'))

        else:

            i.ubsuge = None

    return render(request, "ingresarOrdenEntrada.html", {
        'orden': orden,
        'materiales': materiales,
        'ubtec': ubtec,
        'flag': flag

    })


@login_required
def recolectado(request, IdOs):

    orden = OrdenSalida.objects.get(IdOs=IdOs)
    orden.IdStatus = Estatus.objects.get(Id=5)
    currentUser = request.user
    logMovimiento(orden, Estatus.objects.get(Id=5),
                  User.objects.get(username=currentUser))

    orden.save()

    creador = orden.CreadoPor.email
    asunto = "LogiX: La orden ("+str(orden.Folio) + \
        ") fue recolectada en el almacen"
    correo(creador, asunto, orden)

    messages.success(request, "La orden " + orden.Folio +
                     " fue marcada como recolectada, puedes retirarte del almacen.")

    return redirect("/")


@login_required
def recolectarOrden(request, IdOs):

    if(request.user.profile.IdRol.NombreRol != "Encargado Almacen"):
        return render(request, "NoPermission.html")
    else:
        ordenARecolectar = OrdenSalida.objects.get(IdOs=IdOs)
        materiales = MatOrden.objects.filter(IdOs=IdOs)

    return render(request, "ordenARecolectar.html", {
        'ordenARecolectar': ordenARecolectar,
        'materiales': materiales,
    })


@login_required
def instalarEnSitio(request, IdOs):

    orden = OrdenSalida.objects.get(IdOs=IdOs)

    if orden.IdStatus.Id == 5 or orden.IdStatus.Id == 9:

        orden.IdStatus = Estatus.objects.get(Id=10)
        orden.save()
        creador = orden.CreadoPor.email
        asunto = "LogiX: Pendiente cierre de orden ("+str(orden.Folio)+")"
        correo(creador, asunto, orden)

        currentUserId = request.user
        logMovimiento(orden, Estatus.objects.get(Id=10),
                      User.objects.get(username=currentUserId))

        messages.success(
            request, "Los materiales se marcaron como instalados en sitio")

        return redirect("/")
    else:
        messages.success(request, "Ups! Algo Salio Mal")
        return redirect("/")


@login_required
def cerrarOrdenMovimiento(request, IdOs):
    if(request.user.profile.IdRol.IdRol == 1 or request.user.profile.IdRol.IdRol == 2 or request.user.profile.IdRol.IdRol == 10):

        orden = OrdenSalida.objects.get(IdOs=IdOs)
        orden.IdStatus = Estatus.objects.get(Id=11)

        currentUserId = request.user
        logMovimiento(orden, Estatus.objects.get(Id=11),
                      User.objects.get(username=currentUserId))

        orden.save()
        materiales = MatOrden.objects.filter(IdOs=IdOs)

        for m in materiales:
            if m.IdMaterialInventario.IdMat.Activo == 1:
                nuevaOrdenActivo = OrdenesActivoFijo(
                    IdOs=OrdenSalida.objects.get(IdOs=IdOs)
                )
                nuevaOrdenActivo.save()

                recolector = orden.recolectorAlmacen.email
                asunto = "LogiX: Movimiento de activos ("+str(orden.Folio)+")"
                correo(recolector, asunto, orden)
                break

        messages.success(request, "La orden de movimiento finalizó")

    else:
        return render(request, "NoPermission.html")

    return redirect("/")


@login_required
def guiasPendientes(request):

    #if(request.user.profile.IdRol.NombreRol != "Abastecimiento"):
    # Permitir acceso solo a Abastecimiento (rol 5) y Administrador (rol 10)
    if(request.user.profile.IdRol.IdRol not in [5, 10]):
        return render(request, "NoPermission.html")
    else:

        guiasPendientes = OrdenSalida.objects.filter(IdStatus=6)
        guiasGeneradas = PaqueteriaOs.objects.all()

    return render(request, "guiasPendientes.html", {
        'guiasPendientes': guiasPendientes,
        'guiasGeneradas': guiasGeneradas,

    })


@login_required
def ordenesActivoFijo(request):

    if(request.user.profile.IdRol.NombreRol != "Activo Fijo"):
        return render(request, "NoPermission.html")
    else:

        materiales = MatOrden.objects.all()
        ordenesActivoFijo = OrdenesActivoFijo.objects.all()

    return render(request, "ordenesActivoFijo.html", {
        'ordenesActivoFijo': ordenesActivoFijo,
        'materiales': materiales

    })


@login_required
def ordenesPendientes(request):

    if(request.user.profile.IdRol.NombreRol != "Encargado Almacen"):
        return render(request, "NoPermission.html")
    else:
        ordenesPendientes = OrdenSalida.objects.filter(IdStatus=2)

    return render(request, "ordenesPendientes.html", {
        'ordenesPendientes': ordenesPendientes,
    })


@login_required
def cancelarOrden(request, IdOs, IdStatus):

    orden = OrdenSalida.objects.get(IdOs=IdOs)

    if request.method == "POST":
        cancelacion = OrdenesCanceladas(
            IdOs=OrdenSalida.objects.get(IdOs=IdOs),
            Descripcion=request.POST['descripcion']
        )
        cancelacion.save()

        messages.success(request, "La orden fue cancelada correctamente")
        return redirect("/aprovador/"+IdOs+"/"+IdStatus)

    return render(request, "cancelarOrden.html", {
        'orden': orden,
        'IdOs': IdOs,
        'IdStatus': IdStatus


    })


@login_required
def aprovador(request, IdOs, IdStatus):

    if IdStatus == "2":
        orden = OrdenSalida.objects.get(IdOs=IdOs)
        orden.IdStatus = Estatus.objects.get(Id=2)
        orden.save()

        creador = orden.CreadoPor.email
        logMovimiento(orden, Estatus.objects.get(Id=2), orden.Aprovador)

        asunto = "LogiX: Orden aprobada ("+str(orden.Folio)+")"
        correo(creador, asunto, orden)

        recolector = orden.recolectorAlmacen.email
        asunto = "LogiX: Recolección pendiente ("+str(orden.Folio)+")"
        correo(recolector, asunto, orden)

        messages.success(request, "La orden de salida " +
                         orden.Folio + " fue aprobada correctamente")

    if IdStatus == "3":

        orden = OrdenSalida.objects.get(IdOs=IdOs)
        matOrden = MatOrden.objects.filter(IdOs=IdOs)

        for i in matOrden:

            materialADescontar = Inventario.objects.get(
                Id=i.IdMaterialInventario.Id)

            materialADescontar.CtdRes = materialADescontar.CtdRes - i.CtdSolicitada
            materialADescontar.CtdDis = materialADescontar.CtdDis + i.CtdSolicitada

            materialADescontar.save()
        orden.IdStatus = Estatus.objects.get(Id=3)
        orden.save()

        creador = orden.CreadoPor.email
        logMovimiento(orden, Estatus.objects.get(Id=3), orden.Aprovador)
        asunto = "LogiX: Orden rechazada ("+str(orden.Folio)+")"
        correo(creador, asunto, orden)

        messages.success(
            request, "La orden de Salida fue rechazada correctamente")
        return redirect("/")

    return redirect("/")


def get_auth_token(auth_url, username, password):
    """Authenticate with the API and return JWT token."""
    try:
        auth_payload = {
            'username': username,
            'password': password
        }
        auth_response = requests.post(
            f"{auth_url}/auth/login",
            json=auth_payload,
            timeout=15
        )
        auth_response.raise_for_status()
        return auth_response.json().get('token')
    except Exception as e:
        print(f"Authentication error: {e}")
        return None


def generarTicketSD(sitioAlmacen, telefono, nombre, fechaInicioAct, fechaFinAct, description):
    base_url = 'https://chatbotapi.gtac.com.mx'
    auth_token = get_auth_token(
        base_url,
        username=os.getenv('API_USERNAME'),
        password=os.getenv('API_PASSWORD')
    )

    if not auth_token:
        print("Failed to authenticate with the API")
        return None

    url = f'{base_url}/api/createSDLogixTicket'
    
    payload = {
        'start_date_value': str(fechaInicioAct),
        'end_date_value': str(fechaFinAct),
        'assets_name': str(sitioAlmacen),
        'description': str(description),
        'phone': str(telefono),
        'name': str(nombre)
    }
 
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {auth_token}'
    }
 
    try:
        response = requests.post(url, json=payload, headers=headers, timeout=15)
        response.raise_for_status()
        service_desk_id = response.json().get('folio', None)
    except Timeout:
        return "Intermitencia detectada"
    except Exception as e:
        print(f"ERROR: {e}")
        return None 
   
    return service_desk_id


@login_required
def nuevoTicketSDSalida(request, IdOs):
    if request.method == "POST":
        orden = OrdenSalida.objects.get(IdOs=IdOs)
        fechaInicio = request.POST['fechaInicio']
        fechaFin = request.POST['fechaFin']
        refresh = request.POST['refresh']

        if orden.IdServiceDesk == None or refresh:
            recolector = Profile.objects.get(user=orden.recolectorAlmacen)
            sitioAlmacen = orden.IdOrigen.Nombre
            telefono = recolector.Telefono
            nombre = orden.recolectorAlmacen.first_name

            d = datetime.strptime(fechaInicio, "%Y-%m-%dT%H:%M")
            d = d + timedelta(hours=5)
            estampa1 = int(d.timestamp()*1000)

            f = datetime.strptime(fechaFin, "%Y-%m-%dT%H:%M")
            f = f + timedelta(hours=5)
            estampa2 = int(f.timestamp()*1000)

            materiales = MatOrden.objects.filter(IdOs=IdOs)

            description = "Orden de salida: "+orden.Folio

            if len(request.POST['personaExtra']) != 0:
                description = description + "  Persona Extra: " + \
                    request.POST['personaExtra']

            orden.IdServiceDesk = generarTicketSD(
                sitioAlmacen, telefono, nombre, str(estampa1), str(estampa2), description)
            orden.FechaTicketEntradaSD = fechaInicio
            orden.FechaTicketSalidaSD = fechaFin
            orden.save()
            messages.success(request, f"El ticket fue generado correctamente: '{orden.IdServiceDesk}'")
        else:
            messages.success(request, "Ups! Ocurrio un error")

        return redirect("/ordenesPorRecolectarAlmacen")


@login_required
def nuevoTicketSD(request, IdOsI):
    if request.method == "POST":
        orden = OrdenEntrada.objects.get(IdOsI=IdOsI)
        fechaInicio = request.POST['fechaInicio']
        fechaFin = request.POST['fechaFin']
        refresh = request.POST['refresh']

        if orden.IdServiceDesk == None or refresh:
            recolector = Profile.objects.get(user=orden.asignadoA)
            sitioAlmacen = orden.IdDestino.Nombre
            telefono = recolector.Telefono
            nombre = orden.asignadoA.first_name

            d = datetime.strptime(fechaInicio, "%Y-%m-%dT%H:%M")
            d = d + timedelta(hours=5)
            estampa1 = int(d.timestamp()*1000)

            f = datetime.strptime(fechaFin, "%Y-%m-%dT%H:%M")
            f = f + timedelta(hours=5)
            estampa2 = int(f.timestamp()*1000)

            materiales = MatOrdenEntrada.objects.filter(IdOsI=IdOsI)

            description = "Orden de entrada: "+orden.Folio+" { Materiales: "

            for i in materiales:
                description = description + \
                    str(i.IdMat.SKU)+"-"+str(i.CtdEntrada) + \
                    "-"+str(i.NumeroSerie)+" || "

            description = description+"}"

            if len(request.POST['personaExtra']) != 0:
                description = description + "  Persona Extra: " + \
                    request.POST['personaExtra']

            orden.IdServiceDesk = generarTicketSD(
                sitioAlmacen, telefono, nombre, str(estampa1), str(estampa2), description)
            orden.FechaTicketEntradaSD = fechaInicio
            orden.FechaTicketSalidaSD = fechaFin
            orden.save()
            messages.success(request, "El ticket fue generado correctamente")
        else:
            messages.success(request, "Ups! Ocurrio un error")

        return redirect("/ingresosAInventario")


@login_required
def aprovadorEntrada(request, IdOs, IdStatus):

    if IdStatus == "2":

        orden = OrdenEntrada.objects.get(IdOsI=IdOs)
        orden.IdStatus = Estatus.objects.get(Id=2)
        orden.save()

        st = Estatus.objects.get(Id=2)
        logEntrada(IdOs, st, orden.Aprovador)

        destinatarios = [orden.CreadoPor.email]
        asunto = "LogiX: Orden de entrada aprobada ("+str(orden.Folio)+")"
        correoEntrada(destinatarios, asunto, orden)

        destinatarios = [orden.asignadoA.email]
        asunto = "LogiX: Orden de entrada pendiente de ingresar ("+str(
            orden.Folio)+")"
        correoEntrada(destinatarios, asunto, orden)

        messages.success(request, "La orden de entrada " +
                         str(orden.Folio) + " fue aprobada correctamente")

    if IdStatus == "3":

        orden = OrdenEntrada.objects.get(IdOsI=IdOs)

        orden.IdStatus = Estatus.objects.get(Id=3)
        st = Estatus.objects.get(Id=3)
        orden.save()
        logEntrada(IdOs, st, orden.Aprovador)

        destinatarios = [orden.CreadoPor.email]
        asunto = "logiX: Orden de entrada rechazada ("+str(orden.Folio)+")"
        correoEntrada(destinatarios, asunto, orden)

        messages.success(request, "La orden de entrada" +
                         str(orden.Folio) + " fue rechazada correctamente")
        return redirect("/")

    return redirect("/")


@login_required
def aprovarOrden(request, IdOs):

    orden = OrdenSalida.objects.get(IdOs=IdOs)
    materiales = MatOrden.objects.filter(IdOs=IdOs)

    return render(request, "aprovarOrden.html", {'orden': orden, 'materiales': materiales})


@login_required
def datosOrdenEntrada(request):

    if len(request.session['materiales']) == 0:
        messages.success(
            request, "El carrito de materiales no puede estar vacio")

        return redirect("/nuevaOrdenEntrada")

    else:

        IdArea = request.user.profile.Area.Id

        almacenes = Sitios.objects.filter(EsAlmacen=1)
        usuarios = Profile.objects.filter(Q(Area=IdArea) | Q(IdRol=6))

        return render(request, "datosOrdenEntrada.html", {"almacenes": almacenes,
                                                          "usuarios": usuarios,
                                                          'materiales': request.session['materiales']
                                                          })


@login_required
def aprovarOrdenEntrada(request, IdOs):

    orden = OrdenEntrada.objects.get(IdOsI=IdOs)
    materiales = MatOrdenEntrada.objects.filter(IdOsI=IdOs)

    return render(request, "aprovarOrdenEntrada.html", {'orden': orden, 'materiales': materiales})


@login_required
def marcarPaqueteRecibido(request, IdOs):
    currentUser = request.user

    orden = OrdenSalida.objects.get(IdOs=IdOs)

    if request.method == "POST":
        ordenPaq = PaqueteriaOs.objects.get(IdOs=IdOs)
        ordenPaq.EstadoRecepcionPaquete = request.POST['estadoRecepcionPaquete']
        ordenPaq.save()

        orden.IdStatus = Estatus.objects.get(Id=9)

        currentUserId = request.user
        logMovimiento(orden, Estatus.objects.get(Id=9),
                      User.objects.get(username=currentUser))

        orden.save()

        creador = orden.CreadoPor.email
        asunto = "LogiX: Orden recolectada ("+str(orden.Folio)+")"
        correo(creador, asunto, orden)

        messages.success(request, "El paquete fue marcado como recepcionado")
        return redirect("/")

    return render(request, "marcarPaqueteRecibido.html", {'orden': orden})


@login_required
def ordenesPorAprovar(request):

    ordenesSalidaPorAprobar = OrdenSalida.objects.filter(
        Aprovador=request.user).filter(IdStatus=1)
    ordenesEntradaPorAprobar = OrdenEntrada.objects.filter(
        Aprovador=request.user).filter(IdStatus=1)
    ordenesPorAprobar = chain(ordenesSalidaPorAprobar,
                              ordenesEntradaPorAprobar)

    ordenesSalidaAprobadas = OrdenSalida.objects.filter(
        Aprovador=request.user).exclude(IdStatus=1)
    ordenesEntradaAprobadas = OrdenEntrada.objects.filter(
        Aprovador=request.user).exclude(IdStatus=1)
    ordenesAprobadas = chain(ordenesSalidaAprobadas, ordenesEntradaAprobadas)

    return render(request, "ordenesPorAprovar.html", {
        'ordenesPorAprobar': ordenesPorAprobar,
        'ordenesAprobadas': ordenesAprobadas

    })


@login_required
def ordenesPorRecolectarAlmacen(request):

    recolectorAlmacen = OrdenSalida.objects.filter(
        Q(recolectorAlmacen=request.user)

    ).exclude(IdStatus=1).exclude(IdStatus=3).exclude(IdStatus=11)

    return render(request, "ordenesPorRecolectarAlmacen.html", {
        'recolectorAlmacen': recolectorAlmacen,

    })


@login_required
def ordenesPorRecolectarPaqueteria(request):

    recolectorPaqueteria = OrdenSalida.objects.filter(
        Q(recolectorPaqueteria=request.user)

    ).exclude(IdStatus=1).exclude(IdStatus=3).exclude(IdStatus=11)

    return render(request, "ordenesPorRecolectarPaqueteria.html", {

        'recolectorPaqueteria': recolectorPaqueteria
    })


@login_required
def conmutador(request):
    
    # Verificar que el usuario tenga un perfil válido
    if not hasattr(request.user, 'profile') or not request.user.profile:
        return redirect('/accounts/login/')
    
    try:
        rol = request.user.profile.IdRol.IdRol
    except:
        return redirect('/accounts/login/')

    # Usuario Solicitante
    if(rol == 1):
        return redirect("/misOrdenesDeSalida")

    # Proveedor
    if(rol == 4):
        return redirect("/ordenesPorRecolectarAlmacen")

    # Aprovador
    if(rol == 2):
        return redirect("/ordenesPorAprovar")

    # Encargado Alamacen
    if(rol == 3 or rol == 8 or rol == 9 or rol == 10):
        return redirect("/ordenesSalidaApr")

    # Abastecimiento
    if(rol == 5):
        return redirect("/guiasPendientes")

    # Recolector
    if(rol == 6):
        return redirect("/ordenesPorRecolectarAlmacen")

     # Activo Fijo
    if(rol == 7):
        return redirect("/ordenesActivoFijo")

    return HttpResponse(rol)


@login_required
def generarGuia(request, IdOs):
    currentUser = request.user

    orden = OrdenSalida.objects.get(IdOs=IdOs)
    envio = PaqueteriaOs.objects.get(IdOs=IdOs)
    provPaqueteria = PaqueteriaProv.objects.all()

    if request.method == "POST":
        if len(request.POST['guias']) <= 1:
            messages.success(
                request, "El campo de las guias no puede estar vacio")

        else:
            ordenPaq = PaqueteriaOs.objects.get(IdOs=IdOs)
            ordenPaq.DescripcionDelEnvio = request.POST['guias']

            orden.IdStatus = Estatus.objects.get(Id=7)

            logMovimiento(orden, Estatus.objects.get(Id=7),
                          User.objects.get(username=currentUser))
            ordenPaq.save()
            orden.save()

            creador = orden.recolectorAlmacen.email
            asunto = "LogiX: Guías disponibles ("+str(orden.Folio)+")"
            correo(creador, asunto, orden)

            messages.success(request, "Guía liberada correctamente")
            return redirect("/")

    return render(request, 'generarGuia.html', {
        'orden': orden,
        'envio': envio,
        'provPaqueteria': provPaqueteria
    })


@login_required
def verGuias(request, IdOs):

    currentUser = request.user
    orden = OrdenSalida.objects.get(IdOs=IdOs)
    ordenpaq = PaqueteriaOs.objects.get(IdOs=IdOs)
    if request.method == "POST":
        orden.IdStatus = Estatus.objects.get(Id=8)

        logMovimiento(orden, Estatus.objects.get(Id=8),
                      User.objects.get(username=currentUser))

        orden.save()

        creador = orden.CreadoPor.email
        asunto = "LogiX: Orden entregada en paquetería ("+str(orden.Folio)+")"
        correo(creador, asunto, orden)

        recolectorPaqueteria = orden.recolectorPaqueteria.email
        asunto = "Logix: Recolección en paquetería pendiente ("+str(
            orden.Folio)+")"
        correo(recolectorPaqueteria, asunto, orden)

        messages.success(
            request, "La orden se marcó como entregada en paquetería.")
        return redirect("/")

    return render(request, 'verGuias.html', {
        'orden': orden,
        'ordenpaq': ordenpaq
    })


@login_required
def verDetallesOrdenSalida(request, IdOs):

    orden = OrdenSalida.objects.get(IdOs=IdOs)
    materiales = MatOrden.objects.filter(IdOs=IdOs)
    logs = LogsMovimientos.objects.filter(IdOs=IdOs)

    return render(request, 'verDetallesOrdenSalida.html', {
        'orden': orden,
        'materiales': materiales,
        'logs': logs
    })


@login_required
def detallesOrdenEntrada(request, IdOs):

    orden = OrdenEntrada.objects.get(IdOsI=IdOs)
    materiales = MatOrdenEntrada.objects.filter(IdOsI=IdOs)
    logs = LogsEntradas.objects.filter(IdOsI=IdOs)

    return render(request, 'detallesOrdenEntrada.html', {
        'orden': orden,
        'materiales': materiales,
        'logs': logs
    })


@login_required
def misOrdenesDeSalida(request):

    misOrdenesDeSalida = OrdenSalida.objects.filter(CreadoPor=request.user)

    return render(request, 'misOrdenesDeSalida.html', {
        'misOrdenesDeSalida': misOrdenesDeSalida,
        'label': "salida"


    })


@login_required
def misOrdenesDeEntrada(request):

    misOrdenesEntrada = OrdenEntrada.objects.filter(CreadoPor=request.user)

    return render(request, 'misOrdenesDeSalida.html', {

        'misOrdenesEntrada': misOrdenesEntrada,
        'label': "entrada"

    })


def logMovimiento(IdOs, IdStatus, Autor):

    nuevoLog = LogsMovimientos.objects.create(
        IdOs=IdOs,
        IdStatus=IdStatus,
        Autor=Autor
    )
    nuevoLog.save()


def logEntrada(IdOsI, IdStatus, Autor):

    nuevoLog = LogsEntradas.objects.create(
        IdOsI=OrdenEntrada.objects.get(IdOsI=IdOsI),
        IdStatus=Estatus.objects.get(Id=IdStatus.Id),
        Autor=User.objects.get(username=Autor)
    )
    nuevoLog.save()


def limpieza(IdOs):
    MatOrden.objects.filter(IdOs=OrdenSalida.objects.get(IdOs=IdOs))
    OrdenSalida.objects.get(IdOs=IdOs).delete()


@login_required
def finalizarOrdenSalida(request):
    currentUserId = request.user
    if(request.user.profile.IdRol.IdRol == 1 or request.user.profile.IdRol.IdRol == 2 or request.user.profile.IdRol.IdRol == 8 or request.user.profile.IdRol.IdRol == 9 or request.user.profile.IdRol.IdRol == 10):

        try:
            carrito = len(request.session['materialesDisponibles'])
        except:
            messages.success(request, "El carrito no puede estar vacio")
            return redirect("/ordenSalidaMateriales")

        if carrito == 0:
            messages.success(request, "El carrito no puede estar vacio")
            return redirect("/ordenSalidaMateriales")

        if request.session['esPaqueteria'] == "No":
            nuevaOrdenSalida = OrdenSalida.objects.create(
                CreadoPor=User.objects.get(username=currentUserId),
                Aprovador=User.objects.get(
                    username=request.session['aprovador']),
                IdDestino=Sitios.objects.get(
                    IdSitio=request.session['destinoMat']),
                IdOrigen=Sitios.objects.get(
                    IdSitio=request.session['origenMat']),
                TipoRecoleccion=request.session['tipoRecoleccion'],
                esPaqueteria=request.session['esPaqueteria'],
                recolectorAlmacen=User.objects.get(
                    username=request.session['recolectorAlmacen']),
                IdStatus=Estatus.objects.get(Id=1),
                comentarios=request.session['comentarios'],
                DateLimiteSD=request.session['fechaLimiteAlmacen']


            )

        else:

            nuevaOrdenSalida = OrdenSalida.objects.create(
                CreadoPor=User.objects.get(username=currentUserId),
                Aprovador=User.objects.get(
                    username=request.session['aprovador']),
                IdDestino=Sitios.objects.get(
                    IdSitio=request.session['destinoMat']),
                IdOrigen=Sitios.objects.get(
                    IdSitio=request.session['origenMat']),
                TipoRecoleccion=request.session['tipoRecoleccion'],
                esPaqueteria=request.session['esPaqueteria'],
                recolectorAlmacen=User.objects.get(
                    username=request.session['recolectorAlmacen']),
                recolectorPaqueteria=User.objects.get(
                    username=request.session['recolectorPaqueteria']),
                IdStatus=Estatus.objects.get(Id=1),
                comentarios=request.session['comentarios'],
                DateLimiteSD=request.session['fechaLimiteAlmacen']


            )

        nuevaOrdenSalida.save()
        nuevaOrdenSalidaId = nuevaOrdenSalida.IdOs
        logMovimiento(OrdenSalida.objects.get(IdOs=nuevaOrdenSalidaId), Estatus.objects.get(
            Id=1), User.objects.get(username=currentUserId))

        nuevaOrdenSalida = OrdenSalida.objects.get(IdOs=nuevaOrdenSalidaId)

        folio = str(nuevaOrdenSalidaId).zfill(5)

        nuevaOrdenSalida.Folio = "SA"+folio
        nuevaOrdenSalida.save()

        for i in range(len(request.session['materialesDisponibles'])):

            Id = request.session['materialesDisponibles'][i]['Id']
            cantidad = request.session['materialesDisponibles'][i]['Cantidad']

            MaterialAEditar = Inventario.objects.get(Id=Id)

            cantidadActualDelMaterial = MaterialAEditar.CtdDis

            if int(cantidadActualDelMaterial) < int(cantidad):
                messages.success(
                    request, "Algunos materiales ya han sido ocupados por otra orden, valida de nuevo!")
                request.session['materialesDisponibles'] = []
                limpieza(nuevaOrdenSalidaId)

                return redirect("/")

            else:
                cantidadActualReservada = MaterialAEditar.CtdRes

                nuevaCantidad = int(cantidadActualDelMaterial) - int(cantidad)

                MaterialAEditar.CtdDis = nuevaCantidad
                MaterialAEditar.CtdRes = int(
                    cantidadActualReservada) + int(cantidad)

                MaterialAEditar.save()

                nuevaMatOrden = MatOrden(
                    IdOs=OrdenSalida.objects.get(IdOs=nuevaOrdenSalidaId),
                    IdMaterialInventario=Inventario.objects.get(Id=Id),
                    IdAlmacen=Sitios.objects.get(
                        IdSitio=request.session['origenMat']),
                    StatusMaterial="Por Recolectar",
                    CtdSolicitada=cantidad
                )
                nuevaMatOrden.save()

        try:
            request.session['materialesDisponibles'] = []
        except:
            pass

        aprobador = User.objects.get(username=request.session['aprovador'])
        asunto = "LogiX: Orden por aprobar ("+str(nuevaOrdenSalida.Folio)+")"
        correo(aprobador.email, asunto, nuevaOrdenSalida)
        request.session['materialesDisponibles'] = []
        messages.success(request, "Orden " +
                         str(nuevaOrdenSalida.Folio)+" Creada Correctamente")
        return redirect('/')

    else:

        return render(request, "NoPermission.html")
    return redirect('/')


def correo(destinatarios, asunto, orden):

    tabla = "<table style='width:100%; text-align:center;border:1px solid black;'><thead><th>SKU</th><th>Texto breve</th><th>Cantidad</th></thead><tbody>"

    materiales = MatOrden.objects.filter(IdOs=orden.IdOs)

    for m in materiales:
        tabla = tabla+"<tr><td>{}</td><td>{}</td><td>{}</td>".format(
            m.IdMaterialInventario.IdMat.SKU, m.IdMaterialInventario.IdMat.TextoBreve, m.CtdSolicitada)
        tabla = tabla+"</tr>"

    tabla = tabla+"</tbody></table>"

    contenido = " <h3>Datos generales:</h3> <p>Creador: {} {}</p><p>Folio: {}</p><p>Tipo de Recolección: {}</p><p>Paquetería: {}</p>   <p>Sitio destino: {}</p>  <p>Almacén Origen: {}</p> <br> <h3>Materiales solicitados:</h3> {}  {}".format(
        orden.CreadoPor.first_name, orden.CreadoPor.last_name, orden.Folio, orden.TipoRecoleccion, orden.esPaqueteria, orden.IdDestino.Nombre, orden.IdOrigen.Nombre, tabla, "<p>Para revisar la orden ingresa a: </p><a href='https://logix.gtac.com.mx'>GTAC Almacenes</a>")

    message = Mail(
        from_email='notificaciones@gtac.com.mx',
        to_emails=destinatarios,
        subject=asunto,
        html_content=contenido)

    sg = SendGridAPIClient(
        "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")
    response = sg.send(message)


def correoReenvioPwd(destinatarios, pwd, username):

    contenido = "<h1>Su contraseña se ha restablecido exitosamente, las credenciales de acceso son:</h1><br><p>User: " + \
        username+"</p><br><p>Password: "+pwd+"</p>"

    message = Mail(
        from_email='notificaciones@gtac.com.mx',
        to_emails=destinatarios,
        subject="Restablecimiento de contraseña: LOGIX GTAC",
        html_content=contenido)

    sg = SendGridAPIClient(
        "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")
    response = sg.send(message)


@login_required
def añadirMat(request=None, IdMatInv=None, SKU=None, IdMat=None):

    if request.path == "/añadirMat/carga/":

        materiales = request.POST['materiales']

        if len(materiales) == 0:
            messages.success(request, "No has seleccionado ningun material")
            return redirect("/ordenSalidaMateriales")
        else:
            materiales = materiales.split(",")
            for mat in materiales:
                materialAVerificar = Inventario.objects.get(Id=mat)
                try:
                    request.session['materialesDisponibles'].append(
                        {'Id': mat, 'Cantidad': 1, 'SKU': materialAVerificar.IdMat.SKU, 'IdMat': materialAVerificar.IdMat.IdMat})

                except:
                    request.session['materialesDisponibles'] = [
                        {'Id': mat, 'Cantidad': 1, 'SKU': materialAVerificar.IdMat.SKU, 'IdMat': materialAVerificar.IdMat.IdMat}]

            request.session.modified = True
            return redirect("/ordenSalidaMateriales")

    if request.method == "POST":

        cantidad = request.POST['cantidad']
        mato = Inventario.objects.get(Id=IdMatInv)

        if int(mato.CtdDis) < int(cantidad):
            messages.success(
                request, "La cantidad que intentas ingresar es mayor a la disponible.")
        else:

            Id = IdMatInv

            if 'materialesDisponibles' in request.session:

                materialAVerificar = Inventario.objects.get(Id=Id)
                ctdDis = materialAVerificar.CtdDis
                matCat = Materiales.objects.get(
                    IdMat=materialAVerificar.IdMat.IdMat)

                tamañoDelArreglo = int(
                    len(request.session['materialesDisponibles']))
                ultimaIteracion = tamañoDelArreglo + 1

                for i in range(ultimaIteracion):
                    try:
                        if request.session['materialesDisponibles'][i]['Id'] == Id:

                            if materialAVerificar.IdMat.Tipo.Id == 2:
                                messages.success(
                                    request, "El material ya esta en el carrito")
                                break

                            cantidadAntigua = request.session['materialesDisponibles'][i]['Cantidad']

                            if int(cantidadAntigua)+int(cantidad) > ctdDis:
                                messages.success(
                                    request, "La cantidad que intentas ingresar es mayor a la disponible.")

                                break
                            else:

                                if matCat.Activo == 1:

                                    if int(cantidad) != 1:
                                        messages.success(
                                            request, "Los materiales que son activos solo los puedes ingresar de uno en uno.")
                                        break

                                    else:

                                        try:

                                            a = int(cantidad)
                                            for i in range(tamañoDelArreglo):

                                                if request.session['materialesDisponibles'][i]['Id'] == Id:
                                                    actdAntigua = request.session['materialesDisponibles'][i]['Cantidad']
                                                    actdAntigua = int(
                                                        actdAntigua)
                                                    a = a+actdAntigua

                                            if int(a) > int(ctdDis):
                                                messages.success(
                                                    request, "La cantidad que intentas ingresar es mayor a la disponible.")
                                                break

                                            else:
                                                request.session['materialesDisponibles'].append(
                                                    {'Id': Id, 'Cantidad': cantidad, 'SKU': SKU, 'IdMat': IdMat})

                                                break
                                        except Exception as e:
                                            print(e)

                                else:

                                    request.session['materialesDisponibles'][i]['Cantidad'] = int(
                                        cantidadAntigua)+int(cantidad)

                                    break

                    except:

                        request.session['materialesDisponibles'].append(
                            {'Id': Id, 'Cantidad': cantidad, 'SKU': SKU, 'IdMat': IdMat})

            else:
                request.session['materialesDisponibles'] = [
                    {'Id': Id, 'Cantidad': cantidad, 'SKU': SKU, 'IdMat': IdMat}]

            request.session.modified = True
    return redirect("/ordenSalidaMateriales")


@login_required
def materialModo(request, modo, IdMat=None):

    if modo == "eliminar":

        for i in range(len(request.session['materialesDisponibles'])):
            if request.session['materialesDisponibles'][i]['Id'] == IdMat:
                del request.session['materialesDisponibles'][i]
                break

        request.session.modified = True

    else:

        if modo == "LimpiarTodo":
            try:
                request.session['materialesDisponibles'] = []
            except:
                pass
        else:

            if 'materialesDisponibles' in request.session:
                request.session['materialesDisponibles'].append({'Id': IdMat})

            else:
                request.session['materialesDisponibles'] = [{'Id': IdMat}]

        request.session.modified = True

    return redirect("/ordenSalidaMateriales")


@login_required
def ordenSalidaDatosGenerales(request):

    request.session['aprovador'] = ""
    request.session['origenMat'] = ""
    request.session['destinoMat'] = ""
    request.session['idTipoEnvio'] = ""
    request.session['comentarios'] = ""

    sitios = Sitios.objects.filter(EsAlmacen=0)
    almacenes = Sitios.objects.filter(EsAlmacen=1).filter(Tipo="Refacciones")
    materialesDisponibles = Inventario.objects.all()

    asignadoA = User.objects.all()

    try:
        materialesCarrito = request.session['materialesDisponibles']
    except:
        materialesCarrito = "0"

    if request.method == "POST":

        aprovador = request.POST['aprovador']
        origenMat = request.POST['origenMat']
        destinoMat = request.POST['destinoMat']
        tipoRecoleccion = request.POST['tipoRecoleccion']
        comentarios = request.POST['comentarios']

        request.session['aprovador'] = aprovador
        request.session['origenMat'] = origenMat
        request.session['destinoMat'] = destinoMat
        request.session['tipoRecoleccion'] = tipoRecoleccion
        request.session['comentarios'] = comentarios

        return redirect("/ordenSalidaDatosDeEnvio")

    return render(request, 'ordenSalidaDatosGenerales.html', {
        'almacenes': almacenes,
        'sitios': sitios,
        'asignadoA': asignadoA,


    })


@login_required
def ordenSalidaMateriales(request, SKU=None):

    proveedores = Profile.objects.filter(IdRol=4)
    materialesDisponiblesActivo = Inventario.objects.values('IdMat').filter(IdMat__Tipo=2).filter(
        IdAlmacen=request.session['origenMat']).exclude(CtdDis=0).annotate(count=Count('IdMat')).exclude(IdUbicacionTec__isnull=True)
    materialesDisponiblesGranel = Inventario.objects.filter(IdMat__Tipo=1).filter(
        IdAlmacen=request.session['origenMat']).exclude(CtdDis=0).exclude(IdUbicacionTec__isnull=True)
    todosLosMateriales = Inventario.objects.filter(
        IdAlmacen=request.session['origenMat']).exclude(CtdDis=0).filter(IdMat__Tipo=2)

    for todos in todosLosMateriales:
        todos.enCarrito = 0

    try:
        materialesCarrito = request.session['materialesDisponibles']

        for inv in materialesDisponiblesGranel:
            for car in materialesCarrito:
                if(int(car['Id']) == int(inv.Id)):
                    inv.CtdDis = inv.CtdDis - int(car['Cantidad'])

    except Exception as e:
        print(e)

    try:

        for act in materialesDisponiblesActivo:
            for car in materialesCarrito:
                if(int(car['IdMat']) == int(act['IdMat'])):
                    act['count'] = int(act['count']) - 1

    except Exception as e:
        print(e)

    try:

        for todos in todosLosMateriales:
            for car in materialesCarrito:
                if int(car['Id']) == int(todos.Id):
                    todos.enCarrito = 1

    except Exception as e:
        print(e)

    for i in materialesDisponiblesActivo:
        mat = Materiales.objects.get(IdMat=i['IdMat'])

        i['TextoBreve'] = mat.TextoBreve
        i['SKU'] = mat.SKU

    nombreAprovador = User.objects.get(username=request.session['aprovador'])
    nombreOrigenMat = Sitios.objects.get(IdSitio=request.session['origenMat'])
    nombreDestinoMat = Sitios.objects.get(
        IdSitio=request.session['destinoMat'])
    recolectorAlmacen = User.objects.get(
        username=request.session['recolectorAlmacen'])

    if request.session['tipoRecoleccion'] == "Medios propios" and request.session['esPaqueteria'] == "Si":
        recolectorPaqueteria = User.objects.get(
            username=request.session['recolectorPaqueteria'])
    else:
        recolectorPaqueteria = "No Aplica"

    aprovadorNombreCompleto = nombreAprovador.first_name + " "+nombreAprovador.last_name

    try:
        materialesCarrito = request.session['materialesDisponibles']
        for i in materialesCarrito:

            mat = Inventario.objects.get(Id=i['Id'])
            i['TextoBreve'] = mat.IdMat.TextoBreve

            if mat.IdMat.Tipo.Id == 2:
                i['ComEn'] = mat.DescripcionEntrada
                i['Flag'] = True
            else:
                i['Flag'] = False

        listaId = request.session['listaId']

    except:
        materialesCarrito = 0
        request.session['listaId'] = []
        listaId = request.session['listaId']

    return render(request, 'ordenSalidaMateriales.html', {
        'esPaqueteria': request.session['esPaqueteria'],
        'recolectorAlmacen': recolectorAlmacen,
        'recolectorPaqueteria': recolectorPaqueteria,
        'proveedores': proveedores,
        'listaId': listaId,
        'aprovador': aprovadorNombreCompleto,
        'origenMat': nombreOrigenMat.Nombre,
        'destinoMat': nombreDestinoMat.Nombre,
        'materialesDisponiblesActivo': materialesDisponiblesActivo,
        'materialesDisponiblesGranel': materialesDisponiblesGranel,
        'todosLosMateriales': todosLosMateriales,
        'materialesCarrito': materialesCarrito,
        'tipoRecoleccion': request.session['tipoRecoleccion']

    })


def inMat(request, material, cantidad, tipo, descIte, nserie, nActivo):

    if 'matIn' in request.session:

        if int(tipo) == 2:

            try:
                Id = request.session['matIn'][-1]['Id']
                request.session['matIn'].append({'Id': int(Id)+1, 'IdMat': material.IdMat, 'SKU': material.SKU,
                                                'Txt': material.TextoBreve, 'Ctd': cantidad, 'descIte': descIte, 'nserie': nserie, 'nActivo': nActivo})
                request.session.modified = True
            except Exception as e:

                request.session['matIn'].append({'Id': 1, 'IdMat': material.IdMat, 'SKU': material.SKU,
                                                'Txt': material.TextoBreve, 'Ctd': cantidad, 'descIte': descIte, 'nserie': nserie, 'nActivo': nActivo})
                request.session.modified = True

        else:
            try:
                for i in range(len(request.session['matIn'])):

                    if request.session['matIn'][i]["IdMat"] == material.IdMat:

                        ctdOld = int(request.session['matIn'][i]["Ctd"])
                        request.session['matIn'][i]["Ctd"] = ctdOld + \
                            int(cantidad)
                        request.session.modified = True
                        return

                raise ValueError('Error')

            except ValueError:
                try:
                    Id = request.session['matIn'][-1]['Id']
                except:
                    Id = 0

                request.session['matIn'].append({'Id': int(
                    Id)+1, 'IdMat': material.IdMat, 'SKU': material.SKU, 'Txt': material.TextoBreve, 'Ctd': cantidad})
                request.session.modified = True

    else:

        if int(tipo) == 2:
            request.session['matIn'].append({'Id': 1, 'IdMat': material.IdMat, 'SKU': material.SKU,
                                            'Txt': material.TextoBreve, 'Ctd': cantidad, 'descIte': descIte, 'nserie': nserie})
            request.session.modified = True

        else:
            request.session['matIn'].append(
                {'Id': 1, 'IdMat': material.IdMat, 'SKU': material.SKU, 'Txt': material.TextoBreve, 'Ctd': cantidad})
            request.session.modified = True


def cleanMat(request):
    request.session['matIn'] = []
    request.session.modified = True

    return redirect("/ingresarMaterial/")


def delMat(request, Id):

    for i in range(len(request.session['matIn'])):
        if request.session['matIn'][i]["Id"] == int(Id):
            del request.session['matIn'][i]
            break

    request.session.modified = True


@login_required
def ingresarMaterial(request, Id=None):
    IdArea = request.user.profile.Area.Id

    if 'matIn' in request.session:
        pass
    else:
        request.session['matIn'] = []

    if Id != None:
        delMat(request, Id)

    if request.path == "/ingresarMaterial/clean":
        cleanMat(request)

    catalogo = Materiales.objects.all()
    almacenes = Sitios.objects.filter(EsAlmacen=1)
    usuarios = Profile.objects.filter(Q(Area=IdArea) | Q(IdRol=6))

    if request.method == "POST":

        idMat = request.POST['mat']
        tipo = request.POST['tipo']

        material = Materiales.objects.get(IdMat=idMat)

        if int(tipo) == 1:
            cantidad = request.POST["ctdCon"]
            descIte = None
            nserie = None
            nActivo = None

        if int(tipo) == 2:
            cantidad = 1

            if 'nActivo' in request.POST:
                nActivo = request.POST['nActivo']
            else:
                nActivo = ""

            descIte = request.POST["descIte"]
            nserie = request.POST["nserieIte"]

            if len(descIte) == 0 or len(nserie) == 0:
                messages.success(
                    request, "Llena todos los campos correspondientes")
                return redirect('/ingresarMaterial')

        inMat(request, material, cantidad, tipo, descIte, nserie, nActivo)

    return render(request, "ingresarMaterial.html", {
        'catalogo': catalogo,
        'almacenes': almacenes,
        'matIn': request.session['matIn'],
        'usuarios': usuarios
    })


def correoEntrada(destinatarios, asunto, orden):

    tabla = "<table style='width:100%; text-align:center;border:1px solid black;'><thead><th>SKU</th><th>Texto breve</th><th>Cantidad</th><th>Número activo fijo</th><th>Número de serie</th></thead><tbody>"

    materiales = MatOrdenEntrada.objects.filter(IdOsI=orden.IdOsI)

    for m in materiales:

        tabla = tabla+"<tr><td>{}</td><td>{}</td><td>{}</td><td>{}</td><td>{}</td>".format(
            m.IdMat.SKU, m.IdMat.TextoBreve, m.CtdEntrada, m.NumActivo, m.NumeroSerie)
        tabla = tabla+"</tr>"

    tabla = tabla+"</tbody></table>"

    contenido = " <h3>Datos generales:</h3> <p>Creador: {} {}</p><p>Folio: {}</p><p>Almacen: {}</p><br> <h3>Materiales solicitados:</h3> {}  {}".format(
        orden.CreadoPor.first_name, orden.CreadoPor.last_name, orden.Folio, orden.IdDestino.Nombre, tabla, "<p>Para revisar la orden ingresa a: </p><a href='https://logix.gtac.com.mx'>GTAC Almacenes</a>")

    message = Mail(
        from_email='notificaciones@gtac.com.mx',
        to_emails=destinatarios,
        subject=asunto,
        html_content=contenido)

    sg = SendGridAPIClient(
        "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")
    response = sg.send(message)


@login_required
def finalizarOrdenEntrada(request):

    if request.method == "POST":

        nuevaOrdenEntrada = OrdenEntrada.objects.create(
            CreadoPor=User.objects.get(username=request.user),
            Aprovador=User.objects.get(username=request.POST["aprobador"]),
            IdDestino=Sitios.objects.get(IdSitio=request.POST["destino"]),
            IdStatus=Estatus.objects.get(Id=1),
            asignadoA=User.objects.get(username=request.POST["asignadoA"]),
            FechaLimiteSD=request.POST["fechalimiteSD"]
        )
        nuevaOrdenEntrada.save()
        nuevaOrdenEntradaId = nuevaOrdenEntrada.IdOsI

        logEntrada(nuevaOrdenEntradaId, nuevaOrdenEntrada.IdStatus,
                   nuevaOrdenEntrada.CreadoPor)

        nuevaOrdenEntrada = OrdenEntrada.objects.get(IdOsI=nuevaOrdenEntradaId)

        folio = str(nuevaOrdenEntradaId).zfill(5)

        nuevaOrdenEntrada.Folio = "EN"+folio
        nuevaOrdenEntrada.save()

        for i in request.session['materiales']:
            matIn = MatOrdenEntrada.objects.create(
                IdOsI=OrdenEntrada.objects.get(IdOsI=nuevaOrdenEntradaId),
                IdMat=Materiales.objects.get(IdMat=i['idMat']),
                StatusMaterial="Pendiente Etiqueta",
                CtdEntrada=i['cantidad'],
                DescripcionEntrada=i['descItem'],
                NumeroSerie=i['noSerie'],
                NumActivo=i['noActivo'],

            )
            matIn.save()

        destinatarios = [nuevaOrdenEntrada.CreadoPor.email]
        asunto = "LogiX: Orden de entrada por abrobar ("+str(
            nuevaOrdenEntrada.Folio)+")"
        correoEntrada(destinatarios, asunto, nuevaOrdenEntrada)
        messages.success(request, "Orden de entrada " +
                         str(nuevaOrdenEntrada.Folio)+" creada correctamente")
        request.session['matIn'] = []

    return redirect('/')


@login_required
def ordenSalidaDatosDeEnvio(request):

    proveedores = Profile.objects.filter(IdRol=4)

    nombreAprovador = User.objects.get(username=request.session['aprovador'])
    nombreOrigenMat = Sitios.objects.get(IdSitio=request.session['origenMat'])
    nombreDestinoMat = Sitios.objects.get(
        IdSitio=request.session['destinoMat'])

    aprovadorNombreCompleto = nombreAprovador.first_name + " "+nombreAprovador.last_name

    if request.method == "POST":

        request.session['esPaqueteria'] = request.POST['esPaqueteria']

        if request.session['tipoRecoleccion'] == "Proveedor":
            request.session['recolectorAlmacen'] = request.POST['proveedorAsignado']
            return redirect("/ordenSalidaMateriales")

        else:
            return redirect("/ordenSalidaDatosRecolector")

        # return redirect("/ordenSalidaDatosRecolector")

    return render(request, 'ordenSalidaDatosDeEnvio.html', {
        'tipoRecoleccion': request.session['tipoRecoleccion'],
        'proveedores': proveedores,

        'aprovador': aprovadorNombreCompleto,
        'origenMat': nombreOrigenMat.Nombre,
        'destinoMat': nombreDestinoMat.Nombre,
        'tipoRecoleccion': request.session['tipoRecoleccion']

    })


@login_required
def ordenSalidaDatosRecolector(request):

    IdArea = request.user.profile.Area.Id

    almacen = Sitios.objects.get(IdSitio=request.session['origenMat'])
    sitioDestino = Sitios.objects.get(IdSitio=request.session['destinoMat'])

    recolectoresArea = Profile.objects.filter(Area=IdArea).exclude(IdRol=6)
    fmsAlmacen = Profile.objects.filter(IdRol=6).filter(Zona=almacen.Zona)
    fmsDestino = Profile.objects.filter(IdRol=6).filter(Zona=sitioDestino.Zona)

    usrsAlmacen = recolectoresArea | fmsAlmacen
    usrsDestino = recolectoresArea | fmsDestino

    nombreAprovador = User.objects.get(username=request.session['aprovador'])
    nombreOrigenMat = Sitios.objects.get(IdSitio=request.session['origenMat'])
    nombreDestinoMat = Sitios.objects.get(
        IdSitio=request.session['destinoMat'])
    aprovadorNombreCompleto = nombreAprovador.first_name + " "+nombreAprovador.last_name

    if request.method == "POST":

        request.session['recolectorAlmacen'] = request.POST['recolectorAlmacen']
        request.session['fechaLimiteAlmacen'] = request.POST['fechalimiteSD']

        if (request.session['esPaqueteria'] == "No"):
            request.session['recolectorPaqueteria'] = "No aplica"

        else:

            request.session['recolectorPaqueteria'] = request.POST['recolectorPaqueteria']

        return redirect("/ordenSalidaMateriales")

    return render(request, 'ordenSalidaDatosRecolector.html', {

        'usrsAlmacen': usrsAlmacen,
        'usrsDestino': usrsDestino,
        'aprovador': aprovadorNombreCompleto,
        'origenMat': nombreOrigenMat,
        'destinoMat': nombreDestinoMat,
        'esPaqueteria': request.session['esPaqueteria']

    })
