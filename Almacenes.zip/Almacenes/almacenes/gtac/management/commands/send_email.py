from django.core.management.base import BaseCommand
from django.db import OperationalError
import threading
import schedule
import time


from gtac.views import thread_reporte_global
from gtac.models import CatalogoPES


MAX_RETRIES = 3
RETRY_DELAY = 5  # seconds


def fetch_catalogo_pes():
    retries = 0

    while retries < MAX_RETRIES:
        try:
            return [x.PES for x in CatalogoPES.objects.all()]
        
        except OperationalError as e:
            print(f"OperationalError encountered: {e}. Retrying...")
            retries += 1
            time.sleep(RETRY_DELAY)

        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            break

    if retries >= MAX_RETRIES:
        print(f'LIMIT EXCEEDED')

    return []


def my_periodic_task():
    print('STARTING')

    array_PES = fetch_catalogo_pes()

    if not array_PES:
        print("Failed to fetch data from CatalogoPES. Exiting task.")
        return

    print(array_PES)

    email_list = [
        'jorge.luis.paredes@huawei.com',
        'juan.manuel.gomez@huawei.com',
        'daniel.humberto.nunez@huawei.com',
        'alberto.alarcon@huawei.com',
        'fgranados@gtac.com.mx',
        'dbrionesi@gtac.com.mx',
        'becario_ti2@gtac.com.mx'
    ]

    threads = []
    
    for email in email_list:
        t = threading.Thread(target=thread_reporte_global, args=[array_PES, email], daemon=True)
        t.start()
        threads.append(t)

        print(f'ENDED: {email}')

    for thread in threads:
        thread.join()
    
    print("Running my periodic task...")


class Command(BaseCommand):
    help = 'Runs a periodic task every 5 minutes'

    def handle(self, *args, **options):
        schedule.every().friday.at("14:45").do(my_periodic_task)

        # Infinite loop to run the scheduler
        while True:
            schedule.run_pending()
            time.sleep(1)  # Optional: sleep time can be adjusted
