from django.db import models

from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

from django.db.models import Q, Count, Sum

from itertools import chain


class Sitios(models.Model):
    IdSitio = models.AutoField(db_column='IdSitio', primary_key=True)  # Field name made lowercase.
    Nombre = models.CharField(max_length=100,db_column='Nombre', blank=True, null=True)
    EsAlmacen = models.BooleanField(default=False)
    Imputacion =models.CharField(max_length=5,db_column='Imputacion',blank=True,null=True)
    IpImpresora=models.CharField(max_length=50,db_column='IpImpresora',blank=True,null=True)
    Zona=models.CharField(max_length=50,db_column='Zona',blank=True,null=True)
    Tipo=models.CharField(max_length=50,db_column='Tipo',blank=True,null=True)
    
    

class Estatus(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    Nombre = models.CharField(max_length=100,db_column='Nombre', blank=True, null=True)


class CatTipoMat(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    Nombre = models.CharField(max_length=100,db_column='Nombre', blank=True, null=True)

class Categorias(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    Nombre = models.CharField(max_length=100,db_column='Nombre', blank=True, null=True)
    

class UbicacionesTecnicas(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase
    IdAlmacen = models.ForeignKey(Sitios,null=True,db_column='IdAlmacen',blank=True,on_delete=models.CASCADE) 
    Descripcion = models.CharField(max_length=150,db_column='Descripcion', blank=True, null=True)

class OrdenSalida(models.Model):

    IdOs = models.AutoField(db_column='IdOs', primary_key=True)  # Field name made lowercase.
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Folio= models.CharField(max_length=150,db_column='Folio', blank=True, null=True)
    
    IdServiceDesk= models.CharField(max_length=150,db_column='IdServiceDesk', blank=True, null=True)
    FechaTicketEntradaSD = models.DateTimeField(db_column='FechaTicketEntradaSD', blank=True, null=True)
    FechaTicketSalidaSD = models.DateTimeField(db_column='FechaTicketSalidaSD', blank=True, null=True)
    DateLimiteSD = models.DateTimeField(db_column='DateLimiteSD', blank=True, null=True)


    TipoRecoleccion = models.CharField(max_length=150,db_column='TipoRecoleccion', blank=True, null=True)
    esPaqueteria = models.CharField(max_length=150,db_column='EsPaqueteria', blank=True, null=True)
    comentarios = models.CharField(max_length=300,db_column='comentarios', blank=True, null=True)

    recolectorAlmacen = models.ForeignKey(User,null=True,db_column='RecolectorAlmacen',related_name='RecolectorAlmacen',on_delete=models.CASCADE)
    recolectorPaqueteria = models.ForeignKey(User,null=True,db_column='RecolectoPaqueteria',related_name='RecolectorPaqueteria',on_delete=models.CASCADE)

    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',related_name='CreadoPor',on_delete=models.CASCADE)
    Aprovador = models.ForeignKey(User,null=True,db_column='Aprovador',related_name='Aprovador',on_delete=models.CASCADE)
    IdDestino = models.ForeignKey(Sitios,null=True,db_column='IdDestino',related_name='IdDestino',on_delete=models.CASCADE)
    IdOrigen = models.ForeignKey(Sitios,null=True,db_column='IdOrigen',related_name='IdOrigen',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',blank=True,on_delete=models.CASCADE)

class OrdenEntrada(models.Model):

    IdOsI = models.AutoField(db_column='IdOsI', primary_key=True)  # Field name made lowercase.
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    FechaLimiteSD = models.DateTimeField(db_column='FechaLimiteSD', blank=True, null=True)
    FechaTicketEntradaSD = models.DateTimeField(db_column='FechaTicketEntradaSD', blank=True, null=True)
    FechaTicketSalidaSD = models.DateTimeField(db_column='FechaTicketSalidaSD', blank=True, null=True)

    Folio= models.CharField(max_length=150,db_column='Folio', blank=True, null=True)
    IdServiceDesk= models.CharField(max_length=150,db_column='IdServiceDesk', blank=True, null=True)

    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',related_name='CreadoPorI',on_delete=models.CASCADE)
    Aprovador = models.ForeignKey(User,null=True,db_column='Aprovador',related_name='AprovadorI',on_delete=models.CASCADE)
    IdDestino = models.ForeignKey(Sitios,null=True,db_column='IdDestino',related_name='IdDestinoI',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',blank=True,on_delete=models.CASCADE)
    asignadoA = models.ForeignKey(User,null=True,db_column='asignadoA',on_delete=models.CASCADE)
    


class CatalogoAPR(models.Model):
    Id = models.IntegerField(db_column='Id', primary_key=True)
    Etiqueta= models.CharField(max_length=150,db_column='Etiqueta', blank=True, null=True)
    Texto= models.CharField(max_length=150,db_column='Texto', blank=True, null=True)
    TipoAgrupacion= models.CharField(max_length=150,db_column='TipoAgrupacion', blank=True, null=True)
    SKUPadre = models.ForeignKey("Materiales",db_column='SKUPadre',on_delete=models.CASCADE,null=True)

    def __self__(self):
        return self.Etiqueta

    def get_texto_breve(self):
        if self.TipoAgrupacion == "SKU":
            return self.Texto
        else:
            return self.SKUPadre.TextoBreve

    def get_categoria(self):
        if self.TipoAgrupacion == "SKU":
            return Materiales.objects.filter(GrupoAPR__Etiqueta=self.Etiqueta)[0].IdCategoria.Nombre
        else:
            return self.SKUPadre.IdCategoria.Nombre

class CatalogoPES(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    PES= models.CharField(max_length=150,db_column='PES', blank=True, null=True)
    
    
    @property 
    def ultima_entrada(self):
        if len(self.entradas)>0:
            return str(OrdenesEntradaApr.objects.filter(FolioOC=self.PES).latest('Id').FechaEntrada.strftime("%d-%m-%Y"))
        else:
            return "No hay entradas" 
    @property 
    def primera_salida(self):
        if len(self.salidas)>0:
            return str(MatOrdenSalidaApr.objects.filter(IDPMO__in=self.os_in_pes)[0].IdOrdenSalidaApr.FechaSalida.strftime("%d-%m-%Y")) 
        else:
            return "No hay salidas"

    @property 
    def salidas(self):
        return MatOrdenSalidaApr.objects.filter(IDPMO__in=self.os_in_pes)


    @property
    def os_in_pes(self):
        return [x.OS for x in CatalogoOS.objects.filter(IdPES__PES=self.PES)]

    @property
    def os_in_pes_dict(self):
        return [x for x in CatalogoOS.objects.filter(IdPES__PES=self.PES).values('OS')]


    @property 
    def entradas(self):
        return OrdenesEntradaApr.objects.filter(FolioOC=self.PES)



class CatalogoOS(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    OS= models.CharField(max_length=150,db_column='OS', blank=True, null=True)
    IdPES = models.ForeignKey(CatalogoPES,db_column='IdPES',on_delete=models.CASCADE,null=True)
    EsInterna = models.BooleanField(db_column='EsInterna', default=False)

    @property 
    def elementos_Salida(self):
        return sum([x.CtdSalida for x in MatOrdenSalidaApr.objects.filter(Q(IDPMO=self.OS) &Q(IdStatus__Id=5))])




class Materiales(models.Model):
    IdMat = models.IntegerField(db_column='IdMat', primary_key=True)
    TextoBreve = models.CharField(max_length=550,db_column='TextoBreve', blank=True, null=True)
    IdCategoria = models.ForeignKey(Categorias,db_column='IdCategoria',on_delete=models.CASCADE,null=True)
    Tipo = models.ForeignKey(CatTipoMat,db_column='Tipo',on_delete=models.CASCADE,null=True)
    GrupoAPR = models.ForeignKey(CatalogoAPR,db_column='GrupoAPR',on_delete=models.CASCADE,null=True,blank=True)
    Activo = models.BooleanField(db_column='Activo', default=True)
    SKU = models.CharField(max_length=30,db_column='SKU', blank=True, null=True)
    
class CantidadesDisponibles(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdAlmacen = models.ForeignKey(Sitios,db_column='IdAlmacen',on_delete=models.CASCADE,null=True)
    IdMat = models.ForeignKey(Materiales,db_column='IdMat',on_delete=models.CASCADE,null=True)
    TotalIngresado = models.IntegerField(db_column='TotalIngresado', blank=True, null=True)
    TotalReservado = models.IntegerField(db_column='TotalReservado', blank=True, null=True)
    TotalDisponible = models.IntegerField(db_column='TotalDisponible', blank=True, null=True)


class Inventario(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdMat = models.ForeignKey(Materiales,db_column='IdMat',on_delete=models.CASCADE,null=True)
    IdAlmacen = models.ForeignKey(Sitios,db_column='IdAlmacen',on_delete=models.CASCADE,null=True)
    NumEtiqueta = models.CharField(max_length=100,db_column='NumEtiqueta', blank=True, null=True)
    NumeroSerie = models.CharField(max_length=100,db_column='NumeroSerie', blank=True, null=True)
    DescripcionEntrada = models.CharField(max_length=250,db_column='DescripcionEntrada', blank=True, null=True)
    NumActivoFijo = models.CharField(max_length=250,db_column='NumActivoFijo', blank=True, null=True)
    Ctd = models.IntegerField(db_column='Ctd', blank=True, null=True)
    CtdRes = models.IntegerField(db_column='CtdRes', blank=True, null=True)
    CtdDis = models.IntegerField(db_column='CtdDis', blank=True, null=True)
    IdUbicacionTec = models.ForeignKey(UbicacionesTecnicas,null=True,db_column='IdUbicacionTec',blank=True,on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)



class EstatusMateriales(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True) 
    Descripcion= models.CharField(max_length=150,db_column='Descripcion', blank=True, null=True)
   

class OrdenesEntradaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    Folio= models.CharField(max_length=150,db_column='Folio', blank=True, null=True) 
    FolioOC= models.CharField(max_length=150,db_column='FolioOC', blank=True, null=True) 
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',related_name='CreadoPorEntradaApr',on_delete=models.CASCADE)
    Aprobador = models.ForeignKey(User,null=True,db_column='Aprobador',related_name='AprobadorPorEntradaApr',on_delete=models.CASCADE)
    Almacen = models.ForeignKey(Sitios,null=True,db_column='Almacen',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    FechaEntrada = models.DateTimeField(db_column='FechaEntrada', blank=True, null=True)

    def save(self,*args,**kwargs):
        super(OrdenesEntradaApr, self).save(*args, **kwargs)
        self.saveFolio()

    def saveFolio(self,*args,**kwargs):
        folio="ENAPR-"+str(self.Id).zfill(5)
        self.Folio = folio
        super().save(*args,**kwargs)

    @property 
    def elementos_POD(self):
        return sum([x.CantidadEntrada for x in MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr=self)])


    @property 
    def elementos_Inventariados(self):
        return sum([x.CantidadRecepcionada for x in MatOrdenEntradaApr.objects.filter(Q(IdOrdenEntradaApr=self) & Q(IdStatus__Id=10))])


    @property 
    def elementos_Pendientes(self):
        return sum([x.CantidadEntrada for x in MatOrdenEntradaApr.objects.filter(IdOrdenEntradaApr=self).exclude(IdStatus__Id=10)])


        

class ComentariosEntradasApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdOrdenEntradaApr = models.ForeignKey(OrdenesEntradaApr,null=True,db_column='IdOrdenEntradaApr',on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Comentario = models.TextField(db_column='Comentario', blank=True, null=True)
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',on_delete=models.CASCADE)


class CajasEntradaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdOrdenEntradaApr = models.ForeignKey(OrdenesEntradaApr,null=True,db_column='IdOrdenEntradaApr',on_delete=models.CASCADE)
    CodigoCaja = models.TextField(db_column='CodigoCaja', blank=True, null=True)
    Estatus = models.TextField(db_column='Estatus', blank=True, null=True)
    FechaValidacion = models.DateTimeField(db_column='FechaValidacion', blank=True, null=True)

class UntrackedItemsApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdMat = models.ForeignKey(Materiales,db_column='IdMat',on_delete=models.CASCADE,null=True)
    NumeroSerie = models.CharField(max_length=100,db_column='NumeroSerie', blank=True, null=True)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Cantidad = models.IntegerField(db_column='Cantidad', blank=True, null=True)
    IdStatus = models.ForeignKey(EstatusMateriales,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    Caja = models.ForeignKey(CajasEntradaApr,null=True,db_column='Caja',on_delete=models.CASCADE)



class MatOrdenEntradaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',on_delete=models.CASCADE)
    IdAPR = models.ForeignKey(CatalogoAPR,null=True,db_column='IdAPR',on_delete=models.CASCADE)    
    IdInventario = models.ForeignKey('InventarioAprovicionamiento',null=True,db_column='IdInventario',on_delete=models.CASCADE)
    IdOrdenEntradaApr = models.ForeignKey(OrdenesEntradaApr,null=True,db_column='IdOrdenEntradaApr',on_delete=models.CASCADE)
    NoSerie = models.TextField(db_column='NoSerie', blank=True, null=True)
    NoActivo = models.TextField(db_column='NoActivo', blank=True, null=True)
    etiquetaLogix = models.TextField(db_column='etiquetaLogix', blank=True, null=True)
    CantidadEntrada = models.IntegerField(db_column='CantidadEntrada', blank=True, null=True)
    CantidadRecepcionada = models.IntegerField(db_column='CantidadRecepcionada', blank=True, null=True,default=0)
    Caja = models.ForeignKey(CajasEntradaApr,null=True,db_column='Caja',on_delete=models.CASCADE)
    Guia = models.TextField(db_column='Guia', blank=True, null=True)
    IdStatus = models.ForeignKey(EstatusMateriales,null=True,db_column='IdStatus',on_delete=models.CASCADE)

class BolsaMaterialesByOs(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',on_delete=models.CASCADE)
    QtySolicitada = models.IntegerField(db_column='QtySolicitada', blank=True, null=True,default=0)
    QtyAbastecida = models.IntegerField(db_column='QtyAbastecida', blank=True, null=True,default=0)
    IdOS = models.ForeignKey(CatalogoOS,null=True,db_column='IdOS',on_delete=models.CASCADE)
    IdSalida = models.ForeignKey('OrdenesSalidaApr',null=True,db_column='IdSalida',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(EstatusMateriales,null=True,db_column='IdStatus',on_delete=models.CASCADE)



class InventarioAprovicionamiento(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    Almacen = models.ForeignKey(Sitios,null=True,db_column='Almacen',on_delete=models.CASCADE)
    IdUbTec = models.ForeignKey(UbicacionesTecnicas,null=True,db_column='IdUbTec',on_delete=models.CASCADE)
    CtdTotal = models.IntegerField(db_column='CtdTotal', blank=True, null=True)
    CtdReservada = models.IntegerField(db_column='CtdReservada', blank=True, null=True)
    CtdDisponible = models.IntegerField(db_column='CtdDisponible', blank=True, null=True)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Etiqueta = models.TextField(db_column='Etiqueta', blank=True, null=True)
    NoActivo = models.TextField(db_column='NoActivo', blank=True, null=True)
    NoSerie = models.TextField(db_column='NoSerie', blank=True, null=True)

    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',blank=True,on_delete=models.CASCADE)
    IdApr = models.ForeignKey(CatalogoAPR,db_column='IdApr',on_delete=models.CASCADE,null=True)


class OrdenesSalidaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    Folio= models.CharField(max_length=150,db_column='Folio', blank=True, null=True) 
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',related_name='CreadoPorApr',on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    FechaSalida = models.DateTimeField(db_column='FechaSalida', blank=True, null=True)
    Almacen = models.ForeignKey(Sitios,null=True,db_column='Almacen',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    Aprobador = models.ForeignKey(User,null=True,db_column='Aprobador',related_name='AprobadorPorApr',on_delete=models.CASCADE)

    @property 
    def elementos_Salida(self):
        return sum([x.CtdSalida for x in MatOrdenSalidaApr.objects.filter(Q(IdOrdenSalidaApr=self) & Q(IdStatus__Id=5))])

    @property 
    def elementos_Cancelados(self):
        return sum([x.CtdSalida for x in MatOrdenSalidaApr.objects.filter(Q(IdOrdenSalidaApr=self) & Q(IdStatus__Id=15))])


    @property 
    def elementos_Pendientes(self):
        return sum([x.CtdSalida for x in MatOrdenSalidaApr.objects.filter(IdOrdenSalidaApr=self).exclude(IdStatus__Id__in=[5,15])])



class ReservasApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    Folio= models.CharField(max_length=150,db_column='Folio', blank=True, null=True) 
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',related_name='CreadorReserva',on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Almacen = models.ForeignKey(Sitios,null=True,db_column='Almacen',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    Aprobador = models.ForeignKey(User,null=True,db_column='Aprobador',related_name='AprobadorReserva',on_delete=models.CASCADE)

class SalidasAprPES(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    IdSalidaApr= models.ForeignKey(OrdenesSalidaApr,null=True,db_column='IdSalidaApr',on_delete=models.CASCADE)
    IdPES= models.ForeignKey(CatalogoPES,null=True,db_column='IdPEs',on_delete=models.CASCADE)


class SitiosOcurre(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    CodigoPostal= models.CharField(max_length=150,db_column='CodigoPostal', blank=True, null=True) 
    Oficina= models.CharField(max_length=150,db_column='Oficina', blank=True, null=True) 
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    
class MatOrdenReservaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',blank=True,on_delete=models.CASCADE)
    IdReservaApr = models.ForeignKey(ReservasApr,null=True,db_column='IdReservaApr',blank=True,on_delete=models.CASCADE)
    IdInventario = models.ForeignKey(InventarioAprovicionamiento,null=True,db_column='IdInventario',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(EstatusMateriales,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    CtdReservada = models.IntegerField(db_column='CtdReservada', blank=True, null=True)
    CtdDisponible = models.IntegerField(db_column='CtdDisponible', blank=True, null=True)
    CtdUtilizada = models.IntegerField(db_column='CtdUtilizada', blank=True, null=True,default=0)
    SitioDestino = models.ForeignKey(Sitios,null=True,db_column='SitioDestino',on_delete=models.CASCADE)
    IDPMO = models.ForeignKey(CatalogoOS,null=True,db_column='IDPMO',on_delete=models.CASCADE)
    IdSalidaApr = models.ForeignKey(OrdenesSalidaApr,null=True,db_column='IdSalidaApr',on_delete=models.CASCADE)


   

class MatOrdenSalidaApr(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)
    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',blank=True,on_delete=models.CASCADE)
    IdOrdenSalidaApr = models.ForeignKey(OrdenesSalidaApr,null=True,db_column='IdOrdenSalidaApr',blank=True,on_delete=models.CASCADE)
    IdInventario = models.ForeignKey(InventarioAprovicionamiento,null=True,db_column='IdInventario',on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(EstatusMateriales,null=True,db_column='IdStatus',on_delete=models.CASCADE)
    CtdSalida = models.IntegerField(db_column='CtdSalida', blank=True, null=True)
    IDPMO= models.TextField(max_length=100,db_column='IDPMO', blank=True, null=True) 
    Caja= models.TextField(max_length=100,db_column='Caja', blank=True, null=True) 
    RecolectaEnAlmacén= models.TextField(max_length=100,db_column='RecolectaEnAlmacén', blank=True, null=True) 
    Destinatario= models.TextField(max_length=100,db_column='Destinatario', blank=True, null=True) 
    GuiaEnvio= models.TextField(max_length=200,db_column='GuiaEnvio', blank=True, null=True) 
    SitioOcurre =models.ForeignKey(SitiosOcurre,null=True,db_column='SitioOcurre',on_delete=models.CASCADE)
    SitioDestino = models.ForeignKey(Sitios,null=True,db_column='SitioDestino',on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.IdMat.SKU}-{self.IdMat.Tipo.Nombre}"


class MatOrden(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOs = models.ForeignKey(OrdenSalida,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    IdMaterialInventario = models.ForeignKey(Inventario,null=True,db_column='IdMaterialInventario',blank=True,on_delete=models.CASCADE)
    IdAlmacen = models.ForeignKey(Sitios,null=True,db_column='IdAlmacen',blank=True,on_delete=models.CASCADE)
    StatusMaterial = models.CharField(max_length=100,db_column='StatusMaterial', blank=True, null=True)    
    CtdSolicitada = models.IntegerField(db_column='CtdSolicitada', blank=True, null=True)
    CtdSalida = models.IntegerField(db_column='CtdSalida', blank=True, null=True)
    CtdEntrega = models.IntegerField(db_column='CtdEntrega', blank=True, null=True)
    UbicacionTecnicaDestino = models.CharField(max_length=100,db_column='UbicacionTecnicaDestino', blank=True, null=True)

    

class MatOrdenEntrada(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOsI = models.ForeignKey(OrdenEntrada,null=True,db_column='IdOsI',blank=True,on_delete=models.CASCADE)
    IdMat = models.ForeignKey(Materiales,null=True,db_column='IdMat',blank=True,on_delete=models.CASCADE)
    StatusMaterial = models.CharField(max_length=100,db_column='StatusMaterial', blank=True, null=True)    
    NumeroSerie = models.CharField(max_length=100,db_column='NumeroSerie', blank=True, null=True)    
    NumActivo = models.CharField(max_length=100,db_column='NumActivo', blank=True, null=True)    
    DescripcionEntrada = models.CharField(max_length=100,db_column='DescripcionEntrada', blank=True, null=True)    
    NumEtiqueta = models.CharField(max_length=100,db_column='NumEtiqueta', blank=True, null=True)    
    CtdEntrada = models.IntegerField(db_column='CtdEntrada', blank=True, null=True)
    UbicacionTecnicaDestino = models.ForeignKey(UbicacionesTecnicas,null=True,db_column='IdUbicacionTec',blank=True,on_delete=models.CASCADE)
    IdEnInventario =models.ForeignKey(Inventario,null=True,db_column='IdEnInventario',blank=True,on_delete=models.CASCADE)

    
class OrdenesCanceladas(models.Model):
    IdOs = models.ForeignKey(OrdenSalida,db_column='IdOs',on_delete=models.CASCADE,primary_key=True)
    Descripcion = models.CharField(max_length=300,db_column='Descripcion', blank=True, null=True)


class LogsMovimientos(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOs = models.ForeignKey(OrdenSalida,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',blank=True,on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Autor = models.ForeignKey(User,null=True,db_column='Autor',on_delete=models.CASCADE)


class LogsEntradas(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOsI = models.ForeignKey(OrdenEntrada,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',blank=True,on_delete=models.CASCADE)
    FechaCreacion = models.DateTimeField(auto_now_add=True,db_column='FechaCreacion', blank=True, null=True)
    Autor = models.ForeignKey(User,null=True,db_column='Autor',on_delete=models.CASCADE)





class OrdenesActivoFijo(models.Model):
     IdOs = models.ForeignKey(OrdenSalida,db_column='IdOs',on_delete=models.CASCADE,primary_key=True)
    
   


class RegistroSalida(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOs = models.ForeignKey(OrdenSalida,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    InputScan = models.CharField(max_length=100,db_column='InputScan', blank=True, null=True)

class PaqueteriaProv(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    ProvPaq = models.CharField(max_length=100,db_column='ProvPaq', blank=True, null=True)

class PaqueteriaOs(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOs = models.ForeignKey(OrdenSalida,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    IdPaqueteria = models.ForeignKey(PaqueteriaProv,null=True,db_column='IdPaqueteria',blank=True,on_delete=models.CASCADE)

    DescripcionDelEnvio = models.CharField(max_length=500,db_column='DescripcionDelEnvio', blank=True, null=True)
    DescripcionDeLasCajas = models.CharField(max_length=500,db_column='DescripcionDeLasCajas', blank=True, null=True)
    EstadoRecepcionPaquete = models.CharField(max_length=500,db_column='EstadoRecepcionPaquete', blank=True, null=True)

 
class EstatusOs(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    IdOs = models.ForeignKey(OrdenSalida,null=True,db_column='IdOs',blank=True,on_delete=models.CASCADE)
    NumEtiqueta = models.BooleanField(db_column='NumEtiqueta', default=True)
    IdStatus = models.ForeignKey(Estatus,null=True,db_column='IdStatus',blank=True,on_delete=models.CASCADE)

class Roles(models.Model):
    IdRol = models.AutoField(db_column='IdRol', primary_key=True)  # Field name made lowercase.
    NombreRol = models.CharField(max_length=100,db_column='NombreRol', blank=True, null=True)


    #Flujo APR
    CrearOrdenApr = models.BooleanField(db_column='CrearOrdenApr', blank=True, null=True ,default=False)
    CrearEntradaApr = models.BooleanField(db_column='CrearEntradaApr', blank=True, null=True ,default=False)    
    VerOrdenesApr = models.BooleanField(db_column='VerOrdenesApr', blank=True, null=True ,default=False)

    VerEntradasApr = models.BooleanField(db_column='VerEntradasApr', blank=True, null=True ,default=False)
    RecolectarOrdenApr = models.BooleanField(db_column='RecolectarOrdenApr',  blank=True, null=True,default=False)
    VerInventarioAPR = models.BooleanField(db_column='VerInventarioAPR',  blank=True, null=True,default=False)
    ValidarCajasEntradaApr = models.BooleanField(db_column='ValidarCajasEntradaApr',  blank=True, null=True,default=False)
    EditarCajaEntradaApr = models.BooleanField(db_column='EditarCajaEntradaApr',  blank=True, null=True,default=False)
    ValidarMaterialesEntrada = models.BooleanField(db_column='ValidarMaterialesEntrada',  blank=True, null=True,default=False)
    InventariarMaterialesApr = models.BooleanField(db_column='InventariarMaterialesApr',  blank=True, null=True,default=False)
    LiberarReservaApr= models.BooleanField(db_column='LiberarReservaApr',  blank=True, null=True,default=False)
    CancelarSalidaAPR= models.BooleanField(db_column='CancelarSalidaAPR',  blank=True, null=True,default=False)

    
    
    #Catalogos
    CrearSKU = models.BooleanField(db_column='CrearSKU',  blank=True, null=True,default=False)
    CrearCategoria = models.BooleanField(db_column='CrearCategoria',  blank=True, null=True,default=False)
    VerSKU = models.BooleanField(db_column='VerSKU',  blank=True, null=True,default=False)
    VerCategoria = models.BooleanField(db_column='VerCategoria',  blank=True, null=True,default=False)


    
    # Flujo refacciones
    VerInventarioRefacciones = models.BooleanField(db_column='VerInventarioRefacciones',  blank=True, null=True ,default=False)
    CrearOrdenSalidaRefacciones = models.BooleanField(db_column='CrearOrdenSalidaRefacciones', blank=True, null=True ,default=False)
    CrearOrdenEntradaRefacciones = models.BooleanField(db_column='CrearOrdenEntradaRefacciones', blank=True, null=True ,default=False)
    VerSalidasRefacciones = models.BooleanField(db_column='VerSalidasRefacciones', blank=True, null=True ,default=False)
    generarGuiasRefacciones = models.BooleanField(db_column='generarGuiasRefacciones', blank=True, null=True ,default=False)
    ingresarMaterialesAlmacen = models.BooleanField(db_column='ingresarMaterialesAlmacen', blank=True, null=True ,default=False)
    recolectarEnPaqueteria = models.BooleanField(db_column='recolectarEnPaqueteria', blank=True, null=True ,default=False)
    recoleccionMaterialAlmacén = models.BooleanField(db_column='recoleccionMaterialAlmacén', blank=True, null=True ,default=False)
    generarTicketSD = models.BooleanField(db_column='generarTicketSD', blank=True, null=True ,default=False)
    verEntradasRefacciones = models.BooleanField(db_column='verEntradasRefacciones', blank=True, null=True,default=False)










class Areas(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    NombreArea = models.CharField(max_length=100,db_column='NombreArea', blank=True, null=True)
    Aprovador = models.ForeignKey(User,null=True,db_column='Aprovador',blank=True,on_delete=models.CASCADE)


class TicketSD(models.Model):
    Id = models.AutoField(db_column='Id', primary_key=True)  # Field name made lowercase.
    CreadoPor = models.ForeignKey(User,null=True,db_column='CreadoPor',blank=True,on_delete=models.CASCADE)
    Motivo = models.CharField(max_length=200,db_column='Motivo', blank=True, null=True)
    FechaEntrada = models.DateTimeField(db_column='FechaEntrada', blank=True, null=True)
    FechaSalida = models.DateTimeField(db_column='FechaSalida', blank=True, null=True)
    Almacen = models.ForeignKey(Sitios,null=True,db_column='Almacen',blank=True,on_delete=models.CASCADE)
    IdTicket = models.CharField(max_length=150,db_column='IdTicket', blank=True, null=True)



class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    IdRol = models.ForeignKey(Roles,null=True,db_column='IdRol',blank=True,on_delete=models.CASCADE)
    Area = models.ForeignKey(Areas,null=True,db_column='Area',blank=True,on_delete=models.CASCADE)
    Zona=models.CharField(max_length=50,db_column='Zona',default="z1",editable=True)
    Telefono=models.CharField(max_length=50,db_column='Telefono',default="123",editable=True)

    

    
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()



