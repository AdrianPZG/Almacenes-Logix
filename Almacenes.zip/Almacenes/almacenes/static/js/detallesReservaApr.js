const openNuevaSalida=()=>{
    $('#modalNuevaSalida').modal('show')
}

var arrayProductos = []
var arrayGrupos=[]
var arrayMaterialesPorAñadir=[]


const openEliminarReservas = ()=>{
  $('#modalEliminarReserva').modal('show')
}

const eliminarReserva=(Sitio,IDPMO)=>{

  Swal.fire({
      title: `¿Estas seguro de borrar la reserva ${Sitio}-${IDPMO}`,
      showCancelButton: true,
      confirmButtonText: 'Continuar',
      cancelButtonText: 'Cancelar',
      showLoaderOnConfirm: true,
      preConfirm: async () => {

          const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
          const respuesta = await fetch('/eliminarReservaApr',{
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRFToken': csrftoken,  
              },
              body:JSON.stringify({
                  'Sitio':Sitio,
                  'IDPMO':IDPMO
              })
          })
          if (respuesta.ok){
              return jsRes = await respuesta.json() 
          }
      },
      allowOutsideClick: () => !Swal.isLoading()
  }).then((result) => {
      if (result.isConfirmed) {
          if(result.value.result == "Error"){
              Swal.fire({
                  title:'Error!',
                  text:result.value.message,
                  icon:'error',
              })
          }
          if(result.value.result == "Ok"){
              Swal.fire({
                  title:'Exito!',
                  text:result.value.message,
                  icon:'success',
              }).then((result)=>{
              location.reload()
            })
              
          }


      }
  })
 
}

const finalizarSalida = (PES)=>{
  
  const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
  if(arrayGrupos.length != 0 ){

    arrayGrupos.map((x)=>{
      if(x.materiales.length != 0){
        
        Swal.fire({
            title: `Finalizar salida`,
            html:
            '<hr>'+
            '<label>Ingresa la fecha de salida</label>'+
            '<input type="date" class="form-control" id="fechaSa"/>'
            ,

            showCancelButton: true,
            confirmButtonText: 'Continuar',
            cancelButtonText: 'Cancelar',
            showLoaderOnConfirm: true,
            preConfirm: async () => {
              const fechaSalida = document.getElementById("fechaSa").value
              if(fechaSalida){

                const respuesta = await fetch('/liberarReservaApr',{
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': csrftoken,  
                    },
                    body:JSON.stringify({
                        'gruposMateriales':arrayGrupos,
                        'fechaSalida':fechaSalida,
                        'PES':PES
                    })
                })
                if (respuesta.ok){
                    return jsRes = await respuesta.json() 
                }
              }
              else{
                Swal.showValidationMessage(`La fecha de salida es obligatoria`)   
              }

            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                if(result.value.result == "Error"){
                    Swal.fire({
                        title:'Error!',
                        text:result.value.message,
                        icon:'error',
                    })
                }
                if(result.value.result == "Ok"){
                    Swal.fire({
                        title:'Exito!',
                        text:result.value.message,
                        icon:'success',
                    }).then((result)=>{
                    location.reload()
                  })


                }


            }
        })
     
    }else{
      Swal.fire(
        'Ups!',
        'No puede haber grupos vacios',
        'error'
      )

    }
  })


  }else{
    Swal.fire(
      'Ups!',
      'No hay ningun grupo de envio',
      'error'
    )
 
  }

}


const crearGrupoEnvio = ()=>{
   Swal.fire({
    title: `Nuevo grupo de envío`,
    html:
    '<hr>'+
    '<label>Selecciona el tipo de envio</label>'+
    `<select id="opcionOcurre" class="form-control" onchange="changeTipoEnvioContent(this)"><option value="recoleccion">Recolección en almacen</option><option value="envio">Envio a ocurre</option></select><hr>`+
    '<div id="tipoEnvioBox"><label>Nombre de quien recolecta en almacén</label><input class="form-control" id="recolectorAlmacen" type="text"/></div>'
    ,

    showCancelButton: true,
    confirmButtonText: 'Continuar',
    cancelButtonText: 'Cancelar',
    showLoaderOnConfirm: true,
    preConfirm: () => {
      const opcionSeleccionada = document.getElementById("opcionOcurre").value
      if(opcionSeleccionada=="recoleccion"){
        const recolectorAlmacen = document.getElementById("recolectorAlmacen").value
        if(recolectorAlmacen==null || recolectorAlmacen==""){
            
          Swal.showValidationMessage(`El nombre del recolector es obligatorio`)   
        }else{
          const newGrupo = new Object
          
          newGrupo.id = Math.random().toString(16).slice(2)
          newGrupo.tipo="Recoleccion en almacen"
          newGrupo.titulo = `Grupo: ${recolectorAlmacen}`
          newGrupo.nombreRecolector = recolectorAlmacen
          newGrupo.idTabla = Math.random().toString(16).slice(2)
          newGrupo.idBoby =  Math.random().toString(16).slice(2)
          newGrupo.idDiv = Math.random().toString(16).slice(2)
          newGrupo.materiales = []

          arrayGrupos.push(newGrupo)
          addGrupo(newGrupo)
        }
          
      }else{
        const destinatario = document.getElementById("Destinatario").value
        const ocurre = document.getElementById("ocurre").value
        
        if(destinatario === null || destinatario === ""){

          Swal.showValidationMessage(`El nombre del destinatario es obligatorio`)   
        }else{

          if(ocurre === ""){
            Swal.showValidationMessage(`Selecciona un ocurre`)   
          }else{

            const newGrupo = new Object

            const posicionComa = ocurre.indexOf(",");
            const idOcurreLimpio = ocurre.substring(0, posicionComa);
            const ocurreLimpio = ocurre.substring(posicionComa + 1);

            newGrupo.id = Math.random().toString(16).slice(2)
            newGrupo.tipo="Envio Ocurre"
            newGrupo.titulo = `Grupo: ${ocurreLimpio}, ${destinatario}`
            newGrupo.OcurreId = idOcurreLimpio

            newGrupo.nombreDestinatario = destinatario
            newGrupo.idTabla = Math.random().toString(16).slice(2)
            newGrupo.idBoby =  Math.random().toString(16).slice(2)
            newGrupo.idDiv = Math.random().toString(16).slice(2)
            newGrupo.materiales = []

            arrayGrupos.push(newGrupo)
            addGrupo(newGrupo)
          }

        }

      }
    },
  }) 
}

const getMaterials =async(sitio,pmo)=>{
  const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

  const url = `/getMaterialsBySitioPMO`
  const response = await fetch(url,{
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrftoken,  
    },
    body:JSON.stringify({
      'sitio':sitio,
      'PMO':pmo
    })

  })

  var  tableMateriales= ""
  if(response.ok){
    const jsonResponse = await response.json()
    const materiales = JSON.parse(jsonResponse)

    materiales.map((x)=>{
      if(x.IdStatus__Id ==13){
        tableMateriales = tableMateriales + `<tr><td title="${x.IdMat__TextoBreve}">${x.sku_apr}</td> <td>${x.CtdDisponible}</td></tr>`
      }
    })
  }

  Swal.fire({
    title: `Materiales: ${sitio}-${pmo}`,
    html:
    '<hr>'+
      `<table class="table"><thead><th>SKU</th><th>Cantidad</th></thead><tbody>${tableMateriales}</tbody></table>`
    ,
    showLoaderOnConfirm: true,
  })


}

const deleteGroup = (concatenado)=>{
  const splited = concatenado.split(",");

  arrayGrupos = arrayGrupos.filter(x=>x.id != splited[0])

  const selectedDiv = document.getElementById(splited[1])

  selectedDiv.remove()


}

const addGrupo= (grupo)=>{
  const grupos = document.getElementById("grupos")

  var borderClass = "border-primary"

  if(grupo.tipo=="Envio Ocurre"){
    borderClass = "border-success"
  }

  const nuevaTablaGrupo = `
<div id="${grupo.idDiv}" class="border rounded border-4 ${borderClass} p-2 mb-3">
<div class="d-flex justify-content-between"><h5 class="card-title">${grupo.titulo}</h5> <button class="btn btn-danger btn-sm" id="boton-${grupo.id}" onclick="deleteGroup('${grupo.id},${grupo.idDiv}')"><i class="bi bi-trash"></i> Eliminar grupo</button></div>
<table id="${grupo.idTabla}" class="table">
<thead>
<th>ID PMO</th>
<th>Sitio</th>
<th>Elementos</th>
<th>Acciones</th>
</thead>
<tbody id="${grupo.idBoby}">

</tbody>
</table>
</div>`

  grupos.innerHTML = grupos.innerHTML + nuevaTablaGrupo
}

const changeTipoEnvioContent = async(selectObject)=>{
  var value = selectObject.value;
  const tipoEnvioBox = document.getElementById("tipoEnvioBox")

  if(value == "recoleccion"){
    tipoEnvioBox.innerHTML= `<label>Nombre de quien recolecta en almacén</label><input class="form-control" id="recolectorAlmacen" type="text">`
  }else{

    const url = `/getOcurres`
    const response = await fetch(url)

    var opcionesOcurre = ""
    if(response.ok){
      const jsonResponse = await response.json()
      const ocurres = JSON.parse(jsonResponse)
      ocurres.map((x)=>{
        const texto = `<option value='${x.Id},${x.CodigoPostal}'  label='${x.CodigoPostal}'>`
        opcionesOcurre = opcionesOcurre+texto 

      })


    }

    tipoEnvioBox.innerHTML= `
<label>Selecciona el sitio ocurre</label>
<input id="ocurre" list="ocurreList" class="form-control" required>
<datalist id="ocurreList">
  ${opcionesOcurre}
</datalist>  



<label>Ingresa el nombre del destinarario</label><input class="form-control" id="Destinatario" type="text">`
  }
}






const añadirAgrupo=()=>{
  var opcionesGrupos = ""

  arrayGrupos.map((x)=>{
    const texto = `<option value="${x.id}">${x.titulo}</option>`
    opcionesGrupos = opcionesGrupos + texto

  })
  if(arrayGrupos.length!=0){
    Swal.fire({
      title: `Añadir materiales`,
      html:
      '<hr>'+
        '<label>Selecciona el grupo al que quieres añadir el material</label>'+
        `<select class="form-control" id="grupoSeleccionado">${opcionesGrupos}</select>`
      ,

      showCancelButton: true,
      confirmButtonText: 'Continuar',
      cancelButtonText: 'Cancelar',
      showLoaderOnConfirm: true,
      preConfirm: () => {
        const selectedGroup = document.getElementById("grupoSeleccionado").value

        arrayGrupos.map((x)=>{
          if(x.id==selectedGroup){
            arrayMaterialesPorAñadir.map(i=>x.materiales.push(i))
          }
        })
        cleanMaterialesdisponibles(arrayMaterialesPorAñadir)
        renderMaterialGroups(arrayGrupos)
      },
    }) 
  }
  else{
    Swal.fire(
      'Ups!',
      'Primero tienes que crear un grupo de envio',
      'error'
    )

  }
}

const renderMaterialGroups=(arrayGrupos)=>{
  arrayGrupos.map((x)=>{
    const selectedBody = document.getElementById(x.idBoby)
    var textoInnerBody = ""

    if(x.materiales.length != 0){
      document.getElementById(`boton-${x.id}`).style.display = 'none'
    }
    else{
      document.getElementById(`boton-${x.id}`).style.display = '' 
    }

    x.materiales.map((i)=>{
      textoInnerBody = textoInnerBody+`
<tr>
<td>${i.IDPMO}</td>
<td>${i.SitioDestino}</td>
<td>${i.elementos}</td>
<td>
<button class="btn btn-danger btn-sm" onclick="removeFromGrupo('${i.Id}','${i.IdTr}','${x.id}')"><i class="bi bi-trash"></i></button>
</td>
<tr>`
    })
    selectedBody.innerHTML=textoInnerBody

  })
}

const removeFromGrupo = (idEnMateriales,idEnInventario,idGrupo)=>{
  arrayGrupos.map((x)=>{
    if(x.id == idGrupo){
      x.materiales = x.materiales.filter(x=>x.Id!=idEnMateriales)
    }
  })
  document.getElementById(idEnInventario).style.display = ''
  document.getElementById(`check-${idEnInventario}`).checked = false
  renderMaterialGroups(arrayGrupos)

}

const cleanMaterialesdisponibles=(arrayMat)=>{
  arrayMat.map((x)=>{
    document.getElementById(x.IdTr).style.display = 'none'
  })
  arrayMaterialesPorAñadir = []
}



const checkboxListener = (element)=>{

  const splited = element.value.split(",")
  if(element.checked){
    const splited = element.value.split(",")
    const nuevoMaterial = new Object
    nuevoMaterial.Id = Math.random().toString(16).slice(2)
    nuevoMaterial.IdTr= splited[0]
    nuevoMaterial.SitioDestino = splited[1]
    nuevoMaterial.IDPMO = splited[2]
    nuevoMaterial.elementos = splited[3]

    arrayMaterialesPorAñadir.push(nuevoMaterial)
  }
  else{
    arrayMaterialesPorAñadir = arrayMaterialesPorAñadir.filter(x=> x.IdTr != splited[0])

  }



}



