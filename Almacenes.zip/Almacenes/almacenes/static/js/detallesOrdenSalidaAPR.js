const openModal = ()=>{
    $('#modalRecoleccion').modal('show')
}

const openModalCambio = ()=>{
    $('#modalCambio').modal('show')
}


const cancelarSalidaAPR = (folioSalida,idSalida) =>{
  Swal.fire({
    title: `Esta seguro de cancelar la salida ${folioSalida}`,
    showCancelButton: true,
    confirmButtonText: 'Continuar',
    cancelButtonText: 'Cancelar',
    showLoaderOnConfirm: true,
    preConfirm: async () => {
      const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
      const respuesta = await fetch('/cancelarSalidaAPR',{
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': csrftoken,  
        },
        body:JSON.stringify({
          'idSalida':idSalida,
        })
      })
      if (respuesta.ok){
        return jsRes = await respuesta.json() 
      }


    },
    allowOutsideClick: () => !Swal.isLoading()
  }).then((result) => {
      if (result.isConfirmed) {
        if(result.value.result == "Error"){
          Swal.fire({
            title:'Error!',
            text:result.value.message,
            icon:'error',
          }).then((result)=>{
              location.reload()
            })
        }
        if(result.value.result == "Ok"){
          Swal.fire({
            title:'Exito!',
            text:result.value.message,
            icon:'success',
          }).then((result)=>{
              location.reload()
            })
        }


      }
    })


}

const desgloceOcurre= (ocurre,ordenId)=>{

  const url = `/getMaterialsByOcurreAndSKU/${ocurre}/${ordenId}`


  fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',

    }

  })
    .then(response => {
      result = response.json()
      status_code = response.status;
      if(status_code != 200) {
        throw new Error(response.statusText);

      }else{

        return result
      }

    })
    .then(result => {
      obj = JSON.parse(result)
      document.getElementById("tituloDesgloce").innerHTML="Desgloce: "+ocurre
      tabla = document.getElementById("bodyDesgloce")
      tabla.innerHTML=""

      obj.map((x)=>{


        var row = tabla.insertRow(0);

        var skuValue = row.insertCell(0);
        var cantidad = row.insertCell(1);

        var PMO = row.insertCell(2);

        var Destino = row.insertCell(3);
        var Etiqueta = row.insertCell(4);


        if(x.IdMat__SKU == null){
          skuValue.innerHTML=x.IdInventario__Etiqueta

        }
        else{

          skuValue.innerHTML=x.IdMat__SKU
        }



        Etiqueta.innerHTML=x.IdInventario__Etiqueta
        cantidad.innerHTML=x.CtdSalida

        PMO.innerHTML=x.IDPMO

        Destino.innerHTML=x.SitioDestino__Nombre


      })

      $('#modalDesgloce').modal('show')

    })
    .catch(error=>{

      alert(error)

    })

}

const desgloceRecolector= (recolector,ordenId)=>{

  const url = `/getMaterialsByRecolectorAndSKU/${recolector}/${ordenId}`
  const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;


  fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',

    }

  })
    .then(response => {
      result = response.json()
      status_code = response.status;
      if(status_code != 200) {
        throw new Error(response.statusText);

      }else{

        return result
      }

    })
    .then(result => {
      obj = JSON.parse(result)
      document.getElementById("tituloDesgloce").innerHTML="Desgloce: "+recolector
      tabla = document.getElementById("bodyDesgloce")
      tabla.innerHTML=""

      obj.map((x)=>{

        var row = tabla.insertRow(0);

        var skuValue = row.insertCell(0);
        var cantidad = row.insertCell(1);

        var PMO = row.insertCell(2);

        var Destino = row.insertCell(3);
        var Etiqueta = row.insertCell(4);


        if(x.IdMat__SKU == null){
          skuValue.innerHTML=x.IdInventario__Etiqueta

        }
        else{

          skuValue.innerHTML=x.IdMat__SKU
        }
        Etiqueta.innerHTML=x.IdInventario__Etiqueta

        cantidad.innerHTML=x.CtdSalida

        PMO.innerHTML=x.IDPMO

        Destino.innerHTML=x.SitioDestino__Nombre


      })

      $('#modalDesgloce').modal('show')

    })
    .catch(error=>{

      alert(error)
    })

}


const generarGuiaEnvio=(ocurre,ordenId)=>{
  document.getElementById("tituloModalGuia").innerHTML="Generar guia: "+ocurre
  document.getElementById("InputOcurre").value=ocurre
  $('#modalGuia').modal('show')
}


const marcarComoEntregado=(valor,modo)=>{
  document.getElementById("tituloModalSalida").innerHTML="Salida conjunto: "+valor
  document.getElementById("inputModo").value=modo
  document.getElementById("inputValor").value=valor
  $('#modalSalida').modal('show')
}
