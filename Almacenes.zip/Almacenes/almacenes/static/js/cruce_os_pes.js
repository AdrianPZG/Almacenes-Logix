const getOsByPES = async (PES,esInterna)=>{
  const url = `/getOsByPES`
  const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
  document.getElementById("PES").innerHTML=" "+ PES
  const response = await fetch(url,{
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrftoken,  
    },
    body:JSON.stringify({
      'PES':PES,
      'esInterna':esInterna
    })
  });

  if(response.ok){
    const jsonResponse = await response.json()
    elementosEnBolsa = JSON.parse(jsonResponse.elementos_en_bolsa)


    const array_ordenes=[]
    jsonResponse.os_asociadas.map(i=>{
      array_ordenes.push(JSON.parse(i))
    })

    const array_entradas=[]
    jsonResponse.entradas.map(i=>{
      array_entradas.push(JSON.parse(i))
    })

    valorEntradas = 0
    valorBolsa = 0
    valorSalidas = 0


    html_materiales_en_bolsa=""
    html_ordenes_servicio=""
    html_entradas =""

    elementosEnBolsa.map(i=>{
      const porAbastecer = i.inventariados - i.salida
      var texto_clase = ''
      var color_inventariado = ''


      if(porAbastecer>0){
        texto_clase ="background-color:pink;"
      }

      if(porAbastecer<0){
        texto_clase ="background-color: orange;"
      }

      valorBolsa+=porAbastecer

      if(i.inventariados == 0){
        color_inventariado="bg-danger text-light"
      }

      html_materiales_en_bolsa+=`<tr class="text-center"><td title="${i.texto}">${i.sku}</td><td>${i.apr}</td><td>${i.salida}</td> <td>${i.POD}</td> <td style="${texto_clase}">${porAbastecer}</td> <td class="${color_inventariado}" >${i.inventariados}</td>  </tr>`
    })



    document.getElementById("tabla_materiales_bolsa").innerHTML=html_materiales_en_bolsa
    document.getElementById("valorBolsa").innerText=valorBolsa


    array_entradas.map((i)=>{
      valorEntradas+=i.elementos_entrada
      html_entradas+=`<tr class="text-center">  <td style="white-space:nowrap;">${i.folio}</td> <td>${i.elementos_entrada}</td></tr>`
    })
    document.getElementById("tabla_entradas").innerHTML=html_entradas
    document.getElementById("valorEntradas").innerText=valorEntradas


    array_ordenes.map(i=>{
      valorSalidas += i.elementos
      html_ordenes_servicio+=`<tr class="text-center"><td style="white-space:nowrap;">${i.OS}</td><td>${i.elementos}</td> <td><button class="btn btn-success btn-sm" type="buttton" onclick="getMaterialesByOS('${i.OS}')">Detalles</button></td></tr>`
    })
    document.getElementById("tabla_ordenes_sercio").innerHTML=html_ordenes_servicio
    document.getElementById("valorSalidas").innerText=valorSalidas


  }else{
    Swal.fire({
      title:'Ups!',
      text:"Ocurrio un error! contacta al administrador.",
      icon:'error',

    })
  }

}

const getMaterialesByOS = async(OS)=>{
  const url = `/getMaterialsByOS`
  const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

  const response = await fetch(url,{
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrftoken,  
    },
    body:JSON.stringify({
      'OS':OS,
    })
  });


  if(response.ok){
    const jsonResponse = await response.json()
    const materialesOS = JSON.parse(jsonResponse.materiales)

    let contenidoTablaMateriales = ""

    materialesOS.map(i=>{
      contenidoTablaMateriales+=`<tr><td title="${i.IdMat__TextoBreve}">${i.IdMat__SKU}</td><td>${i.IdInventario__IdApr__Etiqueta}</td><td>${i.CtdSalida}</td><td><a href="/detallesOrdenSalidaApr/${i.IdOrdenSalidaApr__Id}" class="btn btn-warning">${i.IdOrdenSalidaApr__Folio}</a></td></tr>`
    })


    Swal.fire({
      title: `Orden de servicio: ${OS}`,
      html: `
<table class="table">
<thead>
<th>SKU</th>                        
<th>APR</th>
<th>Cantidad</th>
<th>Salida</th>
</thead>
<tbody id="tabla_materiales">
${contenidoTablaMateriales}


</tbody>
</table>

`
    })
  }

}
