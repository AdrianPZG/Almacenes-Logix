
const showModalMateriales = () =>{
    $('#modalMateriales').modal('show')
}
const showModalUbTec = () =>{
    $('#modalUbTec').modal('show')
}



const desgloceMaterialesCaja= (caja,CodigoCaja)=>{
    
    const url = `/getMaterialsByCaja/${caja}`
  

    fetch(url, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            
        }
       
    })
    .then(response => {
        result = response.json()
        status_code = response.status;
        if(status_code != 200) {
            throw new Error(response.statusText);
            
        }else{

            return result
        }
        
    })
    .then(result => {
        obj = JSON.parse(result)
        document.getElementById("tituloDesgloceCaja").innerHTML="Desgloce: "+CodigoCaja
        tabla = document.getElementById("bodyDesgloceCaja")
        tabla.innerHTML=""

       

        obj.map((x)=>{
            
            
            var row = tabla.insertRow(0);

            var skuValue = row.insertCell(0);
            var apr = row.insertCell(1);
            var cantidad = row.insertCell(2);
            var noSerie = row.insertCell(3);
           

       

            
            skuValue.innerHTML=x.IdMat__SKU
            apr.innerHTML=x.IdMat__GrupoAPR__Etiqueta
            cantidad.innerHTML=x.CantidadEntrada
            noSerie.innerHTML=x.NoSerie
            

        })
        $("#modalDesgloceCaja").modal('show')

      
        
    })
    .catch(error=>{
       
        alert(error)

    })
    
}
