var materialesEnCarrito = []

const openModal = (matId,SKU,txt,tipo)=>{
    if(tipo == 2){

        document.getElementById("titleModalItem").innerHTML=SKU
        document.getElementById("sku").value=SKU
        document.getElementById("idMat").value=matId
        $('#modalItem').modal('show')
    }else{
        document.getElementById("titleModalCons").innerHTML=SKU
        document.getElementById("skuCons").value=SKU
        document.getElementById("idMatCons").value=matId
        document.getElementById("descCons").value=txt
        $('#modalCons').modal('show')
    }
}



const añadirAlCarrito = (event,tipo)=>{
    event.preventDefault()
    var isInCart = false
    
    

    const nuevoMaterial = {
        Id:new Date().getTime(),
    }

    if(tipo=="item"){
        nuevoMaterial.descItem = document.getElementById('descItem').value
        nuevoMaterial.cantidad = 1
        nuevoMaterial.SKU = document.getElementById('sku').value,
        nuevoMaterial.idMat = parseInt(document.getElementById('idMat').value)
        nuevoMaterial.noActivo = document.getElementById('noActivo').value
        nuevoMaterial.noSerie = document.getElementById('noSerie').value

        $('#modalItem').modal('hide')
        document.getElementById('descItem').value =""
    }else{
        nuevoMaterial.descItem = document.getElementById('descCons').value
        nuevoMaterial.cantidad = parseInt(document.getElementById('cantidadCons').value)
        nuevoMaterial.SKU = document.getElementById('skuCons').value
        nuevoMaterial.idMat = parseInt(document.getElementById('idMatCons').value)
        nuevoMaterial.noActivo = "No aplica"
        nuevoMaterial.noSerie = "No aplica"
        $('#modalCons').modal('hide')
        document.getElementById('cantidadCons').value =""
        
        var itemToDelete 
        materialesEnCarrito.map(item=>{
            if(item.SKU==nuevoMaterial.SKU){
                nuevoMaterial.cantidad = item.cantidad + nuevoMaterial.cantidad
               
                $(`#${item.Id}`).remove()

                
                materialesEnCarrito.pop(item)
                
            }

        })
        

    }

   
    materialesEnCarrito.push(nuevoMaterial)

    var table= document.getElementById('bodyMatCarrito')
    var row =  table.insertRow(0)
    row.id = nuevoMaterial.Id
    var SKU = row.insertCell(0)
    var desc = row.insertCell(1)
    var cantidad = row.insertCell(2)
    var noSerie = row.insertCell(3)
    var noActivo = row.insertCell(4)
    var boton = row.insertCell(5)


    SKU.innerHTML = nuevoMaterial.SKU
    desc.innerHTML = nuevoMaterial.descItem
    cantidad.innerHTML = nuevoMaterial.cantidad
    noSerie.innerHTML = nuevoMaterial.noSerie
    noActivo.innerHTML = nuevoMaterial.noActivo
    
    boton.innerHTML = `<button onClick=eliminarMat(this,${nuevoMaterial.Id}) class='btn btn-danger'>Eliminar</button>`
   

    
   
    
    
}

const eliminarMat = (btn,Id) =>{
   
    var row = btn.parentNode.parentNode
    row.parentNode.removeChild(row)
  
    materialesEnCarrito = materialesEnCarrito.filter(item=>{
        
        return item.Id !==Id
    })
 
}

const postMateriales = (event) =>{
    event.preventDefault()

    const materialesString = JSON.stringify(materialesEnCarrito)
    document.getElementById('materiales').value=materialesString
    document.getElementById("formMateriales").submit()
}