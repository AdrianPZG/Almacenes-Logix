
function checkextension() {
  var file = document.getElementById("archivoEntradaApr");
  if ( /\.(csv)$/i.test(file.files[0].name) === false ) { 
    Swal.fire({
      title:'Ups! Ocurrio un error.',
      text:"Solo se permiten archivos CSV",
      icon:'error',
    }).then((result) => {
      location.reload();
    });
    
   }
}

const nuevaEntrada = async ()=>{
    var data = new FormData();
      
    var PES = document.getElementById("PES").value
    
    
    var fechaEntrada = document.getElementById("fechaEntrada").value
    var almacen = document.getElementById("almacen").value
    var archivo = document.getElementById("archivoEntradaApr").files[0];

    if( document.getElementById("archivoEntradaApr").files.length == 0 ){
      Swal.fire({
        title:'Ups! Ocurrio un error.',
        text:"Selecciona un archivo",
        icon:'error',
      })
      return
    }


    if (PES=="" || fechaEntrada=="" || almacen==""){
      
      Swal.fire({
        title:'Ups! Ocurrio un error.',
        text:"Todos los campos son obligatorios",
        icon:'error',
      })
      return
    }

    data.append("archivo", archivo);
  
   const url = `/ordenEntradaApr/`
   const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

   $.ajax({
    url : url,
    processData : false,
    contentType : false,
    type : 'POST',
    data : data,
    
    
    headers: {
        'X-CSRFToken': csrftoken,
        'Action':"validarArchivo",
        'PES':PES,
        'fechaEntrada':fechaEntrada,
        'almacen':almacen
      }
   
    }).done(function(data){

       if(data.message=="Error"){
        Swal.fire({
            title:'Ups! Ocurrio un error.',
            text:data.error,
            icon:'error',
        })
       }
      
       if(data.ordenCreada == true){
       
        Swal.fire({
          title: `Exito`,
          text:`La orden de entrada ${data.folio} fue creada con exito.` ,
          icon:'success',
        }).then((result) => {
          location.reload();
        });
       }

       if(data.ordenCreada== false){

            const recordsDiscrepancias = ""

            var discrepancias = JSON.parse(data.discrepancias)

            var rowsDiscrepancias = ""

           
            discrepancias.map((i)=>{

              var clase ="bg-danger"

              if(i.tipo == "Sobrante en la entrada"){
                clase = "bg-warning"
              }
                

              rowsDiscrepancias += `<tr><td>${i.sku}</td><td>${i.desc}</td><td class="${clase}">${i.tipo}</td><td>${i.qty}</td></tr>`
            })


            var tablaDiscrepancias = `
            <table class="table">
                <thead>
                    <th>SKU</th>
                    <th>Descripción</th>
                    <th>Tipo</th>
                    <th>Qty</th>
                </thead>
                <tbody>
                    ${rowsDiscrepancias}
                </tbody>
            </table>
            `            

            var data2 = new FormData()
            data2.append("archivo", archivo);
            Swal.fire({
                title:`La orden de compra ${PES} tiene discrepancias, ingrese un comentario.`,
                input: 'textarea',
                inputAttributes: {
                  required: 'true'
                },
                html:tablaDiscrepancias,
                grow:"row",
                icon:'warning',
                showCancelButton: true,
                confirmButtonText: 'Continuar',
                showLoaderOnConfirm: true,
                preConfirm: (comentario) => {
                  return $.ajax({
                    url : url,
                    processData : false,
                    contentType : false,
                    type : 'POST',
                    data : data2,
                    headers: {
                        'X-CSRFToken': csrftoken,
                        'Action':"crearEntrada",
                        'PES':PES,
                        'comentario':comentario,
                        'fechaEntrada':fechaEntrada,
                        'almacen':almacen,
                        'esInterna':data.esInterna
                      }
                   
                    })
                },
                allowOutsideClick: () => !Swal.isLoading()
              }).then((result) => {
                if(result.value.message=="Error"){
                  Swal.fire({
                    title:'Ups! Ocurrio un error.',
                    text:result.value.error,
                    icon:'error',
                }).then((result) => {
                  location.reload();
                });
                }
                Swal.fire({
                  title: `Exito`,
                  text:`La orden de entrada ${result.value.folio} fue creada con exito.` ,
                  icon:'success',
                })
                
              })
       }
       
       
    });




  

  
  
}