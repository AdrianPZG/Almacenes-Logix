const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;


var faltante_global=0

var table = $('#tablemat').DataTable({ 
    columnDefs: [{ width: '25%', targets: 0 }],
    'rowCallback': function(row, data, index){
    if(data[4]>0){
      $(row).find('td:eq(4)').css('background', '#B0C2F2');
    }
    if(data[5]>0){
      $(row).find('td:eq(5)').css('background', '#FDFD96');
    }
    if(data[6]>0){
      $(row).find('td:eq(6)').css('background', '#ffda9e');
    }
    if(data[8]>0){
      $(row).find('td:eq(8)').css('background', '#b0f2c2');
    }
  if(data[8]<0){
      $(row).find('td:eq(8)').css('background', '#fabfb7');
    }

  }
});



var table_salidas = $('#table-salidas').DataTable({ 
    columnDefs: [{ width: '30%', targets: 0 }],
    'rowCallback': function(row, data, index){
   if(data[3]>0){
      $(row).find('td:eq(3)').css('background', '#fabfb7');
    }
  }
});




var table_entradas = $('#table-entradas').DataTable({ 
    columnDefs: [{ width: '30%', targets: 0 }],
    'rowCallback': function(row, data, index){
    if(data[3]>0){
      $(row).find('td:eq(3)').css('background', '#fabfb7');
    }
  
  }
});




const getBolsa = (pes)=>{
  faltante_global = 0

  var apr_inv = 0
  var apr_sal = 0
  var item_inv = 0
  var item_sal = 0
  var item_fal = 0
  var apr_fal = 0

  var os_list = []
  var os_values= []

  document.getElementById('faltantes').textContent = faltante_global
  table.clear().draw() 
  table_entradas.clear().draw() 
  table_salidas.clear().draw() 
  document.getElementById("titulo-bolsa").textContent =`Bolsa de materiales ${pes} `
  fetch("/cruce_os_pes/",{
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': csrftoken,  
    },
    body:JSON.stringify({
      'action':'getBolsa',
      'pes':pes

    })
  })
    .then(res=>res.json())
    .then(data=>{
      const entradas =  JSON.parse(data.entradas)
      const entradas_ordenes=  JSON.parse(data.Oentradas)
      const salidas_ordenes=  JSON.parse(data.Osalidas)
      const os=  JSON.parse(data.os)
      
      os.map((x)=>{
        os_list.push(x.OS)
        os_values.push(x.elementos_Salida)
      })


      

      entradas_ordenes.map((x)=>{
        table_entradas.row.add([x.Folio,x.elementos_POD,x.elementos_Inventariados,x.elementos_Pendientes]).draw(false)
      })

      salidas_ordenes.map((x)=>{
        table_salidas.row.add([x.IdOrdenSalidaApr__Folio,x.elementos_Salida,x.elementos_Cancelados,x.elementos_Pendientes]).draw(false)
      })


      document.getElementById('last_entry').textContent=data.last_entry
      document.getElementById('first_out').textContent=data.first_out

      entradas.map((x)=>{
        
        if(x.sku){
          item_inv+=x.counter_inventariado
          item_sal+=x.counter_salida
          item_fal+=x.counter_salida - x.counter_inventariado
        }else{
          apr_inv+=x.counter_inventariado
          apr_sal+=x.counter_salida
          apr_fal+=x.counter_salida - x.counter_inventariado
        }

        var suma =  x.counter_salida - x.counter_inventariado
        document.getElementById('faltantes').textContent = faltante_global+ suma
        faltante_global = faltante_global+suma
        table.row.add([
          x.sku,
          x.apr,
          x.counter_inventariado,
          x.counter_salida,
          x.counter_pendiente_inventariar,
          x.counter_pendiente_salida,
          x.counter_cancelados_salida,
          x.counter_POD,
          suma]).draw(false)

      })

      InOutChart.options.plugins.title.text = pes;
      InOutChart.data.labels = ["APR"];
      InOutChart.data.datasets[0].data = [apr_inv];
      InOutChart.data.datasets[1].data = [apr_sal];
      InOutChart.data.datasets[2].data = [apr_fal];
      InOutChart.update();

      InOutChart2.options.plugins.title.text = pes;
      InOutChart2.data.labels = ["Items"];
      InOutChart2.data.datasets[0].data = [item_inv];
      InOutChart2.data.datasets[1].data = [item_sal];
      InOutChart2.data.datasets[2].data = [item_fal];
      InOutChart2.update();


      InOutChart3.options.plugins.title.text = pes;
      InOutChart3.data.labels = os_list;
      InOutChart3.data.datasets[0].data = os_values;
      InOutChart3.update();



    })


}

document.getElementById('reporteGlobal').addEventListener("click", function(event) {
const validateEmail = (email) => {
  return String(email)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    );
};

  Swal.fire({
    title: `Ingresa las siguiente información`,
    html:
    '<hr>'+
      '<label>Correo destino</label>'+
      `<input id="correo" class="form-control" type="email" required>`
    ,
    showCancelButton: true,
    confirmButtonText: 'Continuar',
    cancelButtonText: 'Cancelar',
    showLoaderOnConfirm: true,
    preConfirm: async () => {
      var correo= document.getElementById("correo").value

      var correo_validation = validateEmail(correo)

      if (correo_validation!=null) {
        const respuesta = await fetch('/reporteBolsaGlobal',{
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken,  
          },
          body:JSON.stringify({
            'correo':correo,
          })
        })
        if (respuesta.ok){
          const jsRes = await respuesta.json() 
          return  jsRes
        }
      } 
      else {
        Swal.showValidationMessage('Ingresa un correo valido')   
      }
    },
    allowOutsideClick: () => !Swal.isLoading()
  }).then((result) => {
      if (result.isConfirmed){
        Swal.fire(result.value.title,result.value.text,result.value.icon).then(result=>location.reload())
      }
    })

});
