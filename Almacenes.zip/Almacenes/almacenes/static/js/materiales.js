const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

var table_materiales = $('#tableMateriales').DataTable({ 
    columnDefs: [{ width: '10%', targets: 0 }],
    'rowCallback': function(row, data, index){
   if(data[4]=="Si"){
      $(row).find('td:eq(4)').css('background', '#b0f2c2');
    }else{

      $(row).find('td:eq(4)').css('background', '#fabfb7');
    }
    if(data[3]=="Agrupado"){
      $(row).find('td:eq(5)').css('background', '#B0C2F2');
    }
  }
});




function checkextension() {
    var file = document.getElementById("archivoSKUS");
    if ( /\.(csv)$/i.test(file.files[0].name) === false ) { 
      Swal.fire({
        title:'Ups! Ocurrio un error.',
        text:"Solo se permiten archivos CSV",
        icon:'error',
      }).then((result) => {
        location.reload();
      });
      
     }
  }
 










