const mandarNotificacionOrdenSalidaApr = async(ordenId,Folio)=>{

    Swal.fire({
        title: `Notificacion: ${Folio}`,
        html:
        '<hr>'+
        '<label>Ingresa el correo destinatario</label>'+
        '<input type="email" class="form-control" id="principal" placeholder="Ingresa el destinatario"/>'+
        '<label>Ingresa los correos  a los cuales se les enviara copia separados por una coma</label>'+
        '<input placeholder="Ingresa los correos " id="copia" class="form-control"/>'
        ,

        showCancelButton: true,
        confirmButtonText: 'Continuar',
        cancelButtonText: 'Cancelar',
        showLoaderOnConfirm: true,
        preConfirm: async () => {
            
            const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

            const principal = document.getElementById("principal").value
            const copia = document.getElementById("copia").value

            if (principal) {
                
                const regexExp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/gi;

                let correosInvalidos = ""
                
                if(regexExp.test(principal)){


                    if (copia.length != 0){
                       
                        const arrayCorreos = copia.split(",")


                        await arrayCorreos.map((x)=>{
                            const regexExp2 = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/gi;

                            if(!regexExp2.test(x)){
                                correosInvalidos = correosInvalidos+" "+x
                            }
                        })

                         
                    }

                    if(correosInvalidos.length == 0){

                        const respuesta = await fetch('/notificacionSalidaApr',{
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRFToken': csrftoken,  
                            },
                            body:JSON.stringify({
                                'principal':principal,
                                'copia':copia,
                                'idOrdenSalida':ordenId
                                
                            })
                        })
                        if (respuesta.ok){
                            return jsRes = await respuesta.json() 
                        }
                    }
                    else{

                        Swal.showValidationMessage(`Los correos '${correosInvalidos}' son invalidos`)   
                    }
                }
                else{
                    Swal.showValidationMessage(`'${principal}' no es un correo valido`)   

                }               

            }
            else {
            Swal.showValidationMessage('Todos los campos son obligatorios')   
            }
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.isConfirmed) {
            if(result.value.result == "Error"){
                Swal.fire({
                    title:'Error!',
                    text:result.value.message,
                    icon:'error',
                })
            }
            if(result.value.result == "Ok"){
                Swal.fire({
                    title:'Exito!',
                    text:result.value.message,
                    icon:'success',
                })

            }


        }
    })
    

}
