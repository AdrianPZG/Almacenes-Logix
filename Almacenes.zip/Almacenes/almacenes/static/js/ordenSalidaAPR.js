function checkextension() {
    var file = document.getElementById("archivoMateriales");
    if ( /\.(csv)$/i.test(file.files[0].name) === false ) { 
      Swal.fire({
        title:'Ups! Ocurrio un error.',
        text:"Solo se permiten archivos CSV",
        icon:'error',
      }).then((result) => {
        location.reload();
      });
      
     }
  }
  