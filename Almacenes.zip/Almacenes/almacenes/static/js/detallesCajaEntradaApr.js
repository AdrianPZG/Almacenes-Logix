const validarMaterial= async (event,ordenId,cajaId)=>{

    event.preventDefault()
    sku = document.getElementById("sku").value
    
    if(parseInt(sku.length) == 0){
        
        Swal.fire({
            title:'Ups!',
            text:"El campo SKU es obligatorio",
            icon:'error',
            timer:2000
        })
        return
    }
   
    const url = `/validarMaterialOrdenEntradaApr`
    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

    const response = await fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken,  
        },
        body:JSON.stringify({
            'sku':sku,
            'IdOrden':ordenId,
            'IdCaja':cajaId
        })
    });
    
    if(response.ok){
        const jsonResponse = await response.json()
        if(jsonResponse.result == "Error"){
            Swal.fire({
                title:'Ups!',
                text:jsonResponse.message,
                icon:'error',
                timer:3000
            })
        }
        if(jsonResponse.result == "Ok"){
            if(jsonResponse.modal == "modalItem"){
                Swal.fire({
                    title: `Escanea el número de serie`,
                    html:
                    
                    '<input placeholder="Número de serie" id="noSerie" class="swal2-input" required>'
                    ,

                    showCancelButton: true,
                    confirmButtonText: 'Continuar',
                    cancelButtonText: 'Cancelar',
                    showLoaderOnConfirm: true,
                    preConfirm: async () => {
                        
                        noSerie = document.getElementById('noSerie').value

                        if (noSerie) {
                            const respuesta = await fetch('/validarNoSerieEntradaApr',{
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRFToken': csrftoken,  
                                },
                                body:JSON.stringify({
                                    'sku':sku,
                                    'caja':cajaId,
                                    'noSerie':noSerie,
                                    'ordenId':ordenId
                                })
                            })
                            if (respuesta.ok){
                                return jsRes = await respuesta.json()
                                
                            }
                            
                        } else {
                        Swal.showValidationMessage('Todos los campos son obligatorios')   
                        }
                    },
                    allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                    if (result.isConfirmed) {
                        
                        if(result.value.result=="Error"){
                            Swal.fire({
                                title:'Información faltante',
                                text:result.value.message,
                                icon:'error',
                            }).then((result) => {
                                location.reload();
                            });
                        }
                        
                        if(result.value.result =="Información faltante"){

                            Swal.fire({
                                title:'Ups!',
                                text:result.value.message,
                                icon:'success',
                            }).then((result) => {
                                location.reload();
                            });
                        }

                        if(result.value.result=="ItemEnLaOrden"){
                            const arrayActivos = ['logixA','etiquetaActivoA']
                           
                           
                            Swal.fire({
                                title: `El item esta en la orden, ingresa la siguiente información`,
                                html: '<input placeholder="Etiqueta logix" id="logixA" class="swal2-input" required>' +
                                '<input placeholder="Etiqueta de activo" id="etiquetaActivoA" class="swal2-input" required>',
                                showCancelButton: true,
                                confirmButtonText: 'Continuar',
                                cancelButtonText: 'Cancelar',
                                showLoaderOnConfirm: true,
                                preConfirm: async () => {
            
                                    let validacion = true

                                    await arrayActivos.map(x=>{
                                        const dato = document.getElementById(x).value

                                        if(!dato){
                                            validacion = false
                                        }
                                    })

                                    if (validacion) {
                                        const logix = document.getElementById('logixA').value
                                       
                                        const etiquetaActivo = document.getElementById('etiquetaActivoA').value
                                        
                                        const respuesta = await fetch('/inventariarElementoApr',{
                                            method: 'POST',
                                            headers: {
                                                'Content-Type': 'application/json',
                                                'X-CSRFToken': csrftoken,  
                                            },
                                            body:JSON.stringify({
                                                'logix':logix,
                                                'etiquetaActivo':etiquetaActivo,
                                                'idCaja':cajaId,
                                                'idMatOrden':result.value.IdMatOrden,
                                                
                                            })
                                        })
                                        if (respuesta.ok){
                                            return jsRes = await respuesta.json()
                                        }
                                        
                                    } else {
                                    Swal.showValidationMessage('Todos los campos son obligatorios')   
                                    }
                                },
                                allowOutsideClick: () => !Swal.isLoading()
                            }).then((result) => {
                                
                                if (result.value.result == "Error") { 
                                    Swal.fire({
                                        title:'Ups!',
                                        text:result.value.message,
                                        icon:'error',
                                        
                                    }).then((result) => {
                                        location.reload();
                                    });
                                }

                                if (result.value.result == "Ok"){
                                    Swal.fire({
                                        title:'Exito!',
                                        text:result.value.message,
                                        icon:'success',
                                       
                                    }).then((result) => {
                                        location.reload();
                                    });
                                }
                                
                            })
                        }

                        


                    }
                   
                })
            }
            
            if(jsonResponse.modal=="modalAPR"){
                Swal.fire({
                    title: `Ingresa la cantidad`,
                    html:
                    
                    '<input placeholder="Cantidad" id="cantidadAPR" class="swal2-input" type="number" required>'
                    ,

                    showCancelButton: true,
                    confirmButtonText: 'Continuar',
                    cancelButtonText: 'Cancelar',
                    showLoaderOnConfirm: true,
                    preConfirm: async () => {
                        const qty = document.getElementById("cantidadAPR").value

                        if (qty) {
                            const respuesta = await fetch('/inventariarAgrupadoApr',{
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRFToken': csrftoken,  
                                },
                                body:JSON.stringify({
                                    'cantidad':qty,
                                    'sku':sku,
                                    'idCaja':cajaId
                                    
                                })
                            })
                            if (respuesta.ok){
                                return jsRes = await respuesta.json() 
                            }
                        } else {
                        Swal.showValidationMessage('Todos los campos son obligatorios')   
                        }
                    },
                    allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                    if (result.isConfirmed) {
                        if(result.value.result == "Error"){
                            Swal.fire({
                                title:'Error!',
                                text:result.value.message,
                                icon:'error',
                            }).then((result) => {
                                location.reload();
                            });

                        }
                        if(result.value.result == "Ok"){
                            Swal.fire({
                                title:'Exito',
                                text:result.value.message,
                                icon:'info',
                            }).then((result) => {
                                location.reload();
                            });

                        }
                    }
                })
            }

            if(jsonResponse.modal=="modalEtiquetaLogix"){
                Swal.fire({
                    title: `Escanea la etiqueta logix`,
                    html:
                    
                    '<input placeholder="Etiqueta logix" id="logix" class="swal2-input" type="text" required>'
                    ,

                    showCancelButton: true,
                    confirmButtonText: 'Continuar',
                    cancelButtonText: 'Cancelar',
                    showLoaderOnConfirm: true,
                    preConfirm: async () => {
                        const logix = document.getElementById("logix").value

                        if (logix) {
                            const respuesta = await fetch('/inventariarItemNoActivo',{
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRFToken': csrftoken,  
                                },
                                body:JSON.stringify({
                                    'logix':logix,
                                    'sku':sku,
                                    'idCaja':cajaId
                                    
                                })
                            })
                            if (respuesta.ok){
                                return jsRes = await respuesta.json() 
                            }
                        } else {
                        Swal.showValidationMessage('Todos los campos son obligatorios')   
                        }
                    },
                    allowOutsideClick: () => !Swal.isLoading()
                }).then((result) => {
                    console.log(result)
                    if (result.isConfirmed) {
                        if(result.value.result == "Error"){
                            Swal.fire({
                                title:'Error!',
                                text:result.value.message,
                                icon:'error',
                            }).then((result) => {
                                location.reload();
                            });

                        }
                        if(result.value.result == "Ok"){
                            Swal.fire({
                                title:'Exito!',
                                text:result.value.message,
                                icon:'success',
                            }).then((result) => {
                                location.reload();
                            });

                        }


                    }
                })
            }
        }

        if(jsonResponse.result == "Item no activo fuera de orden"){
            Swal.fire({
                title:'Ups!',
                text:jsonResponse.message,
                icon:'info',
            }).then((result) => {
                location.reload();
            });
        }


    }
    
    document.getElementById('sku').value=""

}

const getPlantillaCaja = (idCaja,codigo)=>{
    const url = `/getPlantillaInventariarCaja`
    const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

    const response = fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrftoken,  
        },
        body:JSON.stringify({
            'idCaja':idCaja
        })
    }).then((res) => { return res.blob(); })
    .then((data) => {
      var a = document.createElement("a");
      a.href = window.URL.createObjectURL(data);
      a.download = `Inventariar-Caja-${codigo}.csv`;
      a.click();
    });
    

}


