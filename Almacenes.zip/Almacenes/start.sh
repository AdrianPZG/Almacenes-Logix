#!/bin/bash

# Start the background process
pipenv run python almacenes/manage.py send_email &

# Start the Django development server
pipenv run python almacenes/manage.py runserver --insecure 0.0.0.0:8000